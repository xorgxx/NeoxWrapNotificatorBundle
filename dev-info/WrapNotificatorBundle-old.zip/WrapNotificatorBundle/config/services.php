<?php

namespace Symfony\Component\DependencyInjection\Loader\Configurator;

use Neox\WrapNotificatorBundle\Application\Notificator;
use Neox\WrapNotificatorBundle\Application\AsyncNotificator;
use Neox\WrapNotificatorBundle\Application\NotificatorInterface;
use Neox\WrapNotificatorBundle\Application\Orchestrator\NotificationOrchestrator;
use Neox\WrapNotificatorBundle\Infrastructure\Channel\ChannelSenderInterface;
use Neox\WrapNotificatorBundle\Infrastructure\Channel\Email\MailerChannelSender;
use Neox\WrapNotificatorBundle\Infrastructure\Channel\Sms\SmsChannelSender;
use Neox\WrapNotificatorBundle\Infrastructure\Channel\Sms\Provider\SmsProviderInterface;
use Neox\WrapNotificatorBundle\Infrastructure\Channel\Sms\Dsn\SmsDsnResolver;
use Neox\WrapNotificatorBundle\Infrastructure\Channel\Sms\Dsn\TwilioSmsProviderFactory;
use Neox\WrapNotificatorBundle\Infrastructure\Channel\Sms\Dsn\NullSmsProviderFactory;
use Neox\WrapNotificatorBundle\Infrastructure\Channel\Webhook\WebhookChannelSender;
use Neox\WrapNotificatorBundle\Infrastructure\Channel\Webpush\WebpushChannelSender;
use Neox\WrapNotificatorBundle\Infrastructure\Mercure\MercurePublisher;
use Neox\WrapNotificatorBundle\Infrastructure\Messenger\Handler\AsyncNotificationHandler;
use Neox\WrapNotificatorBundle\Infrastructure\Messenger\Message\AsyncNotificationMessage;
use Neox\WrapNotificatorBundle\Infrastructure\Health\ChannelHealthCheckerInterface;
use Neox\WrapNotificatorBundle\Infrastructure\Health\SimpleChannelHealthChecker;
use Neox\WrapNotificatorBundle\Infrastructure\Idempotency\InMemoryStore;
use Neox\WrapNotificatorBundle\Infrastructure\Idempotency\StoreInterface;
use Neox\WrapNotificatorBundle\Infrastructure\Storage\NotificationStorageInterface;
use Neox\WrapNotificatorBundle\Infrastructure\Storage\FileNotificationStorage;
use Neox\WrapNotificatorBundle\Application\NotificationScheduler;
use Neox\WrapNotificatorBundle\Infrastructure\Messenger\Message\FlushDueNotificationsMessage;
use Neox\WrapNotificatorBundle\Infrastructure\Messenger\Handler\FlushDueNotificationsHandler;
use Neox\WrapNotificatorBundle\UI\Command\NotificatorMercureSendCommand;
use Neox\WrapNotificatorBundle\UI\Command\NotificatorMercureTestCommand;
use Neox\WrapNotificatorBundle\UI\Command\NotificatorSendCommand;
// use Neox\WrapNotificatorBundle\UI\Command\NotificatorTestCommand;
use Neox\WrapNotificatorBundle\UI\Controller\ArgumentValueResolver\WrapNotificatorConfigValueResolver;
use Neox\WrapNotificatorBundle\UI\EventListener\AutoTurboInjectorListener;
use Neox\WrapNotificatorBundle\UI\Twig\MercureExtension;
use Symfony\Component\DependencyInjection\Reference;
use Neox\WrapNotificatorBundle\UI\Command\NotificationsFlushPendingCommand;
use Neox\WrapNotificatorBundle\UI\Command\NotificationScheduleCommand;
use Neox\WrapNotificatorBundle\UI\Command\NotificationEmailCommand;

return static function (ContainerConfigurator $configurator) {
    $services = $configurator->services()
        ->defaults()
        ->autowire()
        ->autoconfigure();


    // Publisher générique
    $services
        ->set(MercurePublisher::class)
        ->arg('$hub', service('mercure.hub.default')->nullOnInvalid())
        ->arg('$enabled', param('wrap_notificator.mercure.enabled'))
        ->arg('$serializer', service('serializer')->nullOnInvalid())
        ->arg('$turboEnabled', '%wrap_notificator.mercure.turbo_enabled%')
        ->arg('$defaultTopic', '%wrap_notificator.mercure.default_topic%')
        ->arg('$twig', service('twig')->nullOnInvalid())
    ;

    // Extension Twig
    $services
        ->set(MercureExtension::class)
        ->tag('twig.extension');

    $services->set(StoreInterface::class, InMemoryStore::class);

    $services->set(SimpleChannelHealthChecker::class)
        ->alias(ChannelHealthCheckerInterface::class, SimpleChannelHealthChecker::class);

    $services->set(MailerChannelSender::class)
        ->arg('$config', param('wrap_notificator.channels.email'))
        ->arg('$templatesBasePath', param('wrap_notificator.templates.base_path'))
        ->tag('notificator.channel_sender');

    $services->set(SmsChannelSender::class)
        ->arg('$config', param('wrap_notificator.channels.sms'))
        ->arg('$templatesBasePath', param('wrap_notificator.templates.base_path'))
        ->tag('notificator.channel_sender');

    $services->set(WebhookChannelSender::class)
        ->arg('$config', param('wrap_notificator.channels.webhook'))
        ->tag('notificator.channel_sender');

    $services->set(WebpushChannelSender::class)
        ->arg('$config', param('wrap_notificator.channels.webpush'))
        ->tag('notificator.channel_sender');

    // Auto-inject Turbo listener into HTML responses
    $services->set(AutoTurboInjectorListener::class)
        ->arg('$enabled', param('wrap_notificator.mercure.auto_inject'))
        ->arg('$turboEnabled', param('wrap_notificator.mercure.turbo_enabled'))
        ->arg('$publicUrl', param('wrap_notificator.mercure.public_url')) // use configured param for public URL
        ->arg('$defaultTopic', param('wrap_notificator.mercure.default_topic'))
        ->arg('$twig', service('twig')->nullOnInvalid())
        ->arg('$onlyAuthenticated', param('wrap_notificator.mercure.only_authenticated'))
        ->arg('$security', service('security.helper')->nullOnInvalid());

    // SMS DSN support: register factories and resolver
    $services->set(TwilioSmsProviderFactory::class)->tag('wrap_notificator.sms_provider_factory');
    $services->set(NullSmsProviderFactory::class)->tag('wrap_notificator.sms_provider_factory');

    $services->set(SmsDsnResolver::class)
        ->arg('$factories', tagged_iterator('wrap_notificator.sms_provider_factory'));

    // Expose provider built from DSN/config via resolver factory
    $services->set(SmsProviderInterface::class)
        ->factory([service(SmsDsnResolver::class), 'fromConfig'])
        ->arg('$dsn', param('wrap_notificator.channels.sms.dsn'))
        ->arg('$smsConfig', param('wrap_notificator.channels.sms'));

    $services->set(NotificationOrchestrator::class)
        ->arg('$defaultChannel', param('wrap_notificator.default_channel'))
        ->arg('$fallbackOrder', param('wrap_notificator.fallback.order'))
        ->arg('$maxSwitches', param('wrap_notificator.fallback.max_switches'))
        ->arg('$mercurePublisher', service(MercurePublisher::class))
        ->arg('$healthChecker', service(ChannelHealthCheckerInterface::class))
        ->arg('$idempotencyStore', service(StoreInterface::class))
        ->arg('$channelSenders', tagged_iterator('notificator.channel_sender'))
        ->arg('$logger', service('monolog.logger.wrap_notificator')->nullOnInvalid());

    $services->set(Notificator::class)
        ->arg('$orchestrator', service(NotificationOrchestrator::class))
        ->arg('$asyncNotificator', service(AsyncNotificator::class))
        ->arg('$asyncEnabled', param('wrap_notificator.async.enabled'))
        ->alias(NotificatorInterface::class, Notificator::class);

    $services->set(AsyncNotificator::class)
        ->arg('$bus', service('messenger.default_bus'));

    $services->set(AsyncNotificationHandler::class)
        ->tag('messenger.message_handler');

    // Storage wiring (file driver by default)
    $services->set(FileNotificationStorage::class)
        ->arg('$filePath', param('wrap_notificator.storage.file_path'))
        ->arg('$defaultBatchSize', param('wrap_notificator.storage.batch_size'));
    $services->alias(NotificationStorageInterface::class, FileNotificationStorage::class);

    // Scheduler
    $services->set(NotificationScheduler::class)
        ->arg('$defaultDelaySeconds', param('wrap_notificator.storage.default_delay_seconds'));

    // Flush handler
    $services->set(FlushDueNotificationsHandler::class)
        ->tag('messenger.message_handler');

    // Controller Argument Resolver to inject config via attribute + auto alert
    $services->set(WrapNotificatorConfigValueResolver::class)
        ->arg('$bundleConfig', param('wrap_notificator.config'))
        ->arg('$asyncNotificator', service(AsyncNotificator::class))
        ->arg('$notificator', service(NotificatorInterface::class))
        ->arg('$logger', service('monolog.logger.wrap_notificator')->nullOnInvalid())
        ->tag('controller.argument_value_resolver', ['priority' => 50]);

    // Commands
    $services->set(NotificationEmailCommand::class);
    $services->set(NotificationsFlushPendingCommand::class);
    $services->set(NotificationScheduleCommand::class);
    $services->set(NotificatorMercureSendCommand::class)
             ->arg('$mercureEnabled', param('wrap_notificator.mercure.enabled'))
             ->arg('$defaultTopic', param('wrap_notificator.mercure.default_topic'));
    $services->set(NotificatorMercureTestCommand::class)
             ->arg('$mercureEnabled', param('wrap_notificator.mercure.enabled'))
             ->arg('$publicUrl', param('wrap_notificator.mercure.public_url'))
             ->arg('$defaultTopic', param('wrap_notificator.mercure.default_topic'));
};
