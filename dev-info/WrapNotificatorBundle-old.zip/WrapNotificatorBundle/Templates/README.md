Ce dossier contient des modèles (templates) par défaut pour les canaux: email, sms, alert, webhook. Copiez / adaptez-les dans votre application au besoin.
