# WRAPPER — Wrap Notificator Bundle (overview)

WRAPPER unifie l’envoi de notifications multi‑canaux pour vos applis Symfony :
- Canaux pris en charge : email, SMS, webhook, webpush et in‑app.
- Asynchrone par défaut via Messenger (retries, backoff, délais).
- Fallback automatique entre canaux selon votre politique.
- Diffusion en temps réel via Mercure (+ Turbo Streams en option).
- Stockage différé et envoi par lot.
- Journalisation dédiée (canal Monolog `wrap_notificator`).

Ce README présente les principes. Les guides détaillés (avec exemples) sont dans le dossier [doc/](doc/).

## Principe de fonctionnement
1. Vous construisez un `NotificationMessage` (sujet, texte/HTML, destinataires, canal préféré, options).
2. Vous le transmettez au Notificator :
   - Asynchrone (recommandé) en définissant `$message->async = true` puis `NotificatorInterface->send($message)` — envoi via Messenger, prise en compte de `delaySeconds`.
   - Synchrone avec `NotificatorInterface->send($message)`.
3. Le bundle choisit le canal (préféré ou par défaut), applique la stratégie de fallback si besoin, et diffuse des événements (Mercure/Turbo) si activés.

## Démarrage rapide
- Installer/configurer Messenger dans votre projet.
- Configurer le bundle dans `config\packages\wrap_notificator.yaml` (exemples détaillés dans `doc/Fr/README.md` et `doc/En/README.md`).
- Important (SMS) : utilisez un DSN sous forme de chaîne (string) :

```yaml
wrap_notificator:
  channels:
    sms:
      dsn: '%env(WRAP_SMS_DSN)%' # ex: sms+twilio://ACCOUNT_SID:AUTH_TOKEN@default?from=%2B33612345678
```

Exemple d’envoi (async) :

```php
use Neox\WrapNotificatorBundle\Application\NotificatorInterface;
use Neox\WrapNotificatorBundle\Domain\Enum\Channel;
use Neox\WrapNotificatorBundle\Domain\Model\NotificationMessage;

public function send(NotificatorInterface $notificator): void
{
    $msg = new NotificationMessage(
        subject: 'Bienvenue',
        bodyText: 'Bonjour et bienvenue !',
        recipients: ['user@example.com'],
        channelPreferred: Channel::EMAIL,
    );
    $msg->async = true;           // recommandé: passe par Messenger
    $notificator->send($msg);     // dispatch async
}
```

## Documentation
- Français: [doc/Fr/README.md](doc/Fr/README.md)
- English: [doc/En/README.md](doc/En/README.md)

## Toutes les fonctionnalités / All features
- FR: [doc/Fr/FEATURES.md](doc/Fr/FEATURES.md)
- EN: [doc/En/FEATURES.md](doc/En/FEATURES.md)

## Temps réel côté client / Client‑side real‑time
- Twig functions:
  - `stream_notifications(topics = [default])` → toasts in page + Turbo Streams support
  - `neox_notify(topics = [])` → native OS notifications (Web Notifications API), fallback to toasts
- Bootstrap helper: `wrap_notify_bootstrap()` injects container + CSS/JS (SweetAlert toast if available, else modern fallback)
- Hub auto‑detection on the client: `<link rel="mercure">`, `<meta name="mercure-hub">`, `window.MERCURE_PUBLIC_URL`, or configured param.
- Docs:
  - FR: [doc/Fr/categories/realtime-mercure-turbo.md](doc/Fr/categories/realtime-mercure-turbo.md)
  - EN: [doc/En/categories/realtime-mercure-turbo.md](doc/En/categories/realtime-mercure-turbo.md)

## Ajout d’un provider SMS
- Twilio via DSN : `sms+twilio://ACCOUNT_SID:AUTH_TOKEN@default?from=%2B33612345678`.
- Provider custom : implémentez `SmsProviderInterface` + une factory `SmsProviderFactoryInterface`, et taguez : `wrap_notificator.sms_provider_factory`.

Détails et exemples dans la documentation:
- FR: doc/Fr/README.md
- EN: doc/En/README.md

## Dépannage rapide
- `java.net.ConnectException` (en local souvent via Docker/RabbitMQ/Proxy) : vérifiez DSN/URL, réseau, certificats, et la disponibilité du transport Messenger. Voir les sections dédiées dans la doc.
