# Toutes les fonctionnalités du bundle (FR)

Cette page regroupe, en un seul endroit, l’ensemble des fonctionnalités offertes par WrapNotificatorBundle. Pour chaque catégorie, une page détaillée est disponible dans doc/Fr/categories/.

Accès rapide aux catégories:
- [Canaux](./categories/channels.md)
  - Email (Mailer) — Templates Twig, pièces jointes, CC/BCC, HTML/TXT
  - SMS — Providers via DSN (Twilio intégré), provider custom via interfaces
  - Webhook — POST/JSON avec timeouts et statuts retryables
  - Webpush — Activation optionnelle
  - In‑app — Placeholder (selon intégration app), via Channel enum et sender dédié
- [Synchrone/Asynchrone](./categories/sync-async.md)
  - Synchrone: NotificatorInterface->send(NotificationMessage)
  - Asynchrone: définissez `$message->async = true` puis `NotificatorInterface->send($message)` (Messenger)
  - Gestion du délai programmé via NotificationMessage->withDelaySeconds()
  - Retries/Backoff configurables côté Messenger et via la config du bundle
- [Orchestration & fallback](./categories/orchestration-fallback.md)
  - Canal par défaut configurable
  - Ordre de fallback et nombre de bascules (max_switches)
  - Politique de switch (DefaultSwitchPolicy)
  - Health checker des canaux (SimpleChannelHealthChecker, extensible)
- [Temps réel (Mercure/Turbo)](./categories/realtime-mercure-turbo.md)
  - Mercure publisher intégré (événements: dispatched, sent, failed, switched)
  - Injection automatique côté HTML via Turbo Streams (listener configurable)
  - Compatibilité Turbo Streams
- [Idempotence](./categories/idempotency.md)
  - Store InMemory par défaut (StoreInterface)
  - Empêche les envois doublons par id de NotificationMessage
- [Stockage & batch](./categories/storage-batch.md)
  - Driver fichier par défaut (JSONL)
  - Taille de batch configurable, délai par défaut configurable
  - Handler Messenger pour flush des envois arrivés à échéance
- [CLI](../Fr/CLI.md)
  - wrap:notificator:test — envoi de test simple (canal préféré)
  - wrap:notificator:schedule — planifier un envoi (délai, lot)
  - wrap:notificator:flush-pending — traiter les envois stockés arrivés à échéance (ou par lot)
  - wrap:notificator:mercure:send — publication vers un topic Mercure
  - wrap:notificator:mercure:test — diagnostic Mercure
- [Configuration](./categories/configuration.md)
  - async: enabled, transport, retry_limit, backoff_strategy, backoff_initial_ms
  - default_channel et fallback (ordre, max_switches)
  - switch_policy (heures calmes, timezone, règles par canal)
  - channels.email (from, envelope_sender, types MIME, taille, template_engine, transport)
  - channels.sms (dsn string, from, rate_limit)
  - webhook (timeout, statuts retryables)
  - webpush (enabled)
  - mercure (enabled, topic par défaut, turbo_enabled, auto_inject, only_authenticated)
  - logging (canal Monolog et niveau)
  - idempotency (store, ttl)
  - storage (driver, file_path, batch_size, default_delay_seconds)
  - templates (base_path)
- [Fournisseurs SMS](./categories/sms-providers.md)
  - Twilio inclus via DSN (sms+twilio://...) — cf. Configuration
  - Null provider pour dev/tests (sms+null://default)
  - Providers custom via SmsProviderInterface + SmsProviderFactoryInterface
  - Découverte via tag wrap_notificator.sms_provider_factory et SmsDsnResolver
- [Modèle de message](./categories/message-model.md)
  - NotificationMessage: subject, bodyText, bodyHtml, data, recipients, cc, bcc,
    channelPreferred, priority, attachments, tags, metadata, mercureTopics,
    templatePath, templateVars, delaySeconds — id UUID v7 intégré

Références pratiques:
- Vue d'ensemble & configuration: ./README.md
- CLI: ./CLI.md
- Catégories détaillées: ./categories
- Résolution DSN SMS: [SmsDsnResolver](../../src/Infrastructure/Channel/Sms/Dsn/SmsDsnResolver.php), [TwilioSmsProviderFactory](../../src/Infrastructure/Channel/Sms/Dsn/TwilioSmsProviderFactory.php), [NullSmsProviderFactory](../../src/Infrastructure/Channel/Sms/Dsn/NullSmsProviderFactory.php)
