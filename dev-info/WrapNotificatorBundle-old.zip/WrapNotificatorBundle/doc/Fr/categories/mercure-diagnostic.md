# Mercure — Diagnostic

Vérifie si Mercure est installé et correctement configuré, puis publie un message de test.

Commande :
- wrap:notificator:mercure:test — vérifie la configuration et publie une mise à jour de test sur un topic.

Utilisation :
```
php bin/console wrap:notificator:mercure:test [--target=browser|system] [--topic=TOPIC] [--async] [--delay=SECONDS]
```

Options :
- --target, -t : Cible d'affichage : browser (toast dans la page) ou system (notification du système)
- --topic : Topic utilisé pour le test (défaut : wrap_notificator/stream)
- --async, -a : Publier via Messenger (asynchrone). Nécessite un worker.
- --delay, -d : Délai en secondes (avec --async)

Exemples :
- Test simple dans le navigateur :
```
php bin/console wrap:notificator:mercure:test
```
- Test asynchrone avec 10s de retard :
```
php bin/console wrap:notificator:mercure:test --async --delay=10
```
- Test de notification système :
```
php bin/console wrap:notificator:mercure:test --target=system
```

Voir aussi :
- Publication : categories/mercure-publication.md
