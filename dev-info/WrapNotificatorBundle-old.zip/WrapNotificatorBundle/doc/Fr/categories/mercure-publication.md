# Mercure — Publication

Publie un message sur un topic Mercure. Par défaut le payload est JSON ; avec --turbo, publie du Turbo Stream HTML.

Commande :
- wrap:notificator:mercure:send — publie un message sur un topic Mercure (le topic par défaut est configuré dans wrap_notificator.mercure.default_topic).

Utilisation :
```
php bin/console wrap:notificator:mercure:send [message] [--user=ID|--topic=TOPIC] [--json=JSON] [--turbo] [--event=NAME]
```

Arguments :
- message : Texte simple envoyé si --json n'est pas fourni

Options :
- --user : Identifiant utilisateur ; publie sur le topic wrap_notificator/user/{id}
- --topic : Topic explicite (sinon utilise default_topic)
- --json : Payload JSON personnalisé (remplace message)
- --turbo : Publie du Turbo Stream HTML (navigateur)
- --event : Nom d'événement pour styler le contenu Turbo (défaut : custom)

Exemples :
- JSON simple sur le topic par défaut :
```
php bin/console wrap:notificator:mercure:send "Hello!"
```
- Vers un utilisateur spécifique :
```
php bin/console wrap:notificator:mercure:send "Bonjour" --user=42
```
- Payload JSON personnalisé :
```
php bin/console wrap:notificator:mercure:send --json='{"status":"info","message":"Ping"}'
```
- Turbo Stream :
```
php bin/console wrap:notificator:mercure:send "Toast Turbo" --turbo --event=toast
```

Voir aussi :
- Diagnostic : categories/mercure-diagnostic.md
