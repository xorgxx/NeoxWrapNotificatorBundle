# Idempotence (FR)

Le bundle évite les envois doublons grâce à un store d'idempotence. Par défaut: `InMemoryStore`.

Principe:
- Chaque `NotificationMessage` reçoit un `id` (UUID v7) à la création.
- Avant l'envoi, l'orchestrateur vérifie si l'id est déjà présent dans le store.
- Si oui: l'envoi est ignoré (log "Idempotent skip").

Implémentations:
- Par défaut: `InMemoryStore` (volatile)
- Vous pouvez fournir votre implémentation via `StoreInterface` si besoin (Redis, DB...)

Avantages:
- Empêche les doublons lorsque des retries ou des replays se produisent.
