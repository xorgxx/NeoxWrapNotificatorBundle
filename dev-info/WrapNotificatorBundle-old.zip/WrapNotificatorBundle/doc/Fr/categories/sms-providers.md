# Fournisseurs SMS (FR)

Le bundle résout un provider SMS à partir d'un DSN via `SmsDsnResolver` et des factories taguées `wrap_notificator.sms_provider_factory`.

Providers inclus:
- Twilio (schémas: `twilio` ou `sms+twilio`)
- Null (schémas: `null` ou `sms+null`) — utile en dev/tests

Configuration Twilio (exemple):
```dotenv
WRAP_SMS_DSN="sms+twilio://ACCOUNT_SID:AUTH_TOKEN@default?from=%2B33612345678"
```

Créer votre provider:
1. Implémentez `SmsProviderInterface` (méthode `send(string $to, string $message, array $options = [])`).
2. Créez une factory `SmsProviderFactoryInterface` avec `supports(Dsn $dsn)` et `create(Dsn $dsn)`.
3. Déclarez la factory avec le tag `wrap_notificator.sms_provider_factory`.

Astuce: encodez `from` avec `rawurlencode` (`+336...` → `%2B336...`).
