# Vidage

Envoie les notifications stockées qui sont arrivées à échéance, avec possibilité de filtrer par lot et de limiter le nombre traité.

Commande :
- wrap:notificator:flush-pending — vide les notifications dues depuis le stockage via l'asynchrone, avec repli possible en synchrone.

Utilisation :
```
php bin/console wrap:notificator:flush-pending [--limit=N] [--batch-key=KEY]
```

Options :
- --limit : Nombre maximum d'éléments à traiter (défaut : 100)
- --batch-key : Ne vider que le lot spécifié

Exemples :
- Vider toutes les notifications dues :
```
php bin/console wrap:notificator:flush-pending
```
- Vider au plus 50 éléments :
```
php bin/console wrap:notificator:flush-pending --limit=50
```
- Vider uniquement le lot "billing" :
```
php bin/console wrap:notificator:flush-pending --batch-key=billing
```

Voir aussi :
- Planification : categories/planification.md
