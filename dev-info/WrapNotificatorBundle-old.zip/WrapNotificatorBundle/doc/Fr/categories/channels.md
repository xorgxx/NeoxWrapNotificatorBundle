# Canaux pris en charge (FR)

Le bundle fournit des senders pour plusieurs canaux. Choisissez le canal via `NotificationMessage::$channelPreferred` ou laissez le bundle utiliser `default_channel`.

Canaux disponibles:
- Email (basé sur Symfony Mailer)
- SMS (providers via DSN; Twilio inclus)
- Webhook (POST/JSON)
- Webpush (optionnel)
- In‑app (placeholder pour votre application)

Exemple d'envoi email:
```php
use Neox\WrapNotificatorBundle\Domain\Enum\Channel;
use Neox\WrapNotificatorBundle\Domain\Model\NotificationMessage;

$msg = new NotificationMessage(
    subject: 'Bonjour',
    bodyText: 'Texte brut',
    bodyHtml: '<p>HTML</p>',
    recipients: ['user@example.com'],
    channelPreferred: Channel::EMAIL,
);
```

Exemple d'envoi SMS (Twilio via DSN):
```yaml
# .env
WRAP_SMS_DSN="sms+twilio://ACCOUNT_SID:AUTH_TOKEN@default?from=%2B33612345678"
```
```php
use Neox\WrapNotificatorBundle\Domain\Enum\Channel;
use Neox\WrapNotificatorBundle\Domain\Model\NotificationMessage;

$msg = new NotificationMessage(
    bodyText: 'Votre code: 123456',
    recipients: ['+33600000000'],
    channelPreferred: Channel::SMS,
);
```

Webhook rapide:
```yaml
wrap_notificator:
  channels:
    webhook:
      timeout: 10
      retryable_statuses: [429,500,502,503,504]
```

Webpush: activez `webpush.enabled: true` et implémentez le sender si nécessaire.
