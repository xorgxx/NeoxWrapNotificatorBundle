# Orchestration et fallback (FR)

Le bundle choisit le canal à utiliser selon:
- `channelPreferred` du message (prioritaire), sinon `default_channel` de la config
- Une politique de bascule (fallback) si l'envoi échoue

Paramètres clés (wrap_notificator.yaml):
```yaml
wrap_notificator:
  default_channel: email
  fallback:
    order: [sms, webpush, webhook]
    max_switches: 2
```

Exemple: si l'email échoue, tentative sur SMS, puis Webpush, puis Webhook (jusqu'à 2 bascules).

Evénements Mercure (optionnels) publiés pendant l'orchestration: `dispatched`, `sent`, `failed`, `switched`.

Bonnes pratiques:
- Définissez un ordre de fallback réaliste pour vos usages.
- Utilisez un health checker custom si nécessaire (implémentez `ChannelHealthCheckerInterface`).
