# Tests rapides

Catégorie CLI bilingue pour envoyer des notifications de test simples pendant le développement.

Commande :
- wrap:notificator:test — envoie une notification simple via le canal préféré (asynchrone via Messenger).

Utilisation :
```
php bin/console wrap:notificator:test <to> [channel]
```

Arguments :
- to : Email ou téléphone du destinataire
- channel : Canal préféré : email|sms|webhook|webpush (défaut : email)

Exemples :
- Email :
```
php bin/console wrap:notificator:test user@example.org email
```
- SMS :
```
php bin/console wrap:notificator:test "+33611223344" sms
```

Voir aussi :
- Planification : categories/planification.md
- Vidage : categories/vidage.md
- Mercure : categories/mercure-publication.md, categories/mercure-diagnostic.md
