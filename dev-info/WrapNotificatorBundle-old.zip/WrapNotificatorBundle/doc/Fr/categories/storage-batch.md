# Stockage différé et envoi par lot (FR)

Permet de stocker temporairement des notifications et de les envoyer plus tard (batch).

Configuration par défaut:
```yaml
wrap_notificator:
  storage:
    enabled: true
    driver: file
    file_path: '%kernel.project_dir%/var/wrap_notificator/pending.jsonl'
    batch_size: 100
    default_delay_seconds: 0
```

Utilisation typique:
- Planifiez via CLI: `wrap:notificator:schedule` avec `--batch-key=...`
- Flushez plus tard: `wrap:notificator:flush-pending --batch-key=...`

Le handler Messenger `FlushDueNotificationsHandler` traite les envois arrivés à échéance.

Avantages:
- Lissage de charge
- Regroupement logique par batch
