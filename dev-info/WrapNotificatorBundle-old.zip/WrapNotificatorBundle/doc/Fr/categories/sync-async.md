# Envoi synchrone et asynchrone (FR)

Deux modes d'envoi sont disponibles:

- Synchrone: utile pour un retour immédiat. Utilisez `NotificatorInterface->send($message)`.
- Asynchrone (recommandé): passe par Messenger, gère les retries, backoff, et `delaySeconds`. Recommandé: définissez `$message->async = true` puis appelez `NotificatorInterface->send($message)`.

Exemple asynchrone avec délai:
```php
use Neox\WrapNotificatorBundle\Application\NotificatorInterface;
use Neox\WrapNotificatorBundle\Domain\Model\NotificationMessage;

public function send(NotificatorInterface $notificator): void
{
    $msg = (new NotificationMessage(
        subject: 'Promo',
        bodyText: 'Offre -20%',
        recipients: ['user@example.com']
    ))->withDelaySeconds(60);

    $msg->async = true;          // recommande: async via Messenger
    $notificator->send($msg);    // envoie (sera dispatché sur Messenger)
}
```

Configuration minimale Messenger:
```yaml
framework:
  messenger:
    transports:
      async: '%env(MESSENGER_TRANSPORT_DSN)%'
    routing:
      'Neox\\WrapNotificatorBundle\\Infrastructure\\Messenger\\Message\\AsyncNotificationMessage': async
```

Note avancée: `AsyncNotificator` existe toujours pour les usages bas niveau, mais l'API publique recommandée est `NotificatorInterface`.

Astuce: fixez `retry_limit` et `backoff_strategy` dans `wrap_notificator.async` pour harmoniser avec Messenger.
