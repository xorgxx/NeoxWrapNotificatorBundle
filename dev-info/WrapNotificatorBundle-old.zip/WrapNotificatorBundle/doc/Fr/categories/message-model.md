# Modèle de message (FR)

La classe `NotificationMessage` contient toutes les informations nécessaires pour un envoi.

Champs principaux:
- `subject`, `bodyText`, `bodyHtml`
- `recipients`, `cc`, `bcc`
- `channelPreferred` (enum `Channel`)
- `priority`, `attachments`, `tags`, `metadata`
- `mercureTopics`
- `templatePath`, `templateVars`
- `delaySeconds`
- `id` (UUID v7 auto-généré)

Exemple:
```php
use Neox\WrapNotificatorBundle\Domain\Enum\Channel;
use Neox\WrapNotificatorBundle\Domain\Model\NotificationMessage;

$msg = new NotificationMessage(
    subject: 'Bienvenue',
    bodyText: 'Hello',
    recipients: ['user@example.com'],
    channelPreferred: Channel::EMAIL,
    tags: ['welcome', 'marketing'],
);
```

Alternative: constructeur vide + propriétés
```php
use Neox\WrapNotificatorBundle\Domain\Enum\Channel;
use Neox\WrapNotificatorBundle\Domain\Model\NotificationMessage;

$msg = new NotificationMessage();
$msg->subject = 'Bienvenue';
$msg->bodyText = 'Bonjour et bienvenue !';
$msg->recipients = ['user@example.com'];
$msg->channelPreferred = Channel::EMAIL;
```
