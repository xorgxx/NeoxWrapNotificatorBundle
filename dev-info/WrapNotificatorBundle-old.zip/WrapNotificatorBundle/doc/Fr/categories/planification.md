# Planification

Planifie ou met en file une notification pour un envoi différé ou par lot.

Commande :
- wrap:notificator:schedule — enregistre un message avec canal préféré, délai optionnel et clé de lot optionnelle.

Utilisation :
```
php bin/console wrap:notificator:schedule <to> [--channel=...] [--delay=SECONDS] [--batch-key=KEY]
```

Arguments :
- to : Destinataire (email ou téléphone)

Options :
- --channel : email|sms|webhook|webpush (défaut : email)
- --delay : Délai en secondes avant éligibilité (défaut : 0)
- --batch-key : Clé de lot (facultatif) pour regroupement

Exemples :
- Planifier un email dans 5 minutes :
```
php bin/console wrap:notificator:schedule user@example.org --channel=email --delay=300
```
- Enregistrer un SMS dans un lot "billing" :
```
php bin/console wrap:notificator:schedule "+33611223344" --channel=sms --batch-key=billing
```

Voir aussi :
- Vidage : categories/vidage.md
