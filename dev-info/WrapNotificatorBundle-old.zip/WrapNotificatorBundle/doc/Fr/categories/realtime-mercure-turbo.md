# Diffusion temps réel (Mercure/Turbo) — FR

Activez la publication d'événements et, si souhaité, l'injection automatique Turbo Streams dans vos pages HTML. Le bundle expose aussi des fonctions Twig pour consommer le hub Mercure côté navigateur, avec deux modes d'affichage distincts.

## Configuration de base
```yaml
wrap_notificator:
  mercure:
    enabled: true
    public_url: '%env(MERCURE_PUBLIC_URL)%' # peut être auto‑détecté côté client
    default_topic: 'wrap_notificator/stream' # au navigateur !!
    turbo_enabled: true
    auto_inject: true
    only_authenticated: false
```

Astuce: le client peut détecter seul l'URL du hub via `<link rel="mercure" href="…">`, `<meta name="mercure-hub" content="…">` ou `window.MERCURE_PUBLIC_URL`.

## Injection automatique (serveur)
- Le listener `AutoTurboInjectorListener` peut injecter un snippet Turbo pour écouter les événements internes du bundle et afficher des contenus Turbo Streams.
- Fonctionne uniquement pour les réponses HTML et, si `only_authenticated: true`, pour les utilisateurs connectés.

## Fonctions Twig côté client
Ajoutez ces appels UNE SEULE FOIS dans votre layout (dans `<body>`), de préférence en haut de page :

```twig
{{ wrap_notify_bootstrap() }}
{{ neox_notify_browser() }}            {# toasts en page + Turbo Streams #}
{{ neox_notify_system(topics=['alerts:ops']) }} {# notifications natives OS #}
```

- `wrap_notify_bootstrap()` injecte le conteneur, le CSS et le JS minimal pour afficher des toasts modernes. Si SweetAlert (Swal) est présent, un toast Swal est utilisé (avec z-index élevé), sinon un fallback custom est rendu.
- `neox_notify_browser(topics = [default])` ouvre un EventSource vers le hub Mercure, auto‑détecte le hub si possible, traite les Turbo Streams (`Turbo.renderStreamMessage`) et affiche des toasts pour tout payload JSON/JSON‑LD. Si aucun topic n'est fourni, il écoute `wrap_notificator/stream`.
- `neox_notify_system(topics = [])` ouvre un EventSource et affiche des notifications natives via l'API Web Notifications (Windows/macOS/Linux). Si l'API est indisponible ou refusée, retombe sur les toasts en page. Cette fonction ignore les Turbo Streams (pas d'effet DOM).

### Conseils d'abonnement aux topics
- Évitez d'écouter les mêmes topics avec `neox_notify_browser` et `neox_notify_system` simultanément pour ne pas dupliquer l'affichage.
- Si vous fournissez des topics personnalisés, `neox_notify_browser` écoute aussi le topic par défaut afin de recevoir les Turbo Streams liés au bundle.

### Gestion des Turbo Streams
- Les événements Turbo sont publiés sur le topic par défaut (`wrap_notificator/stream`) via le `MercurePublisher`.
- Côté client, le `<turbo-stream>` reçu est passé à `Turbo.renderStreamMessage(...)` si Turbo est chargé; sinon, l'élément est placé dans un holder et pourra être traité plus tard lorsque Turbo sera disponible.

### Z-index et visibilité
- Le conteneur des toasts utilise un z-index maximal (`2147483647`) pour rester visible au‑dessus de l'UI. Pour SweetAlert, `zIndex` est également défini.

### Exemple de publication côté serveur
```php
$publisher->publish('demo', [
    'title' => 'Hello',
    'message' => 'World',
    'level' => 'success',
]);
```

### Dépannage
- La connexion SSE est ouverte mais rien ne s'affiche : vérifiez que Turbo est chargé pour le rendu des streams, et que le conteneur `#wrap-notificator-stream` est présent (injecté par `wrap_notify_bootstrap()`).
- Payloads JSON‑LD : un toast générique s'affiche même sans `title/message/level`.
- URL du hub manquante : exposez un `<link rel="mercure">` ou définissez `MERCURE_PUBLIC_URL`.
