# Interface en ligne de commande (FR)

Voir toutes les fonctionnalités du bundle: [FEATURES.md](FEATURES.md)

Cette page résume les commandes Symfony Console fournies par WrapNotificatorBundle, avec des exemples prêts à copier/coller.

Astuce: lancez toute commande avec -h pour afficher l'aide bilingue (options et exemples).

Aperçu des commandes:
- wrap:notificator:test — Envoie une notification de test via le canal préféré (asynchrone via Messenger).
- wrap:notificator:schedule — Enregistre/planifie une notification pour envoi ultérieur ou par lot.
- wrap:notificator:flush-pending — Envoie les notifications stockées arrivées à échéance (ou d'un lot donné).
- wrap:notificator:mercure:send — Publie un message sur un topic Mercure (JSON ou Turbo Stream).
- wrap:notificator:mercure:test — Diagnostique la configuration Mercure et publie un message de test.

Exemples:

Notification de test (rapide):
```bash
php bin/console wrap:notificator:test user@example.org email
php bin/console wrap:notificator:test "+33611223344" sms
```

Planifier et vider:
```bash
# Planifier un email avec 5 minutes de délai
php bin/console wrap:notificator:schedule user@example.org --channel=email --delay=300

# Enregistrer un SMS dans un lot "billing"
php bin/console wrap:notificator:schedule "+33611223344" --channel=sms --batch-key=billing

# Vider toutes les notifications dues (ou seulement un lot)
php bin/console wrap:notificator:flush-pending
php bin/console wrap:notificator:flush-pending --batch-key=billing --limit=50
```

Mercure (temps réel):
```bash
# Publier du JSON simple sur le topic par défaut
php bin/console wrap:notificator:mercure:send "Hello!"

# Publier vers un utilisateur spécifique
php bin/console wrap:notificator:mercure:send "Bonjour" --user=42

# Payload JSON personnalisé
php bin/console wrap:notificator:mercure:send --json='{"status":"info","message":"Ping"}'

# Turbo Stream pour l'affichage dans le navigateur
php bin/console wrap:notificator:mercure:send "Toast Turbo" --turbo --event=toast

# Diagnostic Mercure (optionnellement async avec délai)
php bin/console wrap:notificator:mercure:test
php bin/console wrap:notificator:mercure:test --async --delay=10
```

Catégories associées:
- Tests rapides: [categories/tests-rapides.md](categories/tests-rapides.md)
- Planification: [categories/planification.md](categories/planification.md)
- Vidage: [categories/vidage.md](categories/vidage.md)
- Publication Mercure: [categories/mercure-publication.md](categories/mercure-publication.md)
- Diagnostic Mercure: [categories/mercure-diagnostic.md](categories/mercure-diagnostic.md)

Voir aussi toutes les fonctionnalités: [FEATURES.md](FEATURES.md)
