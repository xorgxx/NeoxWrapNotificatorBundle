# Wrap Notificator — Documentation (FR)

Bienvenue dans la documentation française du bundle Wrap Notificator (WARPP). Cette section explique clairement le fonctionnement, la configuration et l'utilisation du bundle, avec des exemples simples mais détaillés, y compris les commandes CLI.

Sections principales:
- 1. Aperçu rapide et principe
- 2. Installation et Configuration minimale
- 3. Exemples d'utilisation (sync/async)
- 4. CLI (Commandes et exemples)
- 5. Aller plus loin

---

## 1. Aperçu rapide et principe
- Vous créez un `NotificationMessage` (sujet, texte/HTML, destinataires, canal préféré, options).
- Vous l'envoyez via:
  - Asynchrone (recommandé): définissez `$message->async = true` puis `NotificatorInterface->send($message)` (via Messenger)
  - Synchrone: `NotificatorInterface->send($message)`
- Le bundle choisit le canal (préféré ou par défaut) et applique un fallback si nécessaire.

Canaux: email, SMS, webhook, webpush, in‑app. Diffusion temps réel: Mercure (et Turbo Streams en option).

---

## 2. Installation et Configuration minimale
1) Installez et configurez Symfony Messenger (transport selon votre projet).
2) Configurez le bundle (extrait minimal):

```yaml
# config/packages/wrap_notificator.yaml
wrap_notificator:
  enabled: true
  async:
    enabled: true
    transport: '%env(MESSENGER_TRANSPORT_DSN)%'
  default_channel: email
  channels:
    email:
      from: no-reply@example.com
    sms:
      dsn: '%env(WRAP_SMS_DSN)%' # ex: sms+twilio://ACCOUNT_SID:AUTH_TOKEN@default?from=%2B33612345678
```

Dans votre .env:
```dotenv
WRAP_SMS_DSN="sms+twilio://ACCOUNT_SID:AUTH_TOKEN@default?from=%2B33612345678"
```

Remarque: `wrap_notificator.channels.sms.dsn` doit être une chaîne (string), pas un tableau.

---

## 3. Exemples d'utilisation (sync/async)

### 3.1 Envoi asynchrone (recommandé)
```php
use Neox\WrapNotificatorBundle\Application\NotificatorInterface;
use Neox\WrapNotificatorBundle\Domain\Enum\Channel;
use Neox\WrapNotificatorBundle\Domain\Model\NotificationMessage;

public function sendWelcome(NotificatorInterface $notificator): void
{
    $msg = new NotificationMessage(
        subject: 'Bienvenue',
        bodyText: 'Bonjour et bienvenue !',
        recipients: ['user@example.com'],
        channelPreferred: Channel::EMAIL,
    );

    $msg->async = true;           // envoie via Messenger
    $notificator->send($msg);
}
```

### 3.2 Envoi synchrone
```php
use Neox\WrapNotificatorBundle\Application\NotificatorInterface;
use Neox\WrapNotificatorBundle\Domain\Enum\Channel;
use Neox\WrapNotificatorBundle\Domain\Model\NotificationMessage;

public function sendNow(NotificatorInterface $notificator): void
{
    $msg = new NotificationMessage(
        subject: 'Code',
        bodyText: 'Votre code: 123456',
        recipients: ['+33600000000'],
        channelPreferred: Channel::SMS,
    );

    $notificator->send($msg);
}
```

### 3.3 Variante: constructeur vide + propriétés
```php
use Neox\WrapNotificatorBundle\Domain\Enum\Channel;
use Neox\WrapNotificatorBundle\Domain\Model\NotificationMessage;

$msg = new NotificationMessage();
$msg->subject = 'Bienvenue';
$msg->bodyText = 'Bonjour et bienvenue !';
$msg->recipients = ['user@example.com'];
$msg->channelPreferred = Channel::EMAIL;

```

---

## 4. CLI (Commandes et exemples)
Voir aussi: CLI.md pour le détail complet.

Commandes utiles (exemples):

```bash
# Test rapide (envoi simple via le canal préféré)
php bin/console wrap:notificator:test user@example.org email

# Planifier une notification avec délai et clé de lot
php bin/console wrap:notificator:schedule user@example.org --channel=email --delay=60 --batch-key=promo

# Vider les notifications dues ou par lot
php bin/console wrap:notificator:flush-pending --limit=50

# Mercure — publication et diagnostic
php bin/console wrap:notificator:mercure:send "Hello" --user=42
php bin/console wrap:notificator:mercure:test --async --delay=5
```

---

## 5. Aller plus loin
- Toutes les fonctionnalités: [FEATURES.md](FEATURES.md)
- Catégories détaillées: dossier [categories/](categories)
- Configuration avancée: taux de retry/backoff, fallback entre canaux, webpush, webhook.
- Fournisseurs SMS: Twilio via DSN; provider personnalisé via `SmsProviderInterface` + `SmsProviderFactoryInterface` (tag `wrap_notificator.sms_provider_factory`).
- Journalisation: canal Monolog `wrap_notificator`.

---

## 6. Temps réel (Mercure/Turbo) et notifications

Le bundle propose deux fonctions Twig côté client, en complément du publisher Mercure intégré:

```twig
{{ wrap_notify_bootstrap() }}                       {# conteneur + CSS/JS toasts #}
{{ stream_notifications() }}                        {# toasts en page + Turbo Streams #}
{{ neox_notify(topics=['alerts:ops', 'news:global']) }} {# notifications natives OS #}
```

- `stream_notifications(topics = [default])` : ouvre un EventSource vers le hub Mercure, auto‑détecte l'URL du hub (link rel="mercure", meta, window.MERCURE_PUBLIC_URL, param serveur), rend les `<turbo-stream>` via `Turbo.renderStreamMessage`, et affiche un toast pour tout payload JSON/JSON‑LD reçu.
- `neox_notify(topics = [])` : affiche des notifications natives (Windows/macOS/Linux) via l'API Web Notifications. En cas de refus/indisponibilité, bascule en toast en page. Ignore les Turbo Streams.
- `wrap_notify_bootstrap()` : injecte le conteneur, le CSS et le JS nécessaires ; z-index maximisé pour éviter les masquages ; support SweetAlert (Swal) si présent.

Conseils :
- Évitez d'abonner les deux fonctions aux mêmes topics pour prévenir les doublons.
- Si vous ne fournissez pas de topics à `stream_notifications`, le topic par défaut `wrap_notificator/stream` est utilisé (pour les Turbo Streams du bundle).

Plus d'infos: [categories/realtime-mercure-turbo.md](categories/realtime-mercure-turbo.md)

Documentation complète (FR): ce dossier.
Version anglaise: ../En/README.md
