# Wrap Notificator — Documentation (EN)

Welcome to the English documentation of the Wrap Notificator bundle (WARPP). This section explains how it works, how to configure it, and how to use it with practical examples, including CLI commands.

Main sections:
- 1. Quick overview & principles
- 2. Installation & Minimal configuration
- 3. Usage examples (sync/async)
- 4. CLI (Commands & examples)
- 5. Going further
- 6. Real‑time (Mercure/Turbo) & notifications

---

## 1. Quick overview & principles
- You create a `NotificationMessage` (subject, text/HTML, recipients, preferred channel, options).
- You send it via:
  - Asynchronous (recommended): set `$message->async = true` then `NotificatorInterface->send($message)` (Messenger)
  - Synchronous: `NotificatorInterface->send($message)`
- The bundle selects the channel (preferred or default) and applies fallback if necessary.

Channels: email, SMS, webhook, webpush, in‑app. Real‑time broadcasting: Mercure (optional Turbo Streams).

---

## 2. Installation & Minimal configuration
1) Install and configure Symfony Messenger (transport according to your project).
2) Configure the bundle (minimal excerpt):

```yaml
# config/packages/wrap_notificator.yaml
wrap_notificator:
  enabled: true
  async:
    enabled: true
    transport: '%env(MESSENGER_TRANSPORT_DSN)%'
  default_channel: email
  channels:
    email:
      from: no-reply@example.com
    sms:
      dsn: '%env(WRAP_SMS_DSN)%' # e.g. sms+twilio://ACCOUNT_SID:AUTH_TOKEN@default?from=%2B33612345678
```

In your .env:
```dotenv
WRAP_SMS_DSN="sms+twilio://ACCOUNT_SID:AUTH_TOKEN@default?from=%2B33612345678"
```

Note: `wrap_notificator.channels.sms.dsn` must be a string, not an array.

---

## 3. Usage examples (sync/async)

### 3.1 Asynchronous send (recommended)
```php
use Neox\WrapNotificatorBundle\Application\NotificatorInterface;
use Neox\WrapNotificatorBundle\Domain\Enum\Channel;
use Neox\WrapNotificatorBundle\Domain\Model\NotificationMessage;

public function sendWelcome(NotificatorInterface $notificator): void
{
    $msg = new NotificationMessage(
        subject: 'Welcome',
        bodyText: 'Hello and welcome!',
        recipients: ['user@example.com'],
        channelPreferred: Channel::EMAIL,
    );

    $msg->async = true;           // send via Messenger
    $notificator->send($msg);
}
```

### 3.2 Synchronous send
```php
use Neox\WrapNotificatorBundle\Application\NotificatorInterface;
use Neox\WrapNotificatorBundle\Domain\Enum\Channel;
use Neox\WrapNotificatorBundle\Domain\Model\NotificationMessage;

public function sendNow(NotificatorInterface $notificator): void
{
    $msg = new NotificationMessage(
        subject: 'Code',
        bodyText: 'Your code: 123456',
        recipients: ['+33600000000'],
        channelPreferred: Channel::SMS,
    );

    $notificator->send($msg);
}
```

### 3.3 Variant: empty constructor + properties
```php
use Neox\WrapNotificatorBundle\Domain\Enum\Channel;
use Neox\WrapNotificatorBundle\Domain\Model\NotificationMessage;

$msg = new NotificationMessage();
$msg->subject = 'Welcome';
$msg->bodyText = 'Hello and welcome!';
$msg->recipients = ['user@example.com'];
$msg->channelPreferred = Channel::EMAIL;

// Optional: async delay at Messenger level
$msg = $msg->withDelaySeconds(30);
```

---

## 4. CLI (Commands & examples)
See also: CLI.md for full details.

Useful commands (examples):

```bash
# Quick test (send a simple message via preferred channel)
php bin/console wrap:notificator:test user@example.org email

# Schedule a notification with delay and optional batch
php bin/console wrap:notificator:schedule user@example.org --channel=email --delay=60 --batch-key=promo

# Flush due or batched notifications
php bin/console wrap:notificator:flush-pending --limit=50

# Mercure — publish and diagnostics
php bin/console wrap:notificator:mercure:send "Hello" --user=42
php bin/console wrap:notificator:mercure:test --async --delay=5
```

---

## 5. Going further
- All features: [FEATURES.md](FEATURES.md)
- Detailed categories: [categories/](categories)
- Advanced configuration: retry/backoff, cross‑channel fallback, webpush, webhook.
- SMS providers: Twilio via DSN; custom provider via `SmsProviderInterface` + `SmsProviderFactoryInterface` (tag `wrap_notificator.sms_provider_factory`).
- Logging: Monolog channel `wrap_notificator`.

---

## 6. Real‑time (Mercure/Turbo) & notifications

The bundle provides two Twig functions on the client side, in addition to the integrated Mercure publisher:

```twig
{{ wrap_notify_bootstrap() }}                       {# container + CSS/JS toasts #}
{{ stream_notifications() }}                        {# in‑page toasts + Turbo Streams #}
{{ neox_notify(topics=['alerts:ops', 'news:global']) }} {# native OS notifications #}
```

- `stream_notifications(topics = [default])`: opens an EventSource to the Mercure hub, auto‑detects the hub URL (link rel="mercure", meta, window.MERCURE_PUBLIC_URL, server param), renders `<turbo-stream>` via `Turbo.renderStreamMessage`, and shows a toast for any JSON/JSON‑LD payload.
- `neox_notify(topics = [])`: shows native OS notifications (Windows/macOS/Linux) via the Web Notifications API. If unavailable/denied, falls back to in‑page toast. Ignores Turbo Streams.
- `wrap_notify_bootstrap()`: injects the container, CSS and minimal JS; maximized z‑index to avoid being hidden; uses SweetAlert (Swal) toasts if available, otherwise a modern custom fallback.

Tips:
- Avoid subscribing both functions to the same topics to prevent duplicates.
- If you don’t pass topics to `stream_notifications`, the default topic `wrap_notificator/stream` is used (for bundle Turbo Streams).

More info: [categories/realtime-mercure-turbo.md](categories/realtime-mercure-turbo.md)
