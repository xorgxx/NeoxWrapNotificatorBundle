# All bundle features (EN)

This page gathers, in one place, all the features provided by WrapNotificatorBundle. For each category, a detailed page is available in doc/En/categories/.

Quick access to categories:
- [Channels](./categories/channels.md)
  - Email (Mailer) — Twig templates, attachments, CC/BCC, HTML/TXT
  - SMS — Providers via DSN (built‑in Twilio), custom provider via interfaces
  - Webhook — POST/JSON with timeouts and retryable statuses
  - Webpush — Optional activation
  - In‑app — Placeholder (per app integration), via Channel enum and dedicated sender
- [Sync/Async](./categories/sync-async.md)
  - Sync: NotificatorInterface->send(NotificationMessage)
  - Async: set `$message->async = true` then `NotificatorInterface->send($message)` (Messenger)
  - Scheduled delay via NotificationMessage->withDelaySeconds()
  - Retries/Backoff configurable via Messenger and bundle config
- [Orchestration & fallback](./categories/orchestration-fallback.md)
  - Configurable default channel
  - Fallback order and max switches (max_switches)
  - Switch policy (DefaultSwitchPolicy)
  - Channel health checker (SimpleChannelHealthChecker, extensible)
- [Real‑time (Mercure/Turbo)](./categories/realtime-mercure-turbo.md)
  - Integrated Mercure publisher (events: dispatched, sent, failed, switched)
  - Optional server‑side Turbo Streams injection listener
  - Turbo Streams compatibility
- [Idempotency](./categories/idempotency.md)
  - InMemory store by default (StoreInterface)
  - Prevents duplicate sends by NotificationMessage id
- [Storage & batch](./categories/storage-batch.md)
  - File driver by default (JSONL)
  - Configurable batch size and default delay
  - Messenger handler to flush due notifications
- [CLI](../En/CLI.md)
  - wrap:notificator:test — quick test send (preferred channel)
  - wrap:notificator:schedule — schedule a send (delay, batch)
  - wrap:notificator:flush-pending — flush stored due notifications (or by batch)
  - wrap:notificator:mercure:send — publish to a Mercure topic
  - wrap:notificator:mercure:test — Mercure diagnostics
- [Configuration](./categories/configuration.md)
  - async: enabled, transport, retry_limit, backoff_strategy, backoff_initial_ms
  - default_channel and fallback (order, max_switches)
  - switch_policy (quiet hours, timezone, channel rules)
  - channels.email (from, envelope_sender, MIME types, size, template_engine, transport)
  - channels.sms (dsn string, from, rate_limit)
  - webhook (timeout, retryable statuses)
  - webpush (enabled)
  - mercure (enabled, default_topic, turbo_enabled, auto_inject, only_authenticated, optional public_url)
  - logging (Monolog channel and level)
  - idempotency (store, ttl)
  - storage (driver, file_path, batch_size, default_delay_seconds)
  - templates (base_path)
- [SMS providers](./categories/sms-providers.md)
  - Twilio via DSN (sms+twilio://...) — see Configuration
  - Null provider for dev/tests (sms+null://default)
  - Custom providers via SmsProviderInterface + SmsProviderFactoryInterface
  - Discovery via tag wrap_notificator.sms_provider_factory and SmsDsnResolver
- [Message model](./categories/message-model.md)
  - NotificationMessage: subject, bodyText, bodyHtml, data, recipients, cc, bcc,
    channelPreferred, priority, attachments, tags, metadata, mercureTopics,
    templatePath, templateVars, delaySeconds — built‑in UUID v7 id
