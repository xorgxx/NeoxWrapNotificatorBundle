# Command‑line interface (EN)

See all bundle features: [FEATURES.md](FEATURES.md)

This page summarizes the available Symfony Console commands provided by WrapNotificatorBundle, with quick examples you can copy/paste.

Tip: run any command with -h to read the full bilingual help with options and examples.

Commands overview:
- wrap:notificator:test — Send a simple test notification via the preferred channel (async via Messenger).
- wrap:notificator:schedule — Store a notification to be sent later or grouped in a batch.
- wrap:notificator:flush-pending — Flush due or batched stored notifications.
- wrap:notificator:mercure:send — Publish a message to a Mercure topic (JSON or Turbo Stream).
- wrap:notificator:mercure:test — Diagnose Mercure configuration and publish a probe message.

Examples:

Test notification (quick test):
```bash
php bin/console wrap:notificator:test user@example.org email
php bin/console wrap:notificator:test "+15551234567" sms
```

Schedule and flush:
```bash
# Schedule an email with a 5-minute delay
php bin/console wrap:notificator:schedule user@example.org --channel=email --delay=300

# Enqueue an SMS in a "billing" batch
php bin/console wrap:notificator:schedule "+15551234567" --channel=sms --batch-key=billing

# Flush all due notifications (or only a batch)
php bin/console wrap:notificator:flush-pending
php bin/console wrap:notificator:flush-pending --batch-key=billing --limit=50
```

Mercure (real‑time):
```bash
# Publish simple JSON to default topic
php bin/console wrap:notificator:mercure:send "Hello!"

# Publish to a specific user topic
php bin/console wrap:notificator:mercure:send "Hi" --user=42

# Custom JSON payload
php bin/console wrap:notificator:mercure:send --json='{"status":"info","message":"Ping"}'

# Turbo Stream for in‑page browser UI
php bin/console wrap:notificator:mercure:send "Turbo Toast" --turbo --event=toast

# Mercure diagnostics (optionally async with delay)
php bin/console wrap:notificator:mercure:test
php bin/console wrap:notificator:mercure:test --async --delay=10
```

Related categories:
- Quick tests: [categories/quick-tests.md](categories/quick-tests.md)
- Scheduling: [categories/scheduling.md](categories/scheduling.md)
- Flushing: [categories/flushing.md](categories/flushing.md)
- Mercure publishing: [categories/mercure-publishing.md](categories/mercure-publishing.md)
- Mercure diagnostics: [categories/mercure-diagnostics.md](categories/mercure-diagnostics.md)

See also all bundle features: [FEATURES.md](FEATURES.md)
