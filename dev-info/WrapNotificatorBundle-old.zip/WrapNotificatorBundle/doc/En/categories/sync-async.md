# Synchronous vs Asynchronous (EN)

Two sending modes:

- Synchronous: immediate result. Use `NotificatorInterface->send($message)`.
- Asynchronous (recommended): goes through Messenger, handles retries/backoff and `delaySeconds`. Recommended: set `$message->async = true` then call `NotificatorInterface->send($message)`.

Async example with delay:
```php
use Neox\WrapNotificatorBundle\Application\NotificatorInterface;
use Neox\WrapNotificatorBundle\Domain\Model\NotificationMessage;

public function send(NotificatorInterface $notificator): void
{
    $msg = (new NotificationMessage(
        subject: 'Promo',
        bodyText: '20% off',
        recipients: ['user@example.com']
    ))->withDelaySeconds(60);

    $msg->async = true;          // recommended: async via Messenger
    $notificator->send($msg);    // will be dispatched to Messenger
}
```

Minimal Messenger config:
```yaml
framework:
  messenger:
    transports:
      async: '%env(MESSENGER_TRANSPORT_DSN)%'
    routing:
      'Neox\\WrapNotificatorBundle\\Infrastructure\\Messenger\\Message\\AsyncNotificationMessage': async
```

Advanced note: `AsyncNotificator` still exists for low-level use cases, but the recommended public API is `NotificatorInterface`.

Tip: set `retry_limit` and `backoff_strategy` under `wrap_notificator.async` to align with Messenger.
