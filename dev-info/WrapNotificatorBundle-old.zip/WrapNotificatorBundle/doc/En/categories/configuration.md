# Rich configuration (EN)

Overview of key `wrap_notificator` options:

```yaml
wrap_notificator:
  enabled: true
  async:
    enabled: true
    transport: '%env(MESSENGER_TRANSPORT_DSN)%'
    retry_limit: 7
    backoff_strategy: exponential
    backoff_initial_ms: 500
  default_channel: email
  fallback:
    order: [sms, webpush, webhook]
    max_switches: 2
  switch_policy:
    quiet_hours: '00:00-06:00'
    timezone: 'UTC'
    channel_rules: {}
  channels:
    email:
      from: null
      envelope_sender: null
      allowed_mime_types: ['application/pdf','image/png','image/jpeg','text/plain']
      max_total_size_mb: 10
      template_engine: twig
      transport: null
    sms:
      dsn: '%env(WRAP_SMS_DSN)%'
      from: null
      rate_limit_per_minute: 60
    webhook:
      timeout: 10
      retryable_statuses: [429,500,502,503,504]
    webpush:
      enabled: false
  mercure:
    enabled: false
    default_topic: 'wrap_notificator/stream'
    turbo_enabled: true
    auto_inject: true
    only_authenticated: true
  logging:
    channel: wrap_notificator
    level: info
  idempotency:
    store: in_memory
    ttl_seconds: 86400
  storage:
    enabled: true
    driver: file
    file_path: '%kernel.project_dir%/var/wrap_notificator/pending.jsonl'
    batch_size: 100
    default_delay_seconds: 0
  templates:
    base_path: '%kernel.project_dir%/bundle/WrapNotificatorBundle/Templates'
```

Important note (SMS): `channels.sms.dsn` must be a string.
