# Quick tests

Bilingual CLI category for sending simple probe notifications during development.

Command:
- wrap:notificator:test — send a simple notification using the preferred channel (asynchronous via Messenger).

Usage:
```
php bin/console wrap:notificator:test <to> [channel]
```

Arguments:
- to: Recipient email or phone number
- channel: Preferred channel: email|sms|webhook|webpush (default: email)

Examples:
- Email:
```
php bin/console wrap:notificator:test user@example.org email
```
- SMS:
```
php bin/console wrap:notificator:test "+15551234567" sms
```

See also:
- Scheduling: categories/scheduling.md
- Flushing: categories/flushing.md
- Mercure: categories/mercure-publishing.md, categories/mercure-diagnostics.md
