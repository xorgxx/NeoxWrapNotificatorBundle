# Mercure publishing

Send messages to a Mercure hub topic. By default the payload is JSON; with --turbo, publish Turbo Stream HTML.

Command:
- wrap:notificator:mercure:send — publish a message to a Mercure topic (default topic is configured in wrap_notificator.mercure.default_topic).

Usage:
```
php bin/console wrap:notificator:mercure:send [message] [--user=ID|--topic=TOPIC] [--json=JSON] [--turbo] [--event=NAME]
```

Arguments:
- message: Plain text sent if --json is not provided

Options:
- --user: User identifier; publishes to topic wrap_notificator/user/{id}
- --topic: Explicit topic (otherwise uses default_topic)
- --json: Custom JSON payload (overrides message)
- --turbo: Publish Turbo Stream HTML (browser)
- --event: Event name to style the Turbo content (default: custom)

Examples:
- Simple JSON on default topic:
```
php bin/console wrap:notificator:mercure:send "Hello!"
```
- To a specific user:
```
php bin/console wrap:notificator:mercure:send "Hi" --user=42
```
- Custom JSON payload:
```
php bin/console wrap:notificator:mercure:send --json='{"status":"info","message":"Ping"}'
```
- Turbo Stream:
```
php bin/console wrap:notificator:mercure:send "Turbo Toast" --turbo --event=toast
```

See also:
- Diagnostics: categories/mercure-diagnostics.md
