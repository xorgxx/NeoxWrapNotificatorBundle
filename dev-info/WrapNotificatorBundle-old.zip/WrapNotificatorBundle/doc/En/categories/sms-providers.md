# SMS providers (EN)

The bundle resolves an SMS provider from a DSN using `SmsDsnResolver` and factories tagged with `wrap_notificator.sms_provider_factory`.

Included providers:
- Twilio (schemes: `twilio` or `sms+twilio`)
- Null (schemes: `null` or `sms+null`) — useful in dev/tests

Twilio configuration (example):
```dotenv
WRAP_SMS_DSN="sms+twilio://ACCOUNT_SID:AUTH_TOKEN@default?from=%2B15551234567"
```

Create your provider:
1. Implement `SmsProviderInterface` (`send(string $to, string $message, array $options = [])`).
2. Create a `SmsProviderFactoryInterface` with `supports(Dsn $dsn)` and `create(Dsn $dsn)`.
3. Register the factory with tag `wrap_notificator.sms_provider_factory`.

Tip: URL-encode `from` (`+1555...` → `%2B1555...`).
