# Message model (EN)

The `NotificationMessage` class holds all fields required for sending.

Main fields:
- `subject`, `bodyText`, `bodyHtml`
- `recipients`, `cc`, `bcc`
- `channelPreferred` (enum `Channel`)
- `priority`, `attachments`, `tags`, `metadata`
- `mercureTopics`
- `templatePath`, `templateVars`
- `delaySeconds`
- `id` (auto-generated UUID v7)

Example:
```php
use Neox\WrapNotificatorBundle\Domain\Enum\Channel;
use Neox\WrapNotificatorBundle\Domain\Model\NotificationMessage;

$msg = new NotificationMessage(
    subject: 'Welcome',
    bodyText: 'Hello',
    recipients: ['user@example.com'],
    channelPreferred: Channel::EMAIL,
    tags: ['welcome', 'marketing'],
);
```

Alternative: empty constructor + properties
```php
use Neox\WrapNotificatorBundle\Domain\Enum\Channel;
use Neox\WrapNotificatorBundle\Domain\Model\NotificationMessage;

$msg = new NotificationMessage();
$msg->subject = 'Welcome';
$msg->bodyText = 'Hello and welcome!';
$msg->recipients = ['user@example.com'];
$msg->channelPreferred = Channel::EMAIL;
```
