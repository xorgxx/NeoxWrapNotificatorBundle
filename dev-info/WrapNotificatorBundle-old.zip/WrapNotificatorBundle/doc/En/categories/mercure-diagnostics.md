# Mercure diagnostics

Check whether Mercure is installed and configured correctly, then publish a probe message.

Command:
- wrap:notificator:mercure:test — verifies configuration and publishes a test update to a topic.

Usage:
```
php bin/console wrap:notificator:mercure:test [--target=browser|system] [--topic=TOPIC] [--async] [--delay=SECONDS]
```

Options:
- --target, -t: Display target: browser (in-page toast) or system (OS notification)
- --topic: Topic for the test (default: wrap_notificator/stream)
- --async, -a: Publish via Messenger (asynchronous). Requires a worker.
- --delay, -d: Delay in seconds (with --async)

Examples:
- Simple browser test:
```
php bin/console wrap:notificator:mercure:test
```
- Async test with 10s delay:
```
php bin/console wrap:notificator:mercure:test --async --delay=10
```
- System notification test:
```
php bin/console wrap:notificator:mercure:test --target=system
```

See also:
- Publishing: categories/mercure-publishing.md
