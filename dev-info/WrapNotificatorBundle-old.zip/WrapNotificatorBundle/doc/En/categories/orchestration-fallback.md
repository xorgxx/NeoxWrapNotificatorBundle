# Orchestration and fallback (EN)

The bundle selects the channel based on:
- The message `channelPreferred` (if set), otherwise `default_channel`
- A fallback policy if sending fails

Key settings (wrap_notificator.yaml):
```yaml
wrap_notificator:
  default_channel: email
  fallback:
    order: [sms, webpush, webhook]
    max_switches: 2
```

Example: if email fails, tries SMS, then Webpush, then Webhook (up to 2 switches).

Optional Mercure events published during orchestration: `dispatched`, `sent`, `failed`, `switched`.

Best practices:
- Define a realistic fallback order.
- Implement a custom health checker if needed (`ChannelHealthCheckerInterface`).
