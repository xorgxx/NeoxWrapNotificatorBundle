# Real‑time (Mercure/Turbo) — EN

Enable event broadcasting and, if desired, server‑side Turbo Streams injection in your HTML pages. The bundle also exposes Twig functions to consume the Mercure hub in the browser, with two distinct display modes.

## Basic configuration
```yaml
wrap_notificator:
  mercure:
    enabled: true
    public_url: '%env(MERCURE_PUBLIC_URL)%' # can be auto‑detected on the client
    default_topic: 'wrap_notificator/stream' # browser !
    turbo_enabled: true
    auto_inject: true
    only_authenticated: false
```

Tip: the client can auto‑detect the hub URL via `<link rel="mercure" href="…">`, `<meta name="mercure-hub" content="…">`, or `window.MERCURE_PUBLIC_URL`.

## Automatic injection (server)
- The `AutoTurboInjectorListener` can inject a Turbo snippet to listen to the bundle's internal events and display Turbo Streams.
- Works only for HTML responses and, if `only_authenticated: true`, for authenticated users.

## Client‑side Twig functions
Add these ONCE in your layout (inside `<body>`), preferably at the top of the page:

```twig
{{ wrap_notify_bootstrap() }}
{{ wrap_notify_browser(['alerts:ops']) }}            {# in‑page toasts + Turbo Streams #}
{{ neox_notify_system(['alerts:ops1']) }} {# native OS notifications #}
```

- `wrap_notify_bootstrap()` injects the container, CSS and minimal JS to display modern toasts. If SweetAlert (Swal) is available, a Swal toast is used (with high z‑index); otherwise a modern custom fallback is rendered.
- `wrap_notify_browser(topics = [default])` opens an EventSource to the Mercure hub, auto‑detects the hub when possible, processes Turbo Streams (`Turbo.renderStreamMessage`), and displays toasts for any JSON/JSON‑LD payload. If no topics are provided, it listens to `wrap_notificator/stream`.
- `neox_notify_system(topics = [])` opens an EventSource and shows native notifications via the Web Notifications API (Windows/macOS/Linux). If the API is unavailable or permission is denied, it falls back to in‑page toasts. This function ignores Turbo Streams (no DOM effect).

### Topic subscription tips
- Avoid listening to the same topics with both `neox_notify_browser` and `neox_notify` to prevent duplicate displays.
- If you provide custom topics, `neox_notify_browser` also listens to the default topic to receive the bundle's Turbo Streams.

### Turbo Streams handling
- Turbo events are published on the default topic (`wrap_notificator/stream`) via the `MercurePublisher`.
- On the client, the received `<turbo-stream>` is passed to `Turbo.renderStreamMessage(...)` if Turbo is loaded; otherwise the element is placed in a holder and can be processed later once Turbo becomes available.

### Z‑index and visibility
- The toast container uses a maximum z‑index (`2147483647`) to remain visible above the UI. For SweetAlert, `zIndex` is also set.

### Server‑side publish example
```php
$publisher->publish('demo', [
    'title' => 'Hello',
    'message' => 'World',
    'level' => 'success',
]);
```

### Troubleshooting
- SSE connects but nothing is shown: ensure Turbo is loaded for stream rendering, and the `#wrap-notificator-stream` container exists (injected by `wrap_notify_bootstrap()`).
- JSON‑LD payloads: a generic toast is displayed even without `title/message/level`.
- Missing hub URL: expose a `<link rel="mercure">` or set `MERCURE_PUBLIC_URL`.
