# Deferred storage & batching (EN)

Temporarily store notifications and send them later (batch).

Default configuration:
```yaml
wrap_notificator:
  storage:
    enabled: true
    driver: file
    file_path: '%kernel.project_dir%/var/wrap_notificator/pending.jsonl'
    batch_size: 100
    default_delay_seconds: 0
```

Typical usage:
- Schedule via CLI: `wrap:notificator:schedule` with `--batch-key=...`
- Flush later: `wrap:notificator:flush-pending --batch-key=...`

Messenger handler `FlushDueNotificationsHandler` processes due notifications.

Benefits:
- Smooths load
- Logical grouping by batch
