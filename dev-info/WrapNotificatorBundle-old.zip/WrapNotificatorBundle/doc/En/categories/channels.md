# Supported channels (EN)

The bundle provides senders for multiple channels. Choose via `NotificationMessage::$channelPreferred` or let it default to `default_channel`.

Available channels:
- Email (Symfony Mailer)
- SMS (providers via DSN; built-in Twilio)
- Webhook (POST/JSON)
- Webpush (optional)
- In‑app (placeholder for your app)

Email example:
```php
use Neox\WrapNotificatorBundle\Domain\Enum\Channel;
use Neox\WrapNotificatorBundle\Domain\Model\NotificationMessage;

$msg = new NotificationMessage(
    subject: 'Hello',
    bodyText: 'Plain text',
    bodyHtml: '<p>HTML</p>',
    recipients: ['user@example.com'],
    channelPreferred: Channel::EMAIL,
);
```

SMS example (Twilio via DSN):
```dotenv
WRAP_SMS_DSN="sms+twilio://ACCOUNT_SID:AUTH_TOKEN@default?from=%2B15551234567"
```
```php
use Neox\WrapNotificatorBundle\Domain\Enum\Channel;
use Neox\WrapNotificatorBundle\Domain\Model\NotificationMessage;

$msg = new NotificationMessage(
    bodyText: 'Your code: 123456',
    recipients: ['+15551230000'],
    channelPreferred: Channel::SMS,
);
```

Webhook quick setup:
```yaml
wrap_notificator:
  channels:
    webhook:
      timeout: 10
      retryable_statuses: [429,500,502,503,504]
```

Webpush: enable `webpush.enabled: true` and implement/activate the sender if needed.
