# Idempotency (EN)

The bundle avoids duplicate sends using an idempotency store. Default: `InMemoryStore`.

How it works:
- Each `NotificationMessage` gets an `id` (UUID v7) when created.
- Before sending, the orchestrator checks if the id is already stored.
- If yes: sending is skipped ("Idempotent skip").

Implementations:
- Default: `InMemoryStore` (volatile)
- You can provide your own via `StoreInterface` (Redis, DB, ...)

Benefits:
- Prevents duplicates during retries or message replays.
