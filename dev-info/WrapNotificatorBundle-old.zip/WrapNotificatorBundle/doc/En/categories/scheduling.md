# Scheduling

Schedule (enqueue) notifications to be delivered later or grouped in batches.

Command:
- wrap:notificator:schedule — store a message with a preferred channel, optional delay, and optional batch key.

Usage:
```
php bin/console wrap:notificator:schedule <to> [--channel=...] [--delay=SECONDS] [--batch-key=KEY]
```

Arguments:
- to: Recipient (email address or phone number)

Options:
- --channel: email|sms|webhook|webpush (default: email)
- --delay: Seconds to wait before eligible (default: 0)
- --batch-key: Optional grouping key for later bulk flushing

Examples:
- Schedule an email in 5 minutes:
```
php bin/console wrap:notificator:schedule user@example.org --channel=email --delay=300
```
- Enqueue an SMS in a "billing" batch:
```
php bin/console wrap:notificator:schedule "+15551234567" --channel=sms --batch-key=billing
```

See also:
- Flushing: categories/flushing.md
