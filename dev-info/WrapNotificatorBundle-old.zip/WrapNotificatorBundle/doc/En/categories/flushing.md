# Flushing

Send stored notifications that became due, optionally limited by batch key or a maximum count.

Command:
- wrap:notificator:flush-pending — flush due notifications from storage using async dispatch and optional sync fallback.

Usage:
```
php bin/console wrap:notificator:flush-pending [--limit=N] [--batch-key=KEY]
```

Options:
- --limit: Max items to process (default: 100)
- --batch-key: Flush only the specified batch

Examples:
- Flush all due notifications:
```
php bin/console wrap:notificator:flush-pending
```
- Flush at most 50 items:
```
php bin/console wrap:notificator:flush-pending --limit=50
```
- Flush only the "billing" batch:
```
php bin/console wrap:notificator:flush-pending --batch-key=billing
```

See also:
- Scheduling: categories/scheduling.md
