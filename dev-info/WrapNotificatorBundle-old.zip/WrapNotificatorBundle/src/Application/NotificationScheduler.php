<?php

namespace Neox\WrapNotificatorBundle\Application;

use Neox\WrapNotificatorBundle\Domain\Model\NotificationMessage;
use Neox\WrapNotificatorBundle\Infrastructure\Storage\NotificationStorageInterface;

class NotificationScheduler
{
    public function __construct(
        private readonly NotificationStorageInterface $storage,
        private readonly int $defaultDelaySeconds = 0,
    ) {}

    /**
     * Store a notification for deferred or batched sending.
     */
    public function schedule(NotificationMessage $message, int $delaySeconds = 0, ?string $batchKey = null): void
    {
        $delay = $delaySeconds > 0 ? (new \DateTimeImmutable(
            '+' . $delaySeconds . ' seconds'
        )) : ($this->defaultDelaySeconds > 0 ? new \DateTimeImmutable('+' . $this->defaultDelaySeconds . ' seconds') : null);

        $this->storage->store($message, $delay, $batchKey);
    }
}
