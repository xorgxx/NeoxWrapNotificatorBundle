<?php

namespace Neox\WrapNotificatorBundle\Application;

use Neox\WrapNotificatorBundle\Domain\Model\NotificationMessage;
use Neox\WrapNotificatorBundle\Domain\Result\SendResult;

interface NotificatorInterface
{
    public function send(NotificationMessage $message): SendResult;
}
