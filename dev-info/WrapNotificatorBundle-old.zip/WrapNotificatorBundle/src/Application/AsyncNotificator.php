<?php

namespace Neox\WrapNotificatorBundle\Application;

use Neox\WrapNotificatorBundle\Domain\Model\NotificationMessage;
use Neox\WrapNotificatorBundle\Infrastructure\Messenger\Message\AsyncNotificationMessage;
use Symfony\Component\Messenger\MessageBusInterface;
use Symfony\Component\Messenger\Stamp\DelayStamp;

class AsyncNotificator
{
    public function __construct(private readonly MessageBusInterface $bus) {}

    public function dispatch(NotificationMessage $message): void
    {
        if (!empty($message->delaySeconds) && $message->delaySeconds > 0) {
            $this->bus->dispatch(
                new AsyncNotificationMessage($message),
                [new DelayStamp($message->delaySeconds * 1000)]
            );
            return;
        }
        $this->bus->dispatch(new AsyncNotificationMessage($message));
    }
}
