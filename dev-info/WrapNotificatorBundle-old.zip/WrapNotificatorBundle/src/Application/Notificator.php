<?php

namespace Neox\WrapNotificatorBundle\Application;

use Neox\WrapNotificatorBundle\Application\Orchestrator\NotificationOrchestrator;
use Neox\WrapNotificatorBundle\Domain\Model\NotificationMessage;
use Neox\WrapNotificatorBundle\Domain\Result\SendResult;

class Notificator implements NotificatorInterface
{
    public function __construct(
        private readonly NotificationOrchestrator $orchestrator,
        private readonly ?AsyncNotificator $asyncNotificator = null,
        private readonly bool $asyncEnabled = true // %wrap_notificator.async.enabled%
    ) {}

    // Compat: send() => process()
    public function send(NotificationMessage $message): SendResult
    {
        return $this->process($message);
    }

    public function process(NotificationMessage $message): SendResult
    {
        if ($message->async === true && $this->asyncEnabled && $this->asyncNotificator) {
            $this->asyncNotificator->dispatch($message);
            return new SendResult(true, null, [], null, 0, null); // accepté / dispatché
        }

        return $this->orchestrator->process($message);
    }
}
