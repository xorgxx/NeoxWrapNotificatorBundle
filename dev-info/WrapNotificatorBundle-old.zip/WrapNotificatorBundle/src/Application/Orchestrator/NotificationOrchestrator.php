<?php

namespace Neox\WrapNotificatorBundle\Application\Orchestrator;

use Neox\WrapNotificatorBundle\Domain\Enum\Channel;
use Neox\WrapNotificatorBundle\Domain\Model\NotificationMessage;
use Neox\WrapNotificatorBundle\Domain\Policy\DefaultSwitchPolicy;
use Neox\WrapNotificatorBundle\Domain\Result\SendResult;
use Neox\WrapNotificatorBundle\Infrastructure\Channel\ChannelSenderInterface;
use Neox\WrapNotificatorBundle\Infrastructure\Health\ChannelHealthCheckerInterface;
use Neox\WrapNotificatorBundle\Infrastructure\Idempotency\StoreInterface;
use Neox\WrapNotificatorBundle\Infrastructure\Mercure\MercurePublisher;
use Psr\Log\LoggerInterface;

class NotificationOrchestrator
{
    /** @param iterable<ChannelSenderInterface> $channelSenders */
    public function __construct(
        private readonly string $defaultChannel,
        private readonly array $fallbackOrder,
        private readonly int $maxSwitches,
        private readonly MercurePublisher $mercurePublisher,
        private readonly ChannelHealthCheckerInterface $healthChecker,
        private readonly StoreInterface $idempotencyStore,
        private readonly iterable $channelSenders,
        private readonly ?LoggerInterface $logger = null,
    ) {}

    public function process(NotificationMessage $message): SendResult
    {
        if ($this->idempotencyStore->exists($message->id)) {
            $this->logger?->info('Idempotent skip', ['id' => $message->id]);
            return new SendResult(true, null, [], null, 0, null);
        }

        $policy = new DefaultSwitchPolicy('UTC');
        $available = [Channel::EMAIL, Channel::SMS, Channel::WEBPUSH, Channel::WEBHOOK, Channel::IN_APP];

        $attempts = 0;
        $switches = 0;
        $current = $message->channelPreferred ?? Channel::from($this->defaultChannel);

        $this->mercurePublisher->publish('dispatched', $message, $current, $attempts);

        while ($current && $switches <= $this->maxSwitches) {
            $attempts++;
            $sender = $this->findSender($current);
            if (!$sender) {
                $this->logger?->warning('No sender for channel', ['channel' => $current->value]);
                $current = $policy->decideNext($message, $current, $available, $switches);
                $switches++;
                $this->mercurePublisher->publish('switched', $message, $current, $attempts);
                continue;
            }

            try {
                $result = $sender->send($message);
                $this->idempotencyStore->store($message->id);
                $this->mercurePublisher->publish('sent', $message, $current, $attempts);
                $result->usedChannel = $current; // set used
                $result->attempts = $attempts;
                return $result;
            } catch (\Throwable $e) {
                $this->logger?->error('Send failed', ['error' => $e->getMessage(), 'channel' => $current->value]);
                $this->mercurePublisher->publish('failed', $message, $current, $attempts, [$e->getMessage()]);
                // Simplified retry/switch: directly switch until max
                $next = $policy->decideNext($message, $current, $available, $switches);
                if ($next === null) {
                    return new SendResult(false, null, [$e->getMessage()], $current, $attempts, null);
                }
                $this->mercurePublisher->publish('switched', $message, $next, $attempts, [], $current);
                $current = $next;
                $switches++;
            }
        }

        return new SendResult(false, null, ['No channel available'], null, $attempts, null);
    }

    private function findSender(Channel $channel): ?ChannelSenderInterface
    {
        foreach ($this->channelSenders as $sender) {
            if ($sender->supports($channel)) {
                return $sender;
            }
        }
        return null;
    }
}
