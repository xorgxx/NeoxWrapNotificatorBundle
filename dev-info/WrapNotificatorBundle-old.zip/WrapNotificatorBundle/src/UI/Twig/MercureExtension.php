<?php

namespace Neox\WrapNotificatorBundle\UI\Twig;

use Symfony\Component\DependencyInjection\Attribute\Autowire;
use Twig\Extension\AbstractExtension;
use Twig\TwigFunction;

class MercureExtension extends AbstractExtension
{
    public function __construct(
        #[Autowire(param: 'wrap_notificator.mercure.enabled')] private readonly bool $mercureEnabled,
        #[Autowire(param: 'wrap_notificator.mercure.public_url')] private readonly ?string $publicUrl = null,
        #[Autowire(param: 'wrap_notificator.mercure.default_topic')] private readonly string $defaultTopic = 'wrap_notificator/stream',
        #[Autowire(param: 'wrap_notificator.mercure.only_authenticated')] private readonly bool $onlyAuthenticated = true,
    ) {}

    public function getFunctions(): array
    {
        return [
            new TwigFunction('wrap_notify_browser', [$this, 'renderStream'], ['is_safe' => ['html']]),
            new TwigFunction('wrap_notify_system', [$this, 'renderNativeNotify'], ['is_safe' => ['html']]),
            new TwigFunction('wrap_notify_bootstrap', [$this, 'renderBootstrap'], ['is_safe' => ['html']]),
        ];
    }

    /**
     * Injecte EventSource abonné aux topics fournis + écouteur pour notifications.
     *
     * @param string[]|null $topics
     */
    public function renderStream(?array $topics = null): string
    {
        if (!$this->mercureEnabled) {
            return '';
        }
        $topics = $topics && count($topics)
            ? array_values(array_unique(array_merge($topics, [$this->defaultTopic])))
            : [$this->defaultTopic];

        // Client-side auto-detection of Mercure hub URL: link[rel="mercure"], meta[name="mercure-hub"], window.MERCURE_PUBLIC_URL, fallback to configured server value.
        $topicsJs = json_encode(array_values($topics), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        $withCreds = $this->boolJs($this->onlyAuthenticated);
        $serverHub = (string) ($this->publicUrl ?: getenv('MERCURE_PUBLIC_URL') ?: '');
        $serverHubEsc = addslashes($serverHub);

        return <<<HTML
<script>
(function() {
  var topics = {$topicsJs};
  var withCredentials = {$withCreds};
  var serverHub = '{$serverHubEsc}';

  function detectHubUrl() {
    try {
      var link = document.querySelector('link[rel="mercure"]');
      if (link && link.href) return link.href;
      var meta = document.querySelector('meta[name="mercure-hub"]');
      if (meta && meta.content) return meta.content;
      if (typeof window.MERCURE_PUBLIC_URL === 'string' && window.MERCURE_PUBLIC_URL) return window.MERCURE_PUBLIC_URL;
      if (serverHub) return serverHub;
    } catch (_) {}
    return null;
  }

  function buildUrl(hub, topics) {
    var qs = topics.map(function(t){ return 'topic=' + encodeURIComponent(t); }).join('&');
    return hub + (hub.indexOf('?') >= 0 ? '&' : '?') + qs;
  }

  var hub = detectHubUrl();
  if (!hub) {
    console.warn('[Mercure] No hub URL detected. Add <link rel="mercure" href="..."> or define MERCURE_PUBLIC_URL.');
    return;
  }

  var url = buildUrl(hub, topics);
  try {
    var es = new EventSource(url, { withCredentials: withCredentials });
    es.onmessage = function (e) {
      // Turbo Stream
      if (e && e.data && e.data.indexOf('<turbo-stream') === 0) {
        if (window.Turbo && typeof window.Turbo.renderStreamMessage === 'function') {
          window.Turbo.renderStreamMessage(e.data);
        } else {
          // Fallback: inject the stream element so Turbo (if loaded later) can process it
          var holder = document.getElementById('wrap-notificator-stream-holder') || document.body;
          var tpl = document.createElement('template');
          tpl.innerHTML = e.data.trim();
          holder.appendChild(tpl.content);
        }
        return;
      }
      // JSON => dispatch + popup (generic fallback)
      try {
        var data = JSON.parse(e.data);
        document.dispatchEvent(new CustomEvent('wrap:notificator:event', { detail: data }));
        if (window.WN) {
          var title = (data && (data.title || data.event)) || 'Notification';
          var message = '';
          if (data) {
            message = data.message || data.description || data['@id'] || '';
            if (!message) {
              try { message = JSON.stringify(data); } catch(__) { message = String(e.data || ''); }
            }
          }
          var level = (data && data.level) ? data.level : 'info';
          var timeout = (data && typeof data.timeout === 'number') ? data.timeout : undefined;
          window.WN.notify({ title: title, message: message, level: level, timeout: timeout });
        }
      } catch (_) {}
    };
    es.onerror = function () {
      // reconnexion automatique gérée par EventSource
    };
  } catch (e) {
    console.error('[Mercure] init failed', e);
  }
})();
</script>
HTML;
    }

    /**
     * Injecte le conteneur et le JS/CSS minimal pour le fallback popup (SweetAlert si dispo).
     */
    public function renderBootstrap(): string
    {
        return <<<'HTML'
<style>
#wrap-notify-container {
  position: fixed; z-index: 2147483647; top: 1rem; right: 1rem; display: flex; flex-direction: column; gap: .5rem;
}
.wrap-notify {
  min-width: 280px; max-width: 420px; color: #fff; border-radius: .5rem; box-shadow: 0 8px 24px rgba(0,0,0,.2);
  padding: .75rem .9rem; display: flex; align-items: flex-start; gap: .6rem; backdrop-filter: blur(6px);
}
.wrap-notify-info    { background: linear-gradient(135deg, #2563eb, #60a5fa); }
.wrap-notify-success { background: linear-gradient(135deg, #059669, #34d399); }
.wrap-notify-warning { background: linear-gradient(135deg, #d97706, #fbbf24); }
.wrap-notify-error   { background: linear-gradient(135deg, #dc2626, #f87171); }
.wrap-notify .wn-title { font-weight: 700; margin: 0 0 .15rem 0; line-height: 1.2; }
.wrap-notify .wn-body { margin: 0; opacity: .95; }
.wrap-notify .wn-close { margin-left: auto; cursor: pointer; opacity: .8; background: transparent; color: #fff; border: 0; font-size: 16px; }
.wrap-notify .wn-close:hover { opacity: 1; }
</style>
<div id="wrap-notify-container" aria-live="polite" aria-atomic="true"></div>
<!-- Default Turbo Stream target for Wrap Notificator -->
<div id="wrap-notificator-stream"></div>
<!-- Holder for pending turbo-stream elements if Turbo is not yet ready -->
<div id="wrap-notificator-stream-holder" style="display:none"></div>
<script>
window.WN = window.WN || {};
(function () {
  function levelClass(level) {
    switch(String(level||'info').toLowerCase()){
      case 'success': return 'wrap-notify-success';
      case 'warning': return 'wrap-notify-warning';
      case 'error':
      case 'danger': return 'wrap-notify-error';
      default: return 'wrap-notify-info';
    }
  }

  function useSweetAlert() {
    return !!(window.Swal);
  }

  function showWithSweetAlert(p) {
    const icon = ({success:'success', warning:'warning', error:'error', danger:'error'})[String(p.level||'info').toLowerCase()] || 'info';
    const timer = Number.isFinite(p.timeout) ? p.timeout : 4000;
    window.Swal.fire({
      title: p.title || 'Notification',
      text: p.message || '',
      icon,
      toast: true,
      position: 'top-end',
      showConfirmButton: false,
      timer,
      timerProgressBar: true,
      // Ensure toast overlays anything on the page
      zIndex: 2147483647,
    });
  }

  function showFallback(p) {
    const box = document.createElement('div');
    box.className = 'wrap-notify ' + levelClass(p.level);
    box.innerHTML = `
      <div>
        <div class="wn-title">${p.title || 'Notification'}</div>
        ${p.message ? `<div class="wn-body">${p.message}</div>` : ''}
      </div>
      <button class="wn-close" aria-label="Fermer">✕</button>
    `;
    const holder = document.getElementById('wrap-notify-container');
    holder?.appendChild(box);

    const remove = () => { box.remove(); };
    box.querySelector('.wn-close')?.addEventListener('click', remove);

    const timeout = Number.isFinite(p.timeout) ? p.timeout : 4000;
    if (timeout > 0) setTimeout(remove, timeout);
  }

  window.WN.notify = function (payload) {
    const p = payload || {};
    if (useSweetAlert()) return showWithSweetAlert(p);
    return showFallback(p);
  };

  window.addEventListener('wrap:notificator:notify', (e) => window.WN.notify(e.detail || {}));
})();
</script>
HTML;
    }

    private function boolJs(bool $v): string
    {
        return $v ? 'true' : 'false';
    }

    /**
     * Ouvre un flux SSE et affiche des notifications natives (OS) via l'API Web Notifications.
     * Ne modifie pas le DOM (pas de Turbo Stream, sauf réception ignorée).
     *
     * @param string[]|null $topics
     */
    public function renderNativeNotify(?array $topics = null): string
    {
        if (!$this->mercureEnabled) {
            return '';
        }
        // Ici: si des topics sont fournis, on les utilise tels quels (pas d'ajout du topic par défaut)
        $topics = $topics && count($topics) ? array_values(array_unique($topics)) : [$this->defaultTopic];

        $topicsJs = json_encode(array_values($topics), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        $withCreds = $this->boolJs($this->onlyAuthenticated);
        $serverHub = (string) ($this->publicUrl ?: getenv('MERCURE_PUBLIC_URL') ?: '');
        $serverHubEsc = addslashes($serverHub);

        return <<<HTML
<script>
(function() {
  var topics = {$topicsJs};
  var withCredentials = {$withCreds};
  var serverHub = '{$serverHubEsc}';

  function detectHubUrl() {
    try {
      var link = document.querySelector('link[rel="mercure"]');
      if (link && link.href) return link.href;
      var meta = document.querySelector('meta[name="mercure-hub"]');
      if (meta && meta.content) return meta.content;
      if (typeof window.MERCURE_PUBLIC_URL === 'string' && window.MERCURE_PUBLIC_URL) return window.MERCURE_PUBLIC_URL;
      if (serverHub) return serverHub;
    } catch (_) {}
    return null;
  }

  function buildUrl(hub, topics) {
    var qs = topics.map(function(t){ return 'topic=' + encodeURIComponent(t); }).join('&');
    return hub + (hub.indexOf('?') >= 0 ? '&' : '?') + qs;
  }

  function ensurePermission() {
    if (!('Notification' in window)) return 'unsupported';
    try {
      if (Notification.permission === 'default') {
        Notification.requestPermission().catch(function(){});
      }
      return Notification.permission;
    } catch(_) { return 'unsupported'; }
  }

  function levelToIcon(level) {
    // Try to reuse site icon as default
    var favicon = document.querySelector('link[rel="icon"], link[rel="shortcut icon"]');
    var def = favicon && favicon.href ? favicon.href : undefined;
    switch(String(level||'info').toLowerCase()){
      case 'success': return def;
      case 'warning': return def;
      case 'error':
      case 'danger': return def;
      default: return def;
    }
  }

  function showNative(data) {
    if (!('Notification' in window)) return false;
    var perm = Notification.permission;
    if (perm === 'denied') return false;
    var title = (data && (data.title || data.event)) || 'Notification';
    var message = '';
    if (data) {
      message = data.message || data.description || data['@id'] || '';
      if (!message) { try { message = JSON.stringify(data); } catch(__) { message = String(''); } }
    }
    var icon = (data && data.icon) || levelToIcon(data && data.level);
    try {
      var n = new Notification(title, { body: message, icon: icon, tag: data && data.tag ? data.tag : undefined, requireInteraction: false });
      if (data && data.url) {
        n.onclick = function() { try { window.focus(); window.location.href = data.url; } catch(_) {} };
      }
      return true;
    } catch(e) {
      return false;
    }
  }

  // Simple dedup cache by payload hash (string); TTL 2s
  var seen = window.__WN_EVT_SEEN || (window.__WN_EVT_SEEN = new Map());
  function seenRecently(key) {
    var now = Date.now();
    var ts = seen.get(key);
    if (ts && (now - ts) < 2000) return true;
    seen.set(key, now);
    // Cleanup sometimes
    if (seen.size > 1000) {
      var limit = now - 2000;
      Array.from(seen.keys()).forEach(function(k){ if ((seen.get(k) || 0) < limit) seen.delete(k); });
    }
    return false;
  }

  var hub = detectHubUrl();
  if (!hub) {
    console.warn('[Mercure] No hub URL detected for native notifications.');
    return;
  }

  ensurePermission();
  var url = buildUrl(hub, topics);
  try {
    var es = new EventSource(url, { withCredentials: withCredentials });
    es.onmessage = function (e) {
      if (!e || !e.data) return;
      var key = e.lastEventId ? (e.lastEventId+':'+e.data) : e.data;
      if (seenRecently(key)) return;
      // Ignore Turbo Streams here: native notifier shouldn't affect the page DOM
      if (e.data.indexOf('<turbo-stream') === 0) {
        return;
      }
      try {
        var data = JSON.parse(e.data);
        document.dispatchEvent(new CustomEvent('wrap:notificator:event', { detail: data }));
        var ok = showNative(data);
        if (!ok && window.WN) {
          var title = (data && (data.title || data.event)) || 'Notification';
          var message = '';
          if (data) {
            message = data.message || data.description || data['@id'] || '';
            if (!message) { try { message = JSON.stringify(data); } catch(__) { message = String(e.data || ''); } }
          }
          var level = (data && data.level) ? data.level : 'info';
          var timeout = (data && typeof data.timeout === 'number') ? data.timeout : undefined;
          window.WN.notify({ title: title, message: message, level: level, timeout: timeout });
        }
      } catch (_) {
        // Non-JSON payloads: display raw text via native if possible
        var ok2 = showNative({ title: 'Notification', message: String(e.data||'') });
        if (!ok2 && window.WN) window.WN.notify({ title: 'Notification', message: String(e.data||''), level: 'info' });
      }
    };
    es.onerror = function () { /* auto-reconnect handled by EventSource */ };
  } catch (e) {
    console.error('[Mercure] native notify init failed', e);
  }
})();
</script>
HTML;
    }
}
