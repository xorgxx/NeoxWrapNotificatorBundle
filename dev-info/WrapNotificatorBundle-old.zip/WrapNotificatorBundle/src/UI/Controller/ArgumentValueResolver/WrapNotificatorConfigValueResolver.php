<?php

namespace Neox\WrapNotificatorBundle\UI\Controller\ArgumentValueResolver;

use Neox\WrapNotificatorBundle\Application\AsyncNotificator;
use Neox\WrapNotificatorBundle\Application\NotificatorInterface;
use Neox\WrapNotificatorBundle\Domain\Enum\Channel;
use Neox\WrapNotificatorBundle\Domain\Model\NotificationMessage;
use Neox\WrapNotificatorBundle\UI\Attribute\WrapNotificatorConfig;
use Psr\Log\LoggerInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpKernel\Controller\ValueResolverInterface;
use Symfony\Component\HttpKernel\ControllerMetadata\ArgumentMetadata;

class WrapNotificatorConfigValueResolver implements ValueResolverInterface
{
    private const AUTO_PARAM_NAMES = [
        'wrapNotificatorConfig', 'wrap_notificator_config',
        'wrapNotificator', 'wrap_notificator',
        'wrapConfig', 'notificatorConfig',
    ];

    public function __construct(
        private readonly array $bundleConfig,
        private readonly AsyncNotificator $asyncNotificator,
        private readonly NotificatorInterface $notificator,
        private readonly ?LoggerInterface $logger = null,
    ) {
    }

    public function supports(Request $request, ArgumentMetadata $argument): bool
    {
        // Attribute-based explicit opt-in
        $attributes = $argument->getAttributes(WrapNotificatorConfig::class, ArgumentMetadata::IS_INSTANCEOF);
        if (!empty($attributes)) {
            return true;
        }

        // Automatic mode: only for clearly named array parameters to avoid collisions
        $name = $argument->getName();
        $type = $argument->getType();
        if (in_array($name, self::AUTO_PARAM_NAMES, true)) {
            // If type is specified and not array/mixed, do not claim it
            if ($type === null || $type === 'array' || $type === 'mixed') {
                return true;
            }
        }

        return false;
    }

    public function resolve(Request $request, ArgumentMetadata $argument): iterable
    {
        $attributes = $argument->getAttributes(WrapNotificatorConfig::class, ArgumentMetadata::IS_INSTANCEOF);
        if (!empty($attributes)) {
            /** @var WrapNotificatorConfig $attr */
            $attr = $attributes[0];

            $value = $this->bundleConfig;
            if ($attr->path) {
                $ok = false;
                $value = $this->getByPath($this->bundleConfig, $attr->path, $ok);
                if (!$ok) {
                    if ($attr->required) {
                        throw new \InvalidArgumentException(sprintf('wrap_notificator config path "%s" not found', $attr->path));
                    }
                    $value = $attr->default;
                }
            }

            // Trigger automatic alert if requested via attribute
            if ($attr->autoAlert) {
                $this->triggerAutoAlert($request, $attr);
            } else {
                // Or via global config (if enabled and route filters match)
                $this->triggerAutoAlertFromGlobal($request);
            }

            // Basic type adaptation: if argument expects array and we have null, give []
            if ($argument->getType() === 'array' && $value === null) {
                $value = [];
            }

            yield $value;
            return;
        }

        // Automatic mode (no attribute): return the whole bundle config
        // Also evaluate global auto alert
        $this->triggerAutoAlertFromGlobal($request);

        $value = $this->bundleConfig;
        if ($argument->getType() === 'array' && $value === null) {
            $value = [];
        }
        yield $value;
    }

    private function getByPath(array $config, string $path, bool &$ok): mixed
    {
        $ok = true;
        $cursor = $config;
        foreach (explode('.', $path) as $segment) {
            if (is_array($cursor) && array_key_exists($segment, $cursor)) {
                $cursor = $cursor[$segment];
            } else {
                $ok = false;
                return null;
            }
        }
        return $cursor;
    }

    private function triggerAutoAlert(Request $request, WrapNotificatorConfig $attr): void
    {
        try {
            // Determine channel
            $channel = null;
            if ($attr->alertChannel) {
                try {
                    $channel = Channel::from($attr->alertChannel);
                } catch (\Throwable $e) {
                    $this->logger?->warning('Invalid alertChannel provided to WrapNotificatorConfig', ['given' => $attr->alertChannel]);
                }
            }

            // Recipients must be provided to avoid dispatching invalid messages
            $recipients = $attr->alertRecipients ?? [];
            if (empty($recipients)) {
                // No recipients: skip sending
                return;
            }

            $route = (string)($request->attributes->get('_route') ?? 'unknown');
            $controller = (string)($request->attributes->get('_controller') ?? 'unknown');
            $uri = $request->getUri();
            $method = $request->getMethod();
            $clientIp = $request->getClientIp();

            $subject = $attr->alertSubject ?? sprintf('Route called: %s', $route);
            $bodyText = sprintf("Route alert\n- Route: %s\n- Controller: %s\n- Method: %s\n- URI: %s\n- Client IP: %s\n- Time: %s",
                $route, $controller, $method, $uri, $clientIp, (new \DateTimeImmutable())->format(DATE_ATOM)
            );
            $bodyHtml = sprintf('<h3>Route alert</h3><ul><li><strong>Route:</strong> %s</li><li><strong>Controller:</strong> %s</li><li><strong>Method:</strong> %s</li><li><strong>URI:</strong> %s</li><li><strong>Client IP:</strong> %s</li><li><strong>Time:</strong> %s</li></ul>',
                htmlspecialchars($route), htmlspecialchars($controller), htmlspecialchars($method), htmlspecialchars($uri), htmlspecialchars((string)$clientIp), (new \DateTimeImmutable())->format(DATE_ATOM)
            );

            $message = new NotificationMessage(
                subject: $subject,
                bodyText: $bodyText,
                bodyHtml: $bodyHtml,
                recipients: $recipients,
                channelPreferred: $channel,
                tags: ['auto-alert','wrap_notificator']
            );

            if ($attr->alertSync) {
                $this->notificator->send($message);
            } else {
                $this->asyncNotificator->dispatch($message);
            }
        } catch (\Throwable $e) {
            $this->logger?->error('Failed to send auto alert', ['error' => $e->getMessage()]);
        }
    }

    private function triggerAutoAlertFromGlobal(Request $request): void
    {
        try {
            $cfg = $this->bundleConfig['auto_alert'] ?? [];
            if (!($cfg['enabled'] ?? false)) {
                return;
            }
            $route = (string)($request->attributes->get('_route') ?? 'unknown');
            // Route inclusion/exclusion rules
            $only = $cfg['only_routes'] ?? [];
            $except = $cfg['except_routes'] ?? [];
            if (!empty($only) && !in_array($route, $only, true)) {
                return;
            }
            if (!empty($except) && in_array($route, $except, true)) {
                return;
            }

            $recipients = $cfg['recipients'] ?? [];
            if (empty($recipients)) {
                return; // avoid dispatching invalid messages
            }

            $channel = null;
            if (!empty($cfg['channel'])) {
                try {
                    $channel = Channel::from($cfg['channel']);
                } catch (\Throwable $e) {
                    $this->logger?->warning('Invalid auto_alert.channel in config', ['given' => $cfg['channel']]);
                }
            }

            $controller = (string)($request->attributes->get('_controller') ?? 'unknown');
            $uri = $request->getUri();
            $method = $request->getMethod();
            $clientIp = $request->getClientIp();

            $prefix = (string)($cfg['subject_prefix'] ?? '[Route Alert] ');
            $subject = $prefix . sprintf('%s', $route);
            $bodyText = sprintf("Route alert\n- Route: %s\n- Controller: %s\n- Method: %s\n- URI: %s\n- Client IP: %s\n- Time: %s",
                $route, $controller, $method, $uri, $clientIp, (new \DateTimeImmutable())->format(DATE_ATOM)
            );
            $bodyHtml = sprintf('<h3>Route alert</h3><ul><li><strong>Route:</strong> %s</li><li><strong>Controller:</strong> %s</li><li><strong>Method:</strong> %s</li><li><strong>URI:</strong> %s</li><li><strong>Client IP:</strong> %s</li><li><strong>Time:</strong> %s</li></ul>',
                htmlspecialchars($route), htmlspecialchars($controller), htmlspecialchars($method), htmlspecialchars($uri), htmlspecialchars((string)$clientIp), (new \DateTimeImmutable())->format(DATE_ATOM)
            );

            $message = new NotificationMessage(
                subject: $subject,
                bodyText: $bodyText,
                bodyHtml: $bodyHtml,
                recipients: $recipients,
                channelPreferred: $channel,
                tags: ['auto-alert','wrap_notificator','global']
            );

            if (!empty($cfg['sync'])) {
                $this->notificator->send($message);
            } else {
                $this->asyncNotificator->dispatch($message);
            }
        } catch (\Throwable $e) {
            $this->logger?->error('Failed to send global auto alert', ['error' => $e->getMessage()]);
        }
    }
}
