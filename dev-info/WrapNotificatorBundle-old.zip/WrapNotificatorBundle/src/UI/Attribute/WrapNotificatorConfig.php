<?php

namespace Neox\WrapNotificatorBundle\UI\Attribute;

use Attribute;

/**
 * Attribute to inject WrapNotificatorBundle configuration into controller arguments.
 * Can also optionally trigger an automatic alert when the controller/route is called.
 *
 * Usage:
 *  public function index(#[WrapNotificatorConfig] array $wrapConfig) {}
 *  public function mail(#[WrapNotificatorConfig('channels.email')] array $emailCfg) {}
 *  public function value(#[WrapNotificatorConfig('default_channel')] string $channel) {}
 *  public function alert(#[WrapNotificatorConfig(autoAlert: true, alertRecipients: ['ops@example.com'], alertChannel: 'email')] array $cfg) {}
 */
#[Attribute(Attribute::TARGET_PARAMETER)]
class WrapNotificatorConfig
{
    public function __construct(
        public readonly ?string $path = null,
        public readonly bool $required = true,
        public readonly mixed $default = null,
        // Auto alert options
        public readonly bool $autoAlert = false,
        /** @var string[]|null */
        public readonly ?array $alertRecipients = null,
        public readonly ?string $alertChannel = null, // 'email' | 'sms' | 'webhook' | 'webpush' | 'in_app'
        public readonly ?string $alertSubject = null,
        public readonly bool $alertSync = false,
    ) {}
}
