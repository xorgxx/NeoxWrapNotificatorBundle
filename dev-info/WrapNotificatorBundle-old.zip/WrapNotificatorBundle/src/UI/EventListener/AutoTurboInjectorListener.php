<?php
declare(strict_types=1);

namespace Neox\WrapNotificatorBundle\UI\EventListener;

use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Event\ResponseEvent;
use Symfony\Component\HttpKernel\KernelEvents;
use Twig\Environment as TwigEnvironment;
use Symfony\Bundle\SecurityBundle\Security;

/**
 * Injecteur automatique d'éléments Turbo/Mercure dans les réponses HTML.
 */
final class AutoTurboInjectorListener implements EventSubscriberInterface
{
    private const PRIORITY = -128;

    public function __construct(
        private readonly bool $enabled,
        private readonly bool $turboEnabled,
        private readonly ?string $publicUrl,
        private readonly string $defaultTopic,
        private readonly ?TwigEnvironment $twig,
        private readonly bool $onlyAuthenticated,
        private readonly ?Security $security,
    ) {
    }

    public static function getSubscribedEvents(): array
    {
        return [
            KernelEvents::RESPONSE => [
                'onKernelResponse',
                self::PRIORITY,
            ],
        ];
    }

    public function onKernelResponse(ResponseEvent $event): void
    {
        if (!$this->shouldProcess($event)) {
            return;
        }

        // NB: Implémentation minimaliste: on laisse un hook d'injection plus tard si besoin.
        // Vous pouvez insérer ici un fragment Twig ou du HTML pour initialiser Turbo/Mercure.
        $response = $event->getResponse();
        $content = $response->getContent();

        // Exemple d'injection très légère d'un commentaire marqueur (désactivée par défaut).
        // $content .= "<!-- WrapNotificator Turbo Injector active -->";
        // $response->setContent($content);
    }

    private function shouldProcess(ResponseEvent $event): bool
    {
        if (!$event->isMainRequest()) {
            return false;
        }
        if (!$this->enabled || !$this->turboEnabled) {
            return false;
        }
        if ($this->onlyAuthenticated && null === $this->security?->getUser()) {
            return false;
        }

        $response = $event->getResponse();
        return $this->isHtmlResponse($response);
    }

    private function isHtmlResponse(Response $response): bool
    {
        $type = $response->headers->get('Content-Type');
        return is_string($type) && str_contains($type, 'text/html');
    }
}
