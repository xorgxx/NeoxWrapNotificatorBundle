<?php

namespace Neox\WrapNotificatorBundle\UI\Command;

use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Messenger\MessageBusInterface;
use Symfony\Component\Messenger\Stamp\DelayStamp;
use Symfony\Component\Mercure\HubInterface;
use Symfony\Component\Mercure\Update;

#[AsCommand(name: 'wrap:notificator:mercure:test', description: 'Teste si Mercure est installé et correctement configuré (hub, paramètres, publication de test).')]
class NotificatorMercureTestCommand extends Command
{
    public function __construct(
        private readonly ?HubInterface $hub = null,
        private readonly bool $mercureEnabled = false,
        private readonly string $publicUrl = '',
        private readonly string $defaultTopic = 'wrap_notificator/stream',
        private readonly ?MessageBusInterface $bus = null,
    ) {
        parent::__construct();
    }

    protected function configure(): void
    {
        $this
            ->addOption('target', 't', InputOption::VALUE_REQUIRED, 'Où afficher le test: browser (toast in-page) ou system (notification native OS)', 'browser')
            ->addOption('topic', null, InputOption::VALUE_REQUIRED, 'Topic Mercure à utiliser pour le test (par défaut: wrap_notificator/stream)')
            ->addOption('async', 'a', InputOption::VALUE_NONE, 'Publier via Messenger (asynchrone). Nécessite un worker: php bin/console messenger:consume')
            ->addOption('delay', 'd', InputOption::VALUE_REQUIRED, 'Retard (en secondes) lorsqu\'on utilise --async', '0');

        $this->setHelp(<<<'HELP'
FR (Catégorie: Mercure / Diagnostic)
Vérifie la configuration Mercure (activation, hub, URL publique, topic par défaut) et publie un message de test.

Usage:
  php bin/console wrap:notificator:mercure:test [--target=browser|system] [--topic=TOPIC] [--async] [--delay=SECONDS]

Options:
  --target, -t       Cible d'affichage: browser (toast dans la page) ou system (notification OS)
  --topic            Topic utilisé pour le test (défaut: wrap_notificator/stream)
  --async, -a        Publier via Messenger (asynchrone). Nécessite un worker.
  --delay, -d        Délai en secondes (avec --async)

Exemples:
  # Test simple dans le navigateur (FR)
  php bin/console wrap:notificator:mercure:test

  # Test en asynchrone avec 10s de retard (FR)
  php bin/console wrap:notificator:mercure:test --async --delay=10

  # Test notification système (FR)
  php bin/console wrap:notificator:mercure:test --target=system

EN (Category: Mercure / Diagnostics)
Checks Mercure configuration (enabled, hub, public URL, default topic) and publishes a probe message.

Usage:
  php bin/console wrap:notificator:mercure:test [--target=browser|system] [--topic=TOPIC] [--async] [--delay=SECONDS]

Options:
  --target, -t       Display target: browser (in-page toast) or system (OS notification)
  --topic            Topic for the test (default: wrap_notificator/stream)
  --async, -a        Publish via Messenger (asynchronous). Requires a worker.
  --delay, -d        Delay in seconds (with --async)

Examples:
  # Simple browser test (EN)
  php bin/console wrap:notificator:mercure:test

  # Async test with 10s delay (EN)
  php bin/console wrap:notificator:mercure:test --async --delay=10

  # System notification test (EN)
  php bin/console wrap:notificator:mercure:test --target=system
HELP);
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $ok = true;
        $output->writeln('<info>[Mercure diagnostic]</info>');

        // 1) Enabled flag
        if ($this->mercureEnabled) {
            $output->writeln(' - enabled: <info>TRUE</info>');
        } else {
            $output->writeln(' - enabled: <error>FALSE</error>');
            $ok = false;
        }

        // 2) Hub service
        if ($this->hub) {
            $output->writeln(' - hub service: <info>OK</info>');
        } else {
            $output->writeln(' - hub service: <error>NOT AVAILABLE</error>');
            $ok = false;
        }
        // 3) Public URL
        $publicUrl = $this->publicUrl ?: (getenv('MERCURE_PUBLIC_URL') ?: '');
        if ($publicUrl) {
            $output->writeln(' - public_url: <info>' . $publicUrl . '</info>');
        } else {
            $output->writeln(' - public_url: <error>EMPTY</error>');
            $ok = false;
        }

        // 4) Default topic
        if ($this->defaultTopic) {
            $output->writeln(' - default_topic: <info>' . $this->defaultTopic . '</info>');
        } else {
            $output->writeln(' - default_topic: <error>EMPTY</error>');
            $ok = false;
        }

        // Early fail
        if (!$ok) {
            $output->writeln('=> <error>Mercure configuration is not valid.</error>');
            $output->writeln('   Tips: set MERCURE_PUBLIC_URL, enable wrap_notificator.mercure.enabled, install mercure/hub and configure Symfony Mercure Bundle.');
            return Command::FAILURE;
        }

        // 5) Publish probe
        $target = strtolower((string) $input->getOption('target')) ?: 'browser';
        if (!in_array($target, ['browser','system'], true)) {
            $target = 'browser';
        }
        $topic = (string) ($input->getOption('topic') ?: $this->defaultTopic);
        $useAsync = (bool) $input->getOption('async');
        $delaySeconds = (int) ($input->getOption('delay') ?? 0);
        if ($delaySeconds < 0) { $delaySeconds = 0; }
        try {
            $data = [
                'status' => 'probe',
                'event' => 'wrap_notificator.probe',
                'title' => $target === 'system' ? 'Test notification (OS)' : 'Test notification (browser)',
                'message' => $target === 'system' ? 'Ceci est un test de notification native (Web Notifications).' : 'Ceci est un test d\'affichage dans le navigateur.',
                'level' => 'info',
                'timeout' => 4000,
                'target' => $target,
                'ts' => (new \DateTimeImmutable())->format(DATE_ATOM),
            ];
            $payload = json_encode($data, JSON_UNESCAPED_UNICODE);
            $update = new Update($topic, $payload, private: false, id: null, type: null);

            if ($useAsync) {
                if ($this->bus) {
                    $stamps = [];
                    if ($delaySeconds > 0) {
                        $stamps[] = new DelayStamp($delaySeconds * 1000);
                    }
                    $this->bus->dispatch($update, $stamps);
                    if ($delaySeconds > 0) {
                        $output->writeln(sprintf(' - dispatch (async) with delay %ds to topic [%s] for target [%s]: <info>SCHEDULED</info>', $delaySeconds, $topic, $target));
                    } else {
                        $output->writeln(sprintf(' - dispatch (async) to topic [%s] for target [%s]: <info>ENQUEUED</info>', $topic, $target));
                    }
                    $output->writeln('   Worker: run "php bin/console messenger:consume -vv" (transport: asyncRabbitMq or async)');
                } else {
                    $output->writeln(' - dispatch (async): <error>NO BUS AVAILABLE</error> → fallback to direct publish');
                    if ($delaySeconds > 0) {
                        $output->writeln('   Note: --delay ignoré en mode direct.');
                    }
                    $this->hub->publish($update);
                    $output->writeln(sprintf(' - publish to topic [%s] for target [%s]: <info>OK</info>', $topic, $target));
                }
            } else {
                if ($delaySeconds > 0) {
                    $output->writeln(' - warning: --delay n\'a d\'effet qu\'avec --async. Ignoré en mode direct.');
                }
                $this->hub->publish($update);
                $output->writeln(sprintf(' - publish to topic [%s] for target [%s]: <info>OK</info>', $topic, $target));
            }
        } catch (\Throwable $e) {
            $ok = false;
            $output->writeln(sprintf(' - publish to topic [%s] for target [%s]: <error>FAILED</error>', $topic, $target));
            $output->writeln('   Reason: ' . $e->getMessage());
            $output->writeln('   Check: MERCURE_JWT_TOKEN permissions, hub URL, network.');
        }

        if ($ok) {
            $output->writeln('=> <info>Mercure looks correctly installed and configured.</info>');
            $output->writeln('   Open in browser with topic param, e.g.: ');
            $output->writeln('   ' . $publicUrl . (str_contains($publicUrl, '?') ? '&' : '?') . 'topic=' . rawurlencode($topic));
            if ($target === 'system') {
                $output->writeln('   Tip: ensure your layout includes {{ wrap_notify_system(topics=["' . $topic . '"]) }} and that notification permission is granted.');
            } else {
                $output->writeln('   Tip: ensure your layout includes {{ wrap_notify_browser([' . ($topic === $this->defaultTopic ? '' : '\'' . $topic . '\'') . ']) }} and {{ wrap_notify_bootstrap() }}.');
            }
            if ($useAsync) {
                if ($delaySeconds > 0) {
                    $eta = (new \DateTimeImmutable())->modify('+' . $delaySeconds . ' seconds')->format('H:i:s');
                    $output->writeln('   Async mode: message scheduled, expected earliest delivery around ~ ' . $eta . '.');
                } else {
                    $output->writeln('   Async mode: wait for worker to consume the message, then observe the SSE toast/notification.');
                }
            }
            return Command::SUCCESS;
        }

        return Command::FAILURE;
    }
}
