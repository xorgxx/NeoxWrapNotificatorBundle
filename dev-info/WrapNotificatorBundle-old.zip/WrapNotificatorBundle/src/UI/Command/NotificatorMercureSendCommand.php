<?php

namespace Neox\WrapNotificatorBundle\UI\Command;

use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Mercure\HubInterface;
use Symfony\Component\Mercure\Update;

#[AsCommand(name: 'wrap:notificator:mercure:send', description: 'Publie un message sur Mercure (navigateur par défaut, ou sujet utilisateur).')]
class NotificatorMercureSendCommand extends Command
{
    public function __construct(
        private readonly ?HubInterface $hub = null,
        private readonly bool $mercureEnabled = false,
        private readonly string $defaultTopic = 'wrap_notificator/stream',
    ) {
        parent::__construct();
    }

    protected function configure(): void
    {
        $this
            ->addArgument('message', InputArgument::OPTIONAL, 'Message texte simple (utilisé si --json non fourni).', 'Test Mercure from CLI')
            ->addOption('user', null, InputOption::VALUE_REQUIRED, 'Identifiant utilisateur cible (topic wrap_notificator/user/{id}).')
            ->addOption('topic', null, InputOption::VALUE_REQUIRED, 'Topic Mercure personnalisé (par défaut: default_topic config).')
            ->addOption('json', null, InputOption::VALUE_REQUIRED, 'Payload JSON à publier (si fourni, remplace message texte).')
            ->addOption('turbo', null, InputOption::VALUE_NONE, 'Publier comme Turbo Stream HTML (navigator).')
            ->addOption('event', null, InputOption::VALUE_REQUIRED, "Nom d'événement/context (pour Turbo)", 'custom');

        $this->setHelp(<<<'HELP'
FR (Catégorie: Mercure / Publication)
Publie un message sur un topic Mercure. Par défaut, en JSON; avec --turbo, en Turbo Stream HTML.

Usage:
  php bin/console wrap:notificator:mercure:send [message] [--user=ID|--topic=TOPIC] [--json=JSON] [--turbo] [--event=NAME]

Arguments:
  message            Texte simple envoyé si --json n'est pas fourni

Options:
  --user             Identifiant utilisateur (topic: wrap_notificator/user/{id})
  --topic            Topic explicite (sinon default_topic)
  --json             Payload JSON (remplace message)
  --turbo            Publie du Turbo Stream (navigator)
  --event            Nom d'événement pour styliser le Turbo (defaut: custom)

Exemples:
  # JSON simple sur le topic par défaut (FR)
  php bin/console wrap:notificator:mercure:send "Hello!"

  # Vers un utilisateur (FR)
  php bin/console wrap:notificator:mercure:send "Bonjour" --user=42

  # Payload JSON personnalisé (FR)
  php bin/console wrap:notificator:mercure:send --json='{"status":"info","message":"Ping"}'

  # Turbo Stream (FR)
  php bin/console wrap:notificator:mercure:send "Toast Turbo" --turbo --event=toast

EN (Category: Mercure / Publishing)
Publish a message to a Mercure topic. JSON by default; with --turbo, Turbo Stream HTML.

Usage:
  php bin/console wrap:notificator:mercure:send [message] [--user=ID|--topic=TOPIC] [--json=JSON] [--turbo] [--event=NAME]

Arguments:
  message            Plain text sent if --json is not provided

Options:
  --user             User identifier (topic: wrap_notificator/user/{id})
  --topic            Explicit topic (otherwise default_topic)
  --json             Custom JSON payload (overrides message)
  --turbo            Publish Turbo Stream (browser navigator)
  --event            Event name for Turbo styling (default: custom)

Examples:
  # Simple JSON on default topic (EN)
  php bin/console wrap:notificator:mercure:send "Hello!"

  # To a specific user (EN)
  php bin/console wrap:notificator:mercure:send "Hi" --user=42

  # Custom JSON payload (EN)
  php bin/console wrap:notificator:mercure:send --json='{"status":"info","message":"Ping"}'

  # Turbo Stream (EN)
  php bin/console wrap:notificator:mercure:send "Turbo Toast" --turbo --event=toast
HELP);
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        if (!$this->mercureEnabled || !$this->hub) {
            $output->writeln('<error>Mercure n\'est pas activé ou HubInterface indisponible.</error>');
            return Command::FAILURE;
        }

        $topic = (string)($input->getOption('topic') ?? '');
        $user = $input->getOption('user');
        if ($user) {
            $topic = 'wrap_notificator/user/' . $user;
        }
        if ($topic === '') {
            $topic = $this->defaultTopic; // navigator by default
        }

        $isTurbo = (bool)$input->getOption('turbo');
        $json = $input->getOption('json');
        $messageText = (string)$input->getArgument('message');

        $contentType = null;
        $data = '';

        if ($isTurbo) {
            // Build a minimal Turbo Stream append to the default stream target
            $event = (string)$input->getOption('event');
            $safe = htmlspecialchars($messageText, ENT_QUOTES);
            $ts = (new \DateTimeImmutable())->format(DATE_ATOM);
            $data = <<<HTML
<turbo-stream action="append" target="wrap-notificator-stream">
  <template>
    <div class="wn-event wn-event-$event">
      <small>$ts</small>
      <div>$safe</div>
    </div>
  </template>
</turbo-stream>
HTML;
            $contentType = 'text/vnd.turbo-stream.html';
        } else {
            if ($json) {
                // Validate JSON
                json_decode($json);
                if (json_last_error() !== JSON_ERROR_NONE) {
                    $output->writeln('<error>JSON invalide fourni à --json.</error>');
                    return Command::FAILURE;
                }
                $data = $json;
            } else {
                // Build simple JSON with message
                $data = json_encode([
                    'status' => 'custom',
                    'message' => $messageText,
                    'ts' => (new \DateTimeImmutable())->format(DATE_ATOM),
                ], JSON_UNESCAPED_UNICODE);
            }
        }

        $update = new Update($topic, $data, private: false, id: null, type: $contentType);
        $this->hub->publish($update);

        $output->writeln(sprintf('<info>Publié sur</info> %s %s', $topic, $isTurbo ? '[Turbo]' : '[JSON]'));
        return Command::SUCCESS;
    }
}
