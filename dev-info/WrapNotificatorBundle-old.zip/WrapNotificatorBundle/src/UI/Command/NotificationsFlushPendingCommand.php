<?php

namespace Neox\WrapNotificatorBundle\UI\Command;

use Neox\WrapNotificatorBundle\Application\AsyncNotificator;
use Neox\WrapNotificatorBundle\Application\NotificatorInterface;
use Neox\WrapNotificatorBundle\Infrastructure\Storage\NotificationStorageInterface;
use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;

#[AsCommand(name: 'wrap:notificator:flush-pending', description: 'Send due or batched stored notifications')]
class NotificationsFlushPendingCommand extends Command
{
    public function __construct(
        private readonly NotificationStorageInterface $storage,
        private readonly AsyncNotificator $async,
        private readonly ?NotificatorInterface $sync = null,
    ) {
        parent::__construct();
    }

    protected function configure(): void
    {
        $this
            ->addOption('limit', null, InputOption::VALUE_REQUIRED, 'Maximum items to flush', '100')
            ->addOption('batch-key', null, InputOption::VALUE_REQUIRED, 'Flush only a specific batch key');

        $this->setHelp(<<<'HELP'
FR (Catégorie: Vidage / Envoi différé)
Envoie les notifications stockées et arrivées à échéance, ou uniquement celles d'un lot donné.
L'envoi tente d'abord l'asynchrone, puis retombe en synchronisé en cas d'échec (si disponible).

Usage:
  php bin/console wrap:notificator:flush-pending [--limit=N] [--batch-key=KEY]

Options:
  --limit            Nombre maximum d'éléments à traiter (défaut: 100)
  --batch-key        Ne vider que le lot spécifié

Exemples:
  # Vider toutes les notifications dues (FR)
  php bin/console wrap:notificator:flush-pending

  # Vider au plus 50 éléments (FR)
  php bin/console wrap:notificator:flush-pending --limit=50

  # Vider uniquement le lot "billing" (FR)
  php bin/console wrap:notificator:flush-pending --batch-key=billing

EN (Category: Flushing / Deferred delivery)
Send stored notifications that are due, or flush only a specific batch.
It first tries async dispatch, then falls back to sync if available.

Usage:
  php bin/console wrap:notificator:flush-pending [--limit=N] [--batch-key=KEY]

Options:
  --limit            Max items to process (default: 100)
  --batch-key        Flush only the specified batch

Examples:
  # Flush all due notifications (EN)
  php bin/console wrap:notificator:flush-pending

  # Flush at most 50 items (EN)
  php bin/console wrap:notificator:flush-pending --limit=50

  # Flush only the "billing" batch (EN)
  php bin/console wrap:notificator:flush-pending --batch-key=billing
HELP);
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $limit = (int)$input->getOption('limit');
        $batchKey = $input->getOption('batch-key');
        $items = $batchKey ? $this->storage->fetchBatch($batchKey, $limit) : $this->storage->fetchDue($limit);
        $count = 0; $sent = 0;
        foreach ($items as $item) {
            $count++;
            try {
                $this->async->dispatch($item->message);
                $this->storage->remove($item->id);
                $sent++;
            } catch (\Throwable $e) {
                if ($this->sync) {
                    try {
                        $this->sync->send($item->message);
                        $this->storage->remove($item->id);
                        $sent++;
                    } catch (\Throwable $e2) {
                        // keep for later
                    }
                }
            }
        }
        $output->writeln(sprintf('Flushed %d items; successfully dispatched %d.', $count, $sent));
        return Command::SUCCESS;
    }
}
