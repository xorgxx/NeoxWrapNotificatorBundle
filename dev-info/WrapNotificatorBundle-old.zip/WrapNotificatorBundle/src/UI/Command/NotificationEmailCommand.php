<?php

namespace Neox\WrapNotificatorBundle\UI\Command;

use Neox\WrapNotificatorBundle\Application\AsyncNotificator;
use Neox\WrapNotificatorBundle\Application\NotificatorInterface;
use Neox\WrapNotificatorBundle\Domain\Enum\Channel;
use Neox\WrapNotificatorBundle\Domain\Model\NotificationMessage;
use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

#[AsCommand(name: 'wrap:notificator:test', description: 'Send a test notification')]
class NotificationEmailCommand extends Command
{
    public function __construct(
        private readonly NotificatorInterface $notificator,
        private readonly AsyncNotificator $asyncNotificator,
    ) {
        parent::__construct();
    }

    protected function configure(): void
    {
        $this->addArgument('to', InputArgument::REQUIRED, 'Recipient email or phone');
        $this->addArgument('channel', InputArgument::OPTIONAL, 'Preferred channel (email|sms|webhook|webpush)', 'email');

        $this->setHelp(<<<'HELP'
FR (Catégorie: Tests rapides)
Commande de test pour envoyer une notification simple via le canal choisi. L'envoi se fait en asynchrone (Messenger).

Usage:
  php bin/console wrap:notificator:test <to> [channel]

Arguments:
  to           Email ou téléphone du destinataire
  channel      Canal préféré: email|sms|webhook|webpush (defaut: email)

Exemples:
  # Email (FR)
  php bin/console wrap:notificator:test user@example.org email

  # SMS (FR)
  php bin/console wrap:notificator:test "+33611223344" sms

EN (Category: Quick tests)
Test command to send a simple notification using the preferred channel. Uses asynchronous dispatch (Messenger).

Usage:
  php bin/console wrap:notificator:test <to> [channel]

Arguments:
  to           Recipient email or phone number
  channel      Preferred channel: email|sms|webhook|webpush (default: email)

Examples:
  # Email (EN)
  php bin/console wrap:notificator:test user@example.org email

  # SMS (EN)
  php bin/console wrap:notificator:test "+15551234567" sms
HELP);
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $to = (string)$input->getArgument('to');
        $channel = Channel::from((string)$input->getArgument('channel'));
        $msg = new NotificationMessage(
            subject: 'Test notification',
            bodyText: 'Hello from WrapNotificator',
            bodyHtml: '<p>Hello from <strong>WrapNotificator</strong></p>',
            recipients: [$to],
            channelPreferred: $channel
        );
        $this->asyncNotificator->dispatch($msg);
        $output->writeln('Dispatched test notification '.$msg->id.' to '.$to.' via '.$channel->value);
        return Command::SUCCESS;
    }
}
