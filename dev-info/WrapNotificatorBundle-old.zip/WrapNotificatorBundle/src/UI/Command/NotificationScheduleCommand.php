<?php

namespace Neox\WrapNotificatorBundle\UI\Command;

use Neox\WrapNotificatorBundle\Application\NotificationScheduler;
use Neox\WrapNotificatorBundle\Domain\Enum\Channel;
use Neox\WrapNotificatorBundle\Domain\Model\NotificationMessage;
use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;

#[AsCommand(name: 'wrap:notificator:schedule', description: 'Schedule/store a notification to be sent later or in batch')]
class NotificationScheduleCommand extends Command
{
    public function __construct(private readonly NotificationScheduler $scheduler)
    {
        parent::__construct();
    }

    protected function configure(): void
    {
        $this
            ->addArgument('to', InputArgument::REQUIRED, 'Recipient email or phone')
            ->addOption('channel', null, InputOption::VALUE_REQUIRED, 'Preferred channel (email|sms|webhook|webpush)', 'email')
            ->addOption('delay', null, InputOption::VALUE_REQUIRED, 'Delay seconds before eligible', '0')
            ->addOption('batch-key', null, InputOption::VALUE_REQUIRED, 'Optional batch key');

        $this->setHelp(<<<'HELP'
FR (Catégorie: Planification / Stockage)
Planifie (ou met en file) une notification pour envoi différé ou par lot.

Usage:
  php bin/console wrap:notificator:schedule <to> [--channel=...] [--delay=SECONDS] [--batch-key=KEY]

Arguments:
  to                 Destinataire (email ou téléphone)

Options:
  --channel          Canal préféré: email|sms|webhook|webpush (defaut: email)
  --delay            Délai en secondes avant éligibilité (defaut: 0)
  --batch-key        Clé de lot (facultatif) pour regroupement

Exemples:
  # Planifier un email pour dans 5 minutes (FR)
  php bin/console wrap:notificator:schedule user@example.org --channel=email --delay=300

  # Enregistrer un SMS dans un lot "billing" (FR)
  php bin/console wrap:notificator:schedule "+33611223344" --channel=sms --batch-key=billing

EN (Category: Scheduling / Storage)
Schedule (enqueue) a notification to be delivered later or in batch.

Usage:
  php bin/console wrap:notificator:schedule <to> [--channel=...] [--delay=SECONDS] [--batch-key=KEY]

Arguments:
  to                 Recipient (email or phone)

Options:
  --channel          Preferred channel: email|sms|webhook|webpush (default: email)
  --delay            Delay in seconds before eligible (default: 0)
  --batch-key        Optional batch key for grouping

Examples:
  # Schedule an email in 5 minutes (EN)
  php bin/console wrap:notificator:schedule user@example.org --channel=email --delay=300

  # Enqueue an SMS in a "billing" batch (EN)
  php bin/console wrap:notificator:schedule "+15551234567" --channel=sms --batch-key=billing
HELP);
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $to = (string)$input->getArgument('to');
        $channel = Channel::from((string)$input->getOption('channel'));
        $delay = (int)$input->getOption('delay');
        $batchKey = $input->getOption('batch-key');

        $msg = new NotificationMessage(
            subject: 'Scheduled notification',
            bodyText: 'Hello (scheduled)',
            bodyHtml: '<p>Hello <strong>(scheduled)</strong></p>',
            recipients: [$to],
            channelPreferred: $channel
        );
        $this->scheduler->schedule($msg, $delay, $batchKey);
        $output->writeln(sprintf('Scheduled %s with id %s (delay=%ds%s)', $channel->value, $msg->id, $delay, $batchKey?", batch=$batchKey":""));
        return Command::SUCCESS;
    }
}
