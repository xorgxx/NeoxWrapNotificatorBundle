<?php

namespace Neox\WrapNotificatorBundle\Domain\Enum;

enum Channel: string
{
    case EMAIL = 'email';
    case SMS = 'sms';
    case WEBPUSH = 'webpush';
    case WEBHOOK = 'webhook';
    case IN_APP = 'in_app';
}
