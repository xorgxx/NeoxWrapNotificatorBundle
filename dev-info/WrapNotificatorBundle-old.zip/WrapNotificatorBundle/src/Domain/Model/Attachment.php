<?php

namespace Neox\WrapNotificatorBundle\Domain\Model;

class Attachment
{
    public function __construct(
        public readonly string $filename,
        public readonly string $mimeType,
        public readonly string $contentOrPath,
        public readonly ?string $inlineCid = null,
        public readonly bool $isPath = false,
    ) {
    }
}
