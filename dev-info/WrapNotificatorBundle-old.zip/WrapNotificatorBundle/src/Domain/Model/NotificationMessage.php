<?php

/**
 * NotificationMessage
 *
 * Purpose:
 * - A channel-agnostic DTO carrying both human-readable content (subject/body)
 *   and machine-usable payload (data/metadata) for email, SMS, webhook, webpush, or in-app.
 * - Supports synchronous sending, async dispatch (via Messenger), and queued/deferred delivery.
 *
 * Fields overview:
 * - subject                    : Human-readable short title    (mainly for email/notifications).
 * - bodyText                   : Plain-text body   (fallback when no HTML, or for SMS).
 * - bodyHtml                   : Rich HTML body    (email/webpush). Optional.
 * - data                       : Generic business payload  (serializable key/value) used by templates, webhooks, Mercure, etc.
 * - recipients                 : Target identifiers    (emails, phone numbers, tokens…), depending on the channel.
 * - cc/bcc                     : Email-specific copies     (ignored by non-email channels).
 * - channelPreferred           : Preferred channel; fallback policy applies if delivery fails.
 * - priority                   : Relative priority hint; actual behavior depends on providers.
 * - attachments                : Email attachments     (array of Attachment).
 * - tags                       : Semantic labels   (e.g., 'welcome', 'promo') for filtering/analytics/rules.
 * - metadata                   : Technical options per channel     (e.g., metadata['email']['headers'], metadata['sms']['sender']).
 * - mercureTopics              : Optional list of topics for real-time publishing  (if enabled).
 * - templatePath/templateVars  : Optional Twig template and variables for rendering content.
 * - delaySeconds               : Optional delay (in seconds) for async sending via Messenger.
 *
 * Notes:
 * - Keep $data for business/domain payload; use $metadata for channel-specific technical options.
 * - Prefer serializable scalars/arrays for data/templateVars/metadata.
 * - If async mode is used, delaySeconds is translated to a Messenger DelayStamp.
 */

namespace Neox\WrapNotificatorBundle\Domain\Model;

use Neox\WrapNotificatorBundle\Domain\Enum\Channel;
use Random\RandomException;
use Symfony\Component\Uid\Uuid;

class NotificationMessage
{
    public readonly string $id;

    // Whether to dispatch asynchronously via Messenger
    public bool $async = false;

    /** @param Attachment[] $attachments
     * @throws RandomException
     */
    public function __construct(// Human-readable short subject (email/notification title)
        public ?string  $subject = null,

        // Plain-text body (fallback if no HTML, or for SMS)
        public ?string  $bodyText = null,

        // HTML body (email/webpush rich content). Optional.
        public ?string  $bodyHtml = null,

        // Generic business payload (serializable key/value data)
        // e.g. ['orderId' => 123, 'userName' => 'Alice']
        public array    $data = [],

        // Recipients (emails, phone numbers, tokens…), depending on channel
        public array    $recipients = [],

        // Carbon copy (email only)
        public array    $cc = [],

        // Blind carbon copy (email only)
        public array    $bcc = [],

        // Preferred channel (otherwise default + fallback policy)
        public ?Channel $channelPreferred = null,

        // Relative priority (0 by default). Interpretation depends on channel/provider
        public int      $priority = 0,

        // Attachments (email). Array of Attachment
        public array    $attachments = [],

        // Semantic tags (filtering/analytics/simple rules)
        // e.g. ['welcome','promo','security']
        public array    $tags = [],

        // Technical options per channel
        // e.g. ['email'=>['headers'=>...], 'sms'=>['sender'=>'ACME']]
        public array    $metadata = [],

        // Mercure topics to publish to (real-time). Optional.
        public array    $mercureTopics = [],

        // Twig template (email/sms/webhook), e.g. '@App/mail/welcome.html.twig'
        public ?string  $templatePath = null,

        // Variables passed to the template (prefer serializable scalars/arrays)
        public ?array   $templateVars = null,

        // Delay in seconds for async send (Messenger). Optional.
        public ?int     $delaySeconds = null,)
    {
        $this->id = $this->generateId();
    }

    /**
     * @throws RandomException
     */
    private function generateId(): string
    {
        // Prefer Symfony Uid v7 when available
        if (class_exists('Symfony\\Component\\Uid\\Uuid') && method_exists('Symfony\\Component\\Uid\\Uuid', 'v7')) {
            /** @var object|string $uuid */
            $uuid = Uuid::v7();
            return is_object($uuid) && method_exists($uuid, 'toRfc4122') ? $uuid->toRfc4122() : (string)$uuid;
        }
        // Fallback to RFC4122 v4 style
        $data = random_bytes(16);
        $data[ 6 ] = chr((ord($data[ 6 ]) & 0x0f) | 0x40); // version 4
        $data[ 8 ] = chr((ord($data[ 8 ]) & 0x3f) | 0x80); // variant RFC4122
        return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
    }
}
