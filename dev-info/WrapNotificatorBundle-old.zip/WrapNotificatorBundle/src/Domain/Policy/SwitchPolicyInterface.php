<?php

namespace Neox\WrapNotificatorBundle\Domain\Policy;

use Neox\WrapNotificatorBundle\Domain\Enum\Channel;
use Neox\WrapNotificatorBundle\Domain\Model\NotificationMessage;

interface SwitchPolicyInterface
{
    /**
     * Decide next channel to use given current context.
     * Return null to stop switching.
     */
    public function decideNext(NotificationMessage $message, ?Channel $current, array $available, int $switchCount): ?Channel;
}
