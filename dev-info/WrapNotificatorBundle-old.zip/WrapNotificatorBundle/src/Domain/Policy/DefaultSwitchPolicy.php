<?php

namespace Neox\WrapNotificatorBundle\Domain\Policy;

use Neox\WrapNotificatorBundle\Domain\Enum\Channel;
use Neox\WrapNotificatorBundle\Domain\Model\NotificationMessage;

class DefaultSwitchPolicy implements SwitchPolicyInterface
{
    /**
     * Simple preference -> fallback order respecting max switches.
     */
    public function __construct(
        private readonly string $timezone = 'UTC',
    ) {}

    public function decideNext(NotificationMessage $message, ?Channel $current, array $available, int $switchCount): ?Channel
    {
        // If explicit preference and available, use it first when no current.
        if ($current === null && $message->channelPreferred && in_array($message->channelPreferred, $available, true)) {
            return $message->channelPreferred;
        }

        // Determine fallback chain
        $order = [Channel::EMAIL, Channel::SMS, Channel::WEBPUSH, Channel::WEBHOOK, Channel::IN_APP];
        // Move from current to next
        $startIndex = $current ? array_search($current, $order, true) : -1;
        for ($i = $startIndex + 1; $i < count($order); $i++) {
            if (in_array($order[$i], $available, true)) {
                return $order[$i];
            }
        }

        return null;
    }
}
