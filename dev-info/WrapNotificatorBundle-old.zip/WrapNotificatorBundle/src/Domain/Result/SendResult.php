<?php

namespace Neox\WrapNotificatorBundle\Domain\Result;

use Neox\WrapNotificatorBundle\Domain\Enum\Channel;

class SendResult
{
    public function __construct(
        public bool $success,
        public ?string $providerMessageId = null,
        public array $errors = [],
        public ?Channel $usedChannel = null,
        public int $attempts = 0,
        public ?Channel $switchedFrom = null,
    ) {
    }
}
