<?php

namespace Neox\WrapNotificatorBundle\Infrastructure\Health;

use Neox\WrapNotificatorBundle\Domain\Enum\Channel;

interface ChannelHealthCheckerInterface
{
    public function isHealthy(Channel $channel): bool;
}
