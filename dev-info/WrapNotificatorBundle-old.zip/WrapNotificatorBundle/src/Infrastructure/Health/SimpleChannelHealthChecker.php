<?php

namespace Neox\WrapNotificatorBundle\Infrastructure\Health;

use Neox\WrapNotificatorBundle\Domain\Enum\Channel;

class SimpleChannelHealthChecker implements ChannelHealthCheckerInterface
{
    public function isHealthy(Channel $channel): bool
    {
        // Simple always healthy; can be extended
        return true;
    }
}
