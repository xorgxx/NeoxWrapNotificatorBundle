<?php

namespace Neox\WrapNotificatorBundle\Infrastructure\Messenger\Handler;

use Neox\WrapNotificatorBundle\Application\AsyncNotificator;
use Neox\WrapNotificatorBundle\Application\NotificatorInterface;
use Neox\WrapNotificatorBundle\Infrastructure\Messenger\Message\FlushDueNotificationsMessage;
use Neox\WrapNotificatorBundle\Infrastructure\Storage\NotificationStorageInterface;

class FlushDueNotificationsHandler
{
    public function __construct(
        private readonly NotificationStorageInterface $storage,
        private readonly AsyncNotificator $async,
        private readonly ?NotificatorInterface $sync = null,
    ) {}

    public function __invoke(FlushDueNotificationsMessage $message): void
    {
        $limit = $message->limit > 0 ? $message->limit : 100;
        $items = $message->batchKey ? $this->storage->fetchBatch($message->batchKey, $limit) : $this->storage->fetchDue($limit);
        foreach ($items as $item) {
            try {
                // Prefer async pipeline
                $this->async->dispatch($item->message);
                $this->storage->remove($item->id);
            } catch (\Throwable $e) {
                // fallback to sync if available
                if ($this->sync) {
                    try {
                        $this->sync->send($item->message);
                        $this->storage->remove($item->id);
                    } catch (\Throwable $e2) {
                        // keep item for retry later
                    }
                }
            }
        }
    }
}
