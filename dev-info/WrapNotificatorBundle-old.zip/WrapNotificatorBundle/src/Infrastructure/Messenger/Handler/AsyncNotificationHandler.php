<?php

namespace Neox\WrapNotificatorBundle\Infrastructure\Messenger\Handler;

use Neox\WrapNotificatorBundle\Application\NotificatorInterface;
use Neox\WrapNotificatorBundle\Infrastructure\Messenger\Message\AsyncNotificationMessage;

class AsyncNotificationHandler
{
    public function __construct(private readonly NotificatorInterface $notificator) {}

    public function __invoke(AsyncNotificationMessage $message): void
    {
        $this->notificator->send($message->message);
    }
}
