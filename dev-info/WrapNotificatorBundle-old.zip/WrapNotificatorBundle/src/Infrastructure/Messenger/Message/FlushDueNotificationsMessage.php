<?php

namespace Neox\WrapNotificatorBundle\Infrastructure\Messenger\Message;

class FlushDueNotificationsMessage
{
    public function __construct(public readonly int $limit = 100, public readonly ?string $batchKey = null) {}
}
