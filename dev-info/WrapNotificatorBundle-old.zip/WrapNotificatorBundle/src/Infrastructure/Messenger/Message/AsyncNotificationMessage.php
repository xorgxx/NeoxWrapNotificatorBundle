<?php

namespace Neox\WrapNotificatorBundle\Infrastructure\Messenger\Message;

use Neox\WrapNotificatorBundle\Domain\Model\NotificationMessage;

class AsyncNotificationMessage
{
    public function __construct(public readonly NotificationMessage $message) {}
}
