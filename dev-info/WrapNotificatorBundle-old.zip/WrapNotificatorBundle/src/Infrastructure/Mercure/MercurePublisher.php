<?php

namespace Neox\WrapNotificatorBundle\Infrastructure\Mercure;

use Symfony\Component\Mercure\HubInterface;
use Symfony\Component\Mercure\Update;
use Symfony\Component\Serializer\SerializerInterface;

class MercurePublisher
{
    public function __construct(
        private readonly ?HubInterface $hub = null,
        private readonly bool $enabled = false,
        private readonly ?SerializerInterface $serializer = null,
        private readonly bool $turboEnabled = true,
        private readonly string $defaultTopic = 'wrap_notificator/stream',
        private readonly ?\Twig\Environment $twig = null,
    ) {}

    /**
     * Publie un événement générique en JSON et, si activé, un Turbo Stream sur le topic par défaut.
     *
     * @param string $event
     * @param array<string,mixed> $payload
     * @param string|null $topic
     * @param bool $asPrivate
     * @param string|null $turboType
     */
    public function publish(string $event, array $payload = [], ?string $topic = null, bool $asPrivate = false, ?string $turboType = 'text/vnd.turbo-stream.html'): void
    {
        if (!$this->enabled || !$this->hub) {
            return;
        }

        $topic = $topic ?: ('wrap_notificator/' . $event);
        $data = array_merge([
            'event' => $event,
            'ts' => (new \DateTimeImmutable())->format(DATE_ATOM),
        ], $payload);

        $json = json_encode($data, JSON_UNESCAPED_UNICODE);
        $this->hub->publish(new Update($topic, $json, private: $asPrivate));

        if ($this->turboEnabled && $this->twig) {
            try {
                $html = $this->twig->render('@WrapNotificator/turbo/event.stream.html.twig', [
                    'topic' => $this->defaultTopic,
                    'event' => $event,
                    'data' => $data,
                ]);
                $this->hub->publish(new Update(
                    $this->defaultTopic,
                    $html,
                    private: false,
                    id: null,
                    type: $turboType ?? 'text/vnd.turbo-stream.html'
                ));
            } catch (\Throwable) {
                // On ignore les erreurs Turbo pour ne pas impacter le flux JSON
            }
        }
    }
}
