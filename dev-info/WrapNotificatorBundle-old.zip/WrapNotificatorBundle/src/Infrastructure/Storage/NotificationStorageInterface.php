<?php

namespace Neox\WrapNotificatorBundle\Infrastructure\Storage;

use Neox\WrapNotificatorBundle\Domain\Model\NotificationMessage;

class StoredNotification
{
    public function __construct(
        public readonly string $id,
        public readonly NotificationMessage $message,
        public readonly ?\DateTimeImmutable $sendAfter = null,
        public readonly ?string $batchKey = null,
        public readonly \DateTimeImmutable $createdAt = new \DateTimeImmutable(),
    ) {}
}

interface NotificationStorageInterface
{
    /** Persist a notification for later sending */
    public function store(NotificationMessage $message, ?\DateTimeInterface $sendAfter = null, ?string $batchKey = null): void;

    /**
     * Fetch due notifications (send_after <= now or null), up to limit.
     * Implementations should not remove them automatically.
     *
     * @return StoredNotification[]
     */
    public function fetchDue(int $limit = 100): array;

    /**
     * Fetch notifications by batch key, optionally limited.
     * @return StoredNotification[]
     */
    public function fetchBatch(string $batchKey, int $limit = 100): array;

    /** Remove a stored notification by id after successful send */
    public function remove(string $id): void;
}
