<?php

namespace Neox\WrapNotificatorBundle\Infrastructure\Storage;

use Neox\WrapNotificatorBundle\Domain\Model\NotificationMessage;

class FileNotificationStorage implements NotificationStorageInterface
{
    public function __construct(
        private readonly string $filePath,
        private readonly int $defaultBatchSize = 100,
    ) {
        $dir = dirname($this->filePath);
        if (!is_dir($dir)) {
            @mkdir($dir, 0775, true);
        }
        if (!file_exists($this->filePath)) {
            @touch($this->filePath);
        }
    }

    public function store(NotificationMessage $message, ?\DateTimeInterface $sendAfter = null, ?string $batchKey = null): void
    {
        $row = [
            'id' => $message->id,
            'message' => serialize($message), // PHP serialization to keep objects/attachments
            'send_after' => $sendAfter?->format(DATE_ATOM),
            'batch_key' => $batchKey,
            'created_at' => (new \DateTimeImmutable())->format(DATE_ATOM),
        ];
        $this->appendJsonLine($row);
    }

    public function fetchDue(int $limit = 100): array
    {
        $now = new \DateTimeImmutable();
        $items = [];
        foreach ($this->iterateLines() as $row) {
            if (count($items) >= $limit) break;
            $sendAfter = isset($row['send_after']) && $row['send_after'] ? new \DateTimeImmutable($row['send_after']) : null;
            if ($sendAfter === null || $sendAfter <= $now) {
                $items[] = $this->hydrate($row);
            }
        }
        return $items;
    }

    public function fetchBatch(string $batchKey, int $limit = 100): array
    {
        $items = [];
        foreach ($this->iterateLines() as $row) {
            if (count($items) >= $limit) break;
            if (($row['batch_key'] ?? null) === $batchKey) {
                $items[] = $this->hydrate($row);
            }
        }
        return $items;
    }

    public function remove(string $id): void
    {
        // Rewrite file without the given id
        $tmp = $this->filePath.'.tmp';
        $in = fopen($this->filePath, 'c+');
        if (!$in) return;
        $out = fopen($tmp, 'w');
        if (!$out) { fclose($in); return; }
        if (flock($in, LOCK_EX)) {
            while (($line = fgets($in)) !== false) {
                $line = trim($line);
                if ($line === '') continue;
                $row = json_decode($line, true);
                if (!is_array($row) || ($row['id'] ?? null) === $id) {
                    continue; // skip removed
                }
                fwrite($out, json_encode($row, JSON_UNESCAPED_UNICODE)."\n");
            }
            fflush($out); fclose($out);
            // Replace original
            rename($tmp, $this->filePath);
            flock($in, LOCK_UN);
        }
        fclose($in);
    }

    private function hydrate(array $row): StoredNotification
    {
        /** @var NotificationMessage $message */
        $message = unserialize($row['message']);
        $sendAfter = isset($row['send_after']) && $row['send_after'] ? new \DateTimeImmutable($row['send_after']) : null;
        $createdAt = isset($row['created_at']) ? new \DateTimeImmutable($row['created_at']) : new \DateTimeImmutable();
        return new StoredNotification($row['id'], $message, $sendAfter, $row['batch_key'] ?? null, $createdAt);
    }

    private function appendJsonLine(array $row): void
    {
        $fh = fopen($this->filePath, 'a');
        if (!$fh) return;
        if (flock($fh, LOCK_EX)) {
            fwrite($fh, json_encode($row, JSON_UNESCAPED_UNICODE)."\n");
            fflush($fh);
            flock($fh, LOCK_UN);
        }
        fclose($fh);
    }

    private function iterateLines(): \Generator
    {
        $fh = fopen($this->filePath, 'r');
        if (!$fh) return; // empty generator
        while (($line = fgets($fh)) !== false) {
            $line = trim($line);
            if ($line === '') continue;
            $row = json_decode($line, true);
            if (is_array($row)) {
                yield $row;
            }
        }
        fclose($fh);
    }
}
