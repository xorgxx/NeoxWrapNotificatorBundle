<?php

namespace Neox\WrapNotificatorBundle\Infrastructure\Channel\Sms;

use Neox\WrapNotificatorBundle\Domain\Enum\Channel;
use Neox\WrapNotificatorBundle\Domain\Model\NotificationMessage;
use Neox\WrapNotificatorBundle\Domain\Result\SendResult;
use Neox\WrapNotificatorBundle\Infrastructure\Channel\ChannelSenderInterface;
use Neox\WrapNotificatorBundle\Infrastructure\Channel\Sms\Provider\SmsProviderInterface;
use Twig\Environment;

class SmsChannelSender implements ChannelSenderInterface
{
    public function __construct(
        private readonly SmsProviderInterface $provider,
        private readonly array $config = [],
        private readonly ?string $templatesBasePath = null,
        private readonly ?Environment $twig = null,
    ) {}

    public function supports(Channel $channel): bool
    {
        return $channel === Channel::SMS;
    }

    public function send(NotificationMessage $message): SendResult
    {
        $text = $message->bodyText ?? strip_tags((string)$message->bodyHtml);
        // Render from template if provided and Twig available
        if ($message->templatePath && $this->twig) {
            $vars = $message->templateVars ?? $this->buildDefaultTemplateVars($message);
            $rendered = $this->renderTemplateWithBase($message->templatePath, $vars);
            $text = trim(strip_tags($rendered));
        }

        $toList = $message->recipients ?: [];
        $lastResponse = null;
        foreach ($toList as $to) {
            $lastResponse = $this->provider->send($to, $text, $message->metadata['sms'] ?? []);
            if (!$lastResponse->success) {
                throw new \RuntimeException($lastResponse->error ?? 'SMS failed');
            }
        }
        return new SendResult(true, $lastResponse?->messageId, [], Channel::SMS, 1, null);
    }

    private function buildDefaultTemplateVars(NotificationMessage $message): array
    {
        return [
            'id' => $message->id,
            'subject' => $message->subject,
            'bodyText' => $message->bodyText,
            'bodyHtml' => $message->bodyHtml,
            'data' => $message->data,
            'recipients' => $message->recipients,
            'tags' => $message->tags,
            'metadata' => $message->metadata,
            'time' => (new \DateTimeImmutable())->format(DATE_ATOM),
        ];
    }

    private function renderTemplateWithBase(string $template, array $vars): string
    {
        if (!$this->twig) {
            return '';
        }
        if (str_starts_with($template, '@')) {
            return $this->twig->render($template, $vars);
        }
        $base = $this->templatesBasePath ? rtrim($this->templatesBasePath, "\\/") : '';
        if ($base !== '') {
            $candidate = $base . DIRECTORY_SEPARATOR . ltrim($template, "\\/");
            if (is_file($candidate) && is_readable($candidate)) {
                $source = file_get_contents($candidate) ?: '';
                return $this->twig->createTemplate($source)->render($vars);
            }
        }
        return $this->twig->render($template, $vars);
    }
}
