<?php

namespace Neox\WrapNotificatorBundle\Infrastructure\Channel\Sms\Dsn;

use Neox\WrapNotificatorBundle\Infrastructure\Channel\Sms\Provider\NullSmsProvider;
use Neox\WrapNotificatorBundle\Infrastructure\Channel\Sms\Provider\SmsProviderInterface;
use Symfony\Component\Mailer\Transport\Dsn;

class NullSmsProviderFactory implements SmsProviderFactoryInterface
{
    public function supports(Dsn $dsn): bool
    {
        $scheme = strtolower($dsn->getScheme());
        return $scheme === 'null' || $scheme === 'sms+null' || $scheme === '';
    }

    public function create(Dsn $dsn): SmsProviderInterface
    {
        return new NullSmsProvider();
    }
}
