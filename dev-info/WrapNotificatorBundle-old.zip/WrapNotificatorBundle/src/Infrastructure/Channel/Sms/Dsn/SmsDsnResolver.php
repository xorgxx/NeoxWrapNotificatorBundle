<?php

namespace Neox\WrapNotificatorBundle\Infrastructure\Channel\Sms\Dsn;

use Neox\WrapNotificatorBundle\Infrastructure\Channel\Sms\Provider\NullSmsProvider;
use Neox\WrapNotificatorBundle\Infrastructure\Channel\Sms\Provider\SmsProviderInterface;
use Symfony\Component\Mailer\Transport\Dsn;

class SmsDsnResolver
{
    /** @param iterable<SmsProviderFactoryInterface> $factories */
    public function __construct(private readonly iterable $factories)
    {
    }

    /**
     * Build provider from config DSN; if not provided, try to synthesize from legacy options.
     */
    public function fromConfig(?string $dsn, array $smsConfig): SmsProviderInterface
    {
        $dsnString = $dsn;
        if (!$dsnString || trim($dsnString) === '') {
            // Backward compatibility: honor 'provider' and 'twilio' config
            $provider = (string)($smsConfig['provider'] ?? 'null');
            if ($provider === 'twilio') {
                $acc = $smsConfig['twilio']['account_sid'] ?? '';
                $tok = $smsConfig['twilio']['auth_token'] ?? '';
                $from = $smsConfig['twilio']['from'] ?? ($smsConfig['from'] ?? '');
                $query = $from ? ('?from=' . rawurlencode($from)) : '';
                $dsnString = sprintf('sms+twilio://%s:%s@default%s', $acc, $tok, $query);
            } else {
                $dsnString = 'sms+null://default';
            }
        }

        $dsnObj = $this->parseDsn($dsnString);
        foreach ($this->factories as $factory) {
            if ($factory->supports($dsnObj)) {
                return $factory->create($dsnObj);
            }
        }
        // Fallback
        return new NullSmsProvider();
    }

    private function parseDsn(string $dsn): Dsn
    {
        // If missing scheme, assume null
        if (!str_contains($dsn, '://')) {
            $dsn = 'sms+null://' . ltrim($dsn, '/');
        }
        // Symfony Mailer Dsn is convenient to reuse here
        return Dsn::fromString($dsn);
    }
}
