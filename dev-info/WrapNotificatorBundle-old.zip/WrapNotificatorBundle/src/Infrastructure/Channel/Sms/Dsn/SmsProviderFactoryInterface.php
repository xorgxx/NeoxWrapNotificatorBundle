<?php

namespace Neox\WrapNotificatorBundle\Infrastructure\Channel\Sms\Dsn;

use Neox\WrapNotificatorBundle\Infrastructure\Channel\Sms\Provider\SmsProviderInterface;
use Symfony\Component\Mailer\Transport\Dsn;

interface SmsProviderFactoryInterface
{
    /**
     * Whether this factory supports the given DSN (by scheme or other criteria).
     */
    public function supports(Dsn $dsn): bool;

    /**
     * Create a provider from DSN.
     */
    public function create(Dsn $dsn): SmsProviderInterface;
}
