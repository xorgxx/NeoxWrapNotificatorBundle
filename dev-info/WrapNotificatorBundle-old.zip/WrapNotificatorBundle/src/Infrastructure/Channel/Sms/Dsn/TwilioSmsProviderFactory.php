<?php

namespace Neox\WrapNotificatorBundle\Infrastructure\Channel\Sms\Dsn;

use Neox\WrapNotificatorBundle\Infrastructure\Channel\Sms\Provider\TwilioSmsProvider;
use Neox\WrapNotificatorBundle\Infrastructure\Channel\Sms\Provider\SmsProviderInterface;
use Symfony\Component\Mailer\Transport\Dsn;
use Symfony\Contracts\HttpClient\HttpClientInterface;

class TwilioSmsProviderFactory implements SmsProviderFactoryInterface
{
    public function __construct(private readonly HttpClientInterface $httpClient) {}

    public function supports(Dsn $dsn): bool
    {
        $scheme = strtolower($dsn->getScheme());
        return $scheme === 'twilio' || $scheme === 'sms+twilio';
    }

    public function create(Dsn $dsn): SmsProviderInterface
    {
        $account = $dsn->getUser();
        $token = $dsn->getPassword();
        $from = $dsn->getOption('from');
        $config = [
            'account_sid' => $account,
            'auth_token' => $token,
            'from' => $from,
        ];
        return new TwilioSmsProvider($this->httpClient, $config);
    }
}
