<?php

namespace Neox\WrapNotificatorBundle\Infrastructure\Channel\Sms\Provider;

class SmsSendResponse
{
    public function __construct(
        public bool $success,
        public ?string $messageId = null,
        public ?string $error = null,
        public int $statusCode = 200,
    ) {}
}

interface SmsProviderInterface
{
    public function send(string $to, string $message, array $options = []): SmsSendResponse;
}
