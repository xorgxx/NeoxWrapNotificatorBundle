<?php

namespace Neox\WrapNotificatorBundle\Infrastructure\Channel\Sms\Provider;

use Symfony\Contracts\HttpClient\HttpClientInterface;

class TwilioSmsProvider implements SmsProviderInterface
{
    private string $accountSid;
    private string $authToken;
    private string $from;

    public function __construct(private readonly HttpClientInterface $httpClient, array $config = [])
    {
        $this->accountSid = (string)($config['account_sid'] ?? getenv('TWILIO_ACCOUNT_SID'));
        $this->authToken = (string)($config['auth_token'] ?? getenv('TWILIO_AUTH_TOKEN'));
        $this->from = (string)($config['from'] ?? getenv('TWILIO_FROM'));
    }

    public function send(string $to, string $message, array $options = []): SmsSendResponse
    {
        if (!$this->accountSid || !$this->authToken || !$this->from) {
            return new SmsSendResponse(false, null, 'Twilio not configured', 400);
        }
        $url = sprintf('https://api.twilio.com/2010-04-01/Accounts/%s/Messages.json', $this->accountSid);
        try {
            $response = $this->httpClient->request('POST', $url, [
                'auth_basic' => [$this->accountSid, $this->authToken],
                'body' => [
                    'From' => $this->from,
                    'To' => $to,
                    'Body' => $message,
                ],
            ]);
            $status = $response->getStatusCode();
            $data = $response->toArray(false);
            if ($status >= 200 && $status < 300) {
                return new SmsSendResponse(true, $data['sid'] ?? null, null, $status);
            }
            $retryable = in_array($status, [429,500,502,503,504], true);
            return new SmsSendResponse(false, null, $data['message'] ?? 'Twilio error', $status);
        } catch (\Throwable $e) {
            return new SmsSendResponse(false, null, $e->getMessage(), 500);
        }
    }
}
