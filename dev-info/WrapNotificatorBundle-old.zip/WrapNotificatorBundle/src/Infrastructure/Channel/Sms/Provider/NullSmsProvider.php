<?php

namespace Neox\WrapNotificatorBundle\Infrastructure\Channel\Sms\Provider;

class NullSmsProvider implements SmsProviderInterface
{
    public function send(string $to, string $message, array $options = []): SmsSendResponse
    {
        return new SmsSendResponse(true, 'null-'.md5($to.$message));
    }
}
