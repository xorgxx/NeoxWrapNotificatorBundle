<?php

namespace Neox\WrapNotificatorBundle\Infrastructure\Channel\Email;

use Neox\WrapNotificatorBundle\Domain\Enum\Channel;
use Neox\WrapNotificatorBundle\Domain\Model\Attachment;
use Neox\WrapNotificatorBundle\Domain\Model\NotificationMessage;
use Neox\WrapNotificatorBundle\Domain\Result\SendResult;
use Neox\WrapNotificatorBundle\Infrastructure\Channel\ChannelSenderInterface;
use Symfony\Component\Mailer\MailerInterface;
use Symfony\Component\Mime\Address;
use Symfony\Component\Mime\Email;
use Symfony\Component\Mime\Part\DataPart;
use Symfony\Component\Mime\Part\File;
use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Error\SyntaxError;

class MailerChannelSender implements ChannelSenderInterface
{
    public function __construct(
        private readonly MailerInterface $mailer,
        private readonly array $config = [],
        private readonly ?string $templatesBasePath = null,
        private readonly ?Environment $twig = null,
    ) {}

    public function supports(Channel $channel): bool
    {
        return $channel === Channel::EMAIL;
    }

    public function send(NotificationMessage $message): SendResult
    {
        $email = (new Email());
        $from = $this->config['from'] ?? null;
        if ($from) {
            $email->from(new Address($from));
        }

        // Render from template if provided and Twig available
        if ($message->templatePath && $this->twig) {
            $vars = $message->templateVars ?? $this->buildDefaultTemplateVars($message);
            $rendered = $this->renderTemplateWithBase($message->templatePath, $vars);
            // Heuristic: if template filename suggests HTML, set as HTML, else as text
            if (str_ends_with((string)$message->templatePath, '.html.twig') || str_contains($rendered, '<')) {
                $message->bodyHtml = $rendered;
            } else {
                $message->bodyText = $rendered;
            }
        }

        if ($message->subject) {
            $email->subject($message->subject);
        }
        if ($message->bodyHtml) {
            $email->html($message->bodyHtml);
        }
        if ($message->bodyText) {
            $email->text($message->bodyText);
        }
        if ($message->recipients) {
            $email->to(...array_map(fn($r) => new Address($r), $message->recipients));
        }
        if ($message->cc) {
            $email->cc(...array_map(fn($r) => new Address($r), $message->cc));
        }
        if ($message->bcc) {
            $email->bcc(...array_map(fn($r) => new Address($r), $message->bcc));
        }

        $this->handleAttachments($email, $message->attachments);

        $this->mailer->send($email);

        return new SendResult(true, null, [], Channel::EMAIL, 1, null);
    }

    private function handleAttachments(Email $email, array $attachments): void
    {
        $allowed = $this->config['allowed_mime_types'] ?? [];
        $maxMb = (int)($this->config['max_total_size_mb'] ?? 10);
        $maxBytes = $maxMb * 1024 * 1024;
        $total = 0;

        foreach ($attachments as $att) {
            if (!$att instanceof Attachment) {
                continue;
            }
            if ($allowed && !in_array($att->mimeType, $allowed, true)) {
                throw new \InvalidArgumentException('AttachmentRejected: MIME not allowed');
            }
            if ($att->isPath) {
                if (!is_file($att->contentOrPath)) {
                    throw new \InvalidArgumentException('AttachmentRejected: file not found');
                }
                $size = filesize($att->contentOrPath) ?: 0;
                $total += $size;
                if ($total > $maxBytes) {
                    throw new \InvalidArgumentException('AttachmentRejected: total size exceeded');
                }
                if ($att->inlineCid) {
                    $email->embedFromPath($att->contentOrPath, $att->inlineCid, $att->mimeType);
                } else {
                    $email->attachFromPath($att->contentOrPath, $att->filename, $att->mimeType);
                }
            } else {
                $content = $att->contentOrPath;
                $size = strlen($content);
                $total += $size;
                if ($total > $maxBytes) {
                    throw new \InvalidArgumentException('AttachmentRejected: total size exceeded');
                }
                $part = new DataPart($content, $att->filename, $att->mimeType);
                if ($att->inlineCid) {
                    $email->embed($part, $att->inlineCid);
                } else {
                    $email->attachPart($part);
                }
            }
        }
    }

    private function buildDefaultTemplateVars(NotificationMessage $message): array
    {
        return [
            'id' => $message->id,
            'subject' => $message->subject,
            'bodyText' => $message->bodyText,
            'bodyHtml' => $message->bodyHtml,
            'data' => $message->data,
            'recipients' => $message->recipients,
            'tags' => $message->tags,
            'metadata' => $message->metadata,
            'time' => (new \DateTimeImmutable())->format(DATE_ATOM),
        ];
    }

    /**
     * @throws SyntaxError
     * @throws RuntimeError
     * @throws LoaderError
     */
    private function renderTemplateWithBase(string $template, array $vars): string
    {
        if (!$this->twig) {
            return '';
        }
        // If user provided a namespaced Twig template, render directly
        if (str_starts_with($template, '@')) {
            return $this->twig->render($template, $vars);
        }
        // Try filesystem under configured base path
        $base = $this->templatesBasePath ? rtrim($this->templatesBasePath, "\\/") : '';
        if ($base !== '') {
            $candidate = $base . DIRECTORY_SEPARATOR . ltrim($template, "\\/");
            if (is_file($candidate) && is_readable($candidate)) {
                $source = file_get_contents($candidate) ?: '';
                return $this->twig->createTemplate($source)->render($vars);
            }
        }
        // Fallback: attempt to render as a regular Twig template name
        return $this->twig->render($template, $vars);
    }
}
