<?php

namespace Neox\WrapNotificatorBundle\Infrastructure\Channel\Webpush;

use Neox\WrapNotificatorBundle\Domain\Enum\Channel;
use Neox\WrapNotificatorBundle\Domain\Model\NotificationMessage;
use Neox\WrapNotificatorBundle\Domain\Result\SendResult;
use Neox\WrapNotificatorBundle\Infrastructure\Channel\ChannelSenderInterface;

class WebpushChannelSender implements ChannelSenderInterface
{
    public function __construct(private readonly array $config = []) {}

    public function supports(\Neox\WrapNotificatorBundle\Domain\Enum\Channel $channel): bool
    {
        return $channel === Channel::WEBPUSH;
    }

    public function send(NotificationMessage $message): SendResult
    {
        // Stub: pretend success
        return new SendResult(true, 'webpush-stub', [], Channel::WEBPUSH, 1, null);
    }
}
