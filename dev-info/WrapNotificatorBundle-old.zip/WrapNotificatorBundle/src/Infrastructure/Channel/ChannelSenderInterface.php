<?php

namespace Neox\WrapNotificatorBundle\Infrastructure\Channel;

use Neox\WrapNotificatorBundle\Domain\Enum\Channel;
use Neox\WrapNotificatorBundle\Domain\Model\NotificationMessage;
use Neox\WrapNotificatorBundle\Domain\Result\SendResult;

interface ChannelSenderInterface
{
    public function supports(Channel $channel): bool;

    /** @throws \Throwable on failure */
    public function send(NotificationMessage $message): SendResult;
}
