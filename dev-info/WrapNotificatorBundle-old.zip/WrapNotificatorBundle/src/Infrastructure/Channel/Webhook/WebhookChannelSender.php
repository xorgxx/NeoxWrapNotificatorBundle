<?php

namespace Neox\WrapNotificatorBundle\Infrastructure\Channel\Webhook;

use Neox\WrapNotificatorBundle\Domain\Enum\Channel;
use Neox\WrapNotificatorBundle\Domain\Model\NotificationMessage;
use Neox\WrapNotificatorBundle\Domain\Result\SendResult;
use Neox\WrapNotificatorBundle\Infrastructure\Channel\ChannelSenderInterface;
use Symfony\Contracts\HttpClient\HttpClientInterface;

class WebhookChannelSender implements ChannelSenderInterface
{
    public function __construct(private readonly HttpClientInterface $httpClient, private readonly array $config = []) {}

    public function supports(Channel $channel): bool
    {
        return $channel === Channel::WEBHOOK;
    }

    public function send(NotificationMessage $message): SendResult
    {
        $url = $message->metadata['webhook']['url'] ?? null;
        if (!$url) {
            throw new \InvalidArgumentException('Webhook URL missing');
        }
        $timeout = (int)($this->config['timeout'] ?? 10);
        $response = $this->httpClient->request('POST', $url, [
            'timeout' => $timeout,
            'json' => [
                'id' => $message->id,
                'subject' => $message->subject,
                'bodyText' => $message->bodyText,
                'bodyHtml' => $message->bodyHtml,
                'data' => $message->data,
                'tags' => $message->tags,
            ],
        ]);
        $status = $response->getStatusCode();
        if ($status >= 200 && $status < 300) {
            return new SendResult(true, (string)$status, [], Channel::WEBHOOK, 1, null);
        }
        throw new \RuntimeException('Webhook failed with status ' . $status);
    }
}
