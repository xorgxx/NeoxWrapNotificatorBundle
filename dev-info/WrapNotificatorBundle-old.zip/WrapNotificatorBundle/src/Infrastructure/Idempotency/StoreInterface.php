<?php

namespace Neox\WrapNotificatorBundle\Infrastructure\Idempotency;

interface StoreInterface
{
    public function exists(string $key): bool;
    public function store(string $key, int $ttlSeconds = 86400): void;
}
