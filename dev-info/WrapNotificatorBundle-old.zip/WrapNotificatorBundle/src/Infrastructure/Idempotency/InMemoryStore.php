<?php

namespace Neox\WrapNotificatorBundle\Infrastructure\Idempotency;

class InMemoryStore implements StoreInterface
{
    private array $store = [];

    public function exists(string $key): bool
    {
        return isset($this->store[$key]) && $this->store[$key] > time();
    }

    public function store(string $key, int $ttlSeconds = 86400): void
    {
        $this->store[$key] = time() + $ttlSeconds;
    }
}
