<?php

namespace Neox\WrapNotificatorBundle\DependencyInjection;

use Symfony\Component\Config\FileLocator;
use Symfony\Component\DependencyInjection\ContainerBuilder;
use Symfony\Component\DependencyInjection\Extension\Extension;
use Symfony\Component\DependencyInjection\Extension\PrependExtensionInterface;
use Symfony\Component\DependencyInjection\Loader\PhpFileLoader;

class WrapNotificatorExtension extends Extension implements PrependExtensionInterface
{
    public function load(array $configs, ContainerBuilder $container)
    {
        $configuration = new Configuration();
        $config = $this->processConfiguration($configuration, $configs);

        // Store the whole config array for attribute injection and other uses
        $container->setParameter('wrap_notificator.config', $config);

        // Automatically expose all nested config values as container parameters
        $this->registerConfigParameters($container, $config, 'wrap_notificator');

        $loader = new PhpFileLoader($container, new FileLocator(__DIR__ . '/../../config'));
        // load service definitions if present
        try {
            $loader->load('services.php');
        } catch (\Exception $e) {
            // optional
        }
    }

    private function registerConfigParameters(ContainerBuilder $container, array $config, string $prefix = 'wrap_notificator'): void
    {
        foreach ($config as $key => $value) {
            $paramKey = $prefix . '.' . $key;

            if (is_array($value)) {
                // Set the aggregate array parameter
                $container->setParameter($paramKey, $value);
                // And also expose nested keys for associative arrays
                if (!$this->isSimpleArray($value)) {
                    $this->registerConfigParameters($container, $value, $paramKey);
                }
            } else {
                $container->setParameter($paramKey, $value);
            }
        }
    }

    private function isSimpleArray(array $array): bool
    {
        if (empty($array)) {
            return true;
        }
        return array_keys($array) === range(0, count($array) - 1);
    }

    public function prepend(ContainerBuilder $container): void
    {
        // Read this bundle's configuration (may be empty at this point)
        $configs = $container->getExtensionConfig($this->getAlias());
        $processed = $this->processConfiguration(new Configuration(), $configs);

        $level = $processed['logging']['level'] ?? 'info';
        $channel = $processed['logging']['channel'] ?? 'wrap_notificator';

        // Prepend Monolog configuration to keep it inside the bundle
        if (in_array('monolog', $container->getExtensions() ? array_keys($container->getExtensions()) : [], true)) {
            $container->prependExtensionConfig('monolog', [
                'channels' => [$channel],
                'handlers' => [
                    $channel => [
                        'type' => 'rotating_file',
                        'path' => '%kernel.logs_dir%/' . $channel . '_%kernel.environment%.log',
                        'level' => $level,
                        'max_files' => 7,
                        'channels' => [$channel],
                    ],
                ],
            ]);
        }

        // Prepend Twig paths for bundle templates (namespace: WrapNotificator)
        if (in_array('twig', $container->getExtensions() ? array_keys($container->getExtensions()) : [], true)) {
            $container->prependExtensionConfig('twig', [
                'paths' => [
                    '%kernel.project_dir%/bundle/WrapNotificatorBundle/src/Resources/views' => 'WrapNotificator',
                    '%kernel.project_dir%/bundle/WrapNotificatorBundle/Templates' => 'WrapNotificator',
                ],
            ]);
        }
    }
}
