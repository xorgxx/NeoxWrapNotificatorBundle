<?php

namespace Neox\WrapNotificatorBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class WrapNotificatorBundle extends Bundle
{
}
