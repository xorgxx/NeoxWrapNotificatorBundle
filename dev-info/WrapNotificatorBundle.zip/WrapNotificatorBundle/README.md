# WrapNotificatorBundle

Un bundle Symfony 7.3 / PHP 8.3 fournissant une façade ergonomique au-dessus de Symfony Mailer + Notifier + Mercure + Web Push (minishlink/web-push).

Schéma rapide:

```
[Your Code]
   ↓
NotifierFacade (API de façade)
   ↓                   \
MessageFactory         TypedSender
   ↓                         ↓
Email/Chat/SMS/DTOs  Mailer / Notifier / Mercure / WebPush
```

## Installation

```
composer require wrap/notificator-bundle
composer require symfony/mailer symfony/notifier symfony/mercure-bundle minishlink/web-push
```

Ajoutez le bundle si votre auto‑découverte n'est pas active (Symfony Flex le fait normalement) :

```php
// config/bundles.php
return [
    // ...
    WrapNotificatorBundle\WrapNotificatorBundle::class => ['all' => true],
];
```

## Configuration (exemples)

- Mailer DSN
```
MAILER_DSN=smtp://localhost:1025
```

- Notifier DSN (Slack/Telegram/Twilio)
```
SLACK_DSN=slack://xoxb-***@default?channel=my-channel
TELEGRAM_DSN=telegram://bot-token@default?channel=@my_channel
TWILIO_DSN=twilio://SID:TOKEN@default?from=%2B33600000000
```

- Mercure Hub
```
MERCURE_URL=http://localhost:3000/.well-known/mercure
MERCURE_PUBLIC_URL=http://localhost:3000/.well-known/mercure
MERCURE_JWT_SECRET=!ChangeMe!
```

- Web Push (VAPID)
```
VAPID_PUBLIC_KEY=yourPublicKey
VAPID_PRIVATE_KEY=yourPrivateKey
VAPID_SUBJECT=mailto:you@example.com
```

Voir aussi `config/packages/wrap_notificator.yaml` fourni.

## API de façade

Toutes les méthodes retournent un `DeliveryStatus` avec un `uuid` v4 auto et ne lèvent pas d’exception (en cas d’erreur → `failed`). Chaque méthode accepte en plus un contexte optionnel `?DeliveryContext $ctx` pour la corrélation et l’idempotence.

- `notifyEmail(subject, htmlOrText, to, isHtml=true, opts=[], metadata=[], ?DeliveryContext $ctx = null) : DeliveryStatus`
- `notifySms(content, to, metadata=[], ?DeliveryContext $ctx = null) : DeliveryStatus`
- `notifyChat(transport, content, subject=null, opts=[], metadata=[], ?DeliveryContext $ctx = null) : DeliveryStatus`
- `notifyBrowser(topic, data=array, metadata=[], ?DeliveryContext $ctx = null) : DeliveryStatus` (Mercure)
- `notifyPush(subscription, data, ttl=null, metadata=[], ?DeliveryContext $ctx = null) : DeliveryStatus` (Web Push)
- `notifyDesktop(subscription, data, ttl=null, metadata=[], ?DeliveryContext $ctx = null) : DeliveryStatus` (alias Push)

`DeliveryStatus` = `{ uuid, channel, status(sent|queued|failed), message?, id?, metadata[] }`.

## Factory (MessageFactory)

- `email(subject, content, to, opts=[]) : Email`
  - `opts['html']` boolean (par défaut true)
  - `opts['from'] = [address, name]`
- `sms(content, to) : SmsMessage`
- `chat(transport, content, subject=null, opts=[]) : ChatMessage`
  - SlackOptions supportés: `channel`, `iconEmoji`, `blocks`
  - TelegramOptions: `chatId`, `parseMode`, `disableWebPagePreview`
- `browser(topic, data) : BrowserPayload`
- `push(subscription, data, ttl=null) : WebPushMessage`
  - `subscription = {"endpoint":"...","keys":{"p256dh":"...","auth":"..."}}`

Les JSON sont encodés sans échappements inutiles (`JSON_UNESCAPED_*`).

## Sender (TypedSender)

Construit avec des services optionnels: `MailerInterface`, `ChatterInterface`, `TexterInterface`, `HubInterface` (Mercure), `Minishlink\WebPush\WebPush`.

Méthodes:
- `sendEmail(Email)`
- `sendSms(SmsMessage)`
- `sendChat(ChatMessage)`
- `sendBrowser(BrowserPayload)` → met l’ID retourné par `publish()` dans `id` si disponible
- `sendPush(WebPushMessage)` → utilise `sendOneNotification()`; en cas d’échec, `message = report->getReason()`

Aucune méthode ne lève d’exception; elles renvoient un `DeliveryStatus::failed()` en cas d’erreur.

## CLI

Commande unique: `bin/console notify:send`

Options:
- `--channel=email|sms|chat|browser|push|desktop` (obligatoire)
- Email: `--to`, `--subject`, `--html`, `--text`
- SMS: `--to`, `--text`
- Chat: `--transport=slack|telegram`, `--text`, `--subject`, `--opt=key:value` (répétable)
- Browser: `--topic`, `--data=key:value` (répétable)
- Push/Desktop: `--subscription-file=path.json`, `--data=key:value`, `--ttl=3600`

Affiche le JSON du `DeliveryStatus` sur `stdout`. Code retour: `0` si `sent|queued`, `1` si `failed`.

### Exemples notify:send

Les exemples ci-dessous couvrent tous les canaux et les principales options. Chaque commande imprime un `DeliveryStatus` JSON. Sur Windows PowerShell, préférez les guillemets doubles et échappez le contenu HTML/JSON si nécessaire.

#### Email

- Email HTML (Unix/macOS/bash):
```bash
php bin/console notify:send \
  --channel=email \
  --to="user@example.com" \
  --subject="Bienvenue" \
  --html='<h1>Bonjour</h1><p>Bienvenue !</p>'
```

- Email texte (Unix/macOS/bash):
```bash
php bin/console notify:send \
  --channel=email \
  --to="user@example.com" \
  --subject="Info" \
  --text="Message texte brut"
```

- Email HTML (Windows PowerShell):
```powershell
php bin/console notify:send `
  --channel=email `
  --to="user@example.com" `
  --subject="Bienvenue" `
  --html='<h1>Bonjour</h1><p>Bienvenue !</p>'
```

#### SMS

- SMS simple:
```bash
php bin/console notify:send \
  --channel=sms \
  --to="+33600000000" \
  --text="Hello depuis Notify"
```

- SMS avec idempotence (déduplication 15 min):
```bash
php bin/console notify:send \
  --channel=sms --to="+33600000000" --text="Rappel" \
  --dedupe-key="reminder:user:42:2025-12-01" --dedupe-ttl=900
```

#### Chat

- Slack (canal + icône):
```bash
php bin/console notify:send \
  --channel=chat \
  --transport=slack \
  --text="Déploiement terminé" \
  --subject="Release 1.2" \
  --opt=channel:ops --opt=iconEmoji::rocket:
```

- Telegram (chatId + parseMode HTML):
```bash
php bin/console notify:send \
  --channel=chat \
  --transport=telegram \
  --text="<b>Alerte</b> service indisponible" \
  --subject="Incident" \
  --opt=chatId:123456789 --opt=parseMode:HTML --opt=disableWebPagePreview:1
```

Astuce: vous pouvez ajouter `--dedupe-key`/`--dedupe-ttl` pour éviter les doublons lors des relances.

#### Browser (Mercure)

- Publication sur un topic avec données clés/valeurs:
```bash
php bin/console notify:send --channel=browser --topic='users:42' --data=type:notification --data=title:"Bienvenue" --data=level:info
```

#### Push et Desktop (Web Push)

1) Créez un fichier d’abonnement (ex: `sub.json`):
```json
{
  "endpoint": "https://fcm.googleapis.com/fcm/send/abc...",
  "keys": { "p256dh": "...", "auth": "..." }
}
```

2) Envoyez une notification Push avec TTL et payload:
```bash
php bin/console notify:send \
  --channel=push \
  --subscription-file=./sub.json \
  --data=title:"Hello" --data=body:"Nouvelle alerte" \
  --ttl=120
```

3) Alias Desktop (mêmes paramètres que Push):
```bash
php bin/console notify:send \
  --channel=desktop \
  --subscription-file=./sub.json \
  --data=title:"Hello" --data=body:"Notification bureau"
```

- Variante Windows PowerShell:
```powershell
php bin/console notify:send `
  --channel=push `
  --subscription-file=".\sub.json" `
  --data=title:"Hello" `
  --data=body:"Notification"
```

#### Corrélation (CorrelationId) et Idempotence (DedupeKey)

- Clé de déduplication + TTL:
```bash
php bin/console notify:send \
  --channel=email \
  --to="user@example.com" --subject="Rappel" --text="AG ce soir" \
  --dedupe-key="ag.reminder:42:2025-12-01" --dedupe-ttl=900
```

- CorrelationId explicite:
```bash
php bin/console notify:send \
  --channel=sms --to="+33600000000" --text="Ping" \
  --correlation-id=4f6a4b73-0f4c-4d48-9f6a-9dc2b7b6c001
```

#### Codes de retour
- 0 quand le statut est `sent` ou `queued` (déduplication possible)
- 1 quand le statut est `failed`

#### Conseils de dépannage rapides
- Vérifiez vos DSN Mailer/Notifier, vos variables Mercure et vos clés VAPID Web Push.
- En cas d’erreur réseau ou de transport manquant, la commande renvoie un `DeliveryStatus::failed()` avec `message` explicatif.
- Utilisez `-vvv` pour plus de verbosité de la console si nécessaire.

## Exemples

- Contrôleur `examples/Controller/NotificationsController.php`:
  - POST `/notify/ag` → envoie Email HTML + Browser (Mercure), retourne les 2 `DeliveryStatus`.
- Template twig `examples/twig/emails/convocation_ag.html.twig`.

## Async (optionnel)

Vous pouvez router `Symfony\Component\Notifier\Message\MessageInterface` vers Messenger pour de l’asynchrone.

## Sécurité

Pour Mercure, utilisez des topics scellés par utilisateur (ex. `users:{id}`) et configurez les scopes dans votre JWT.

## Corrélation & Idempotence

Le bundle fournit un contexte d’envoi `DeliveryContext` pour regrouper des envois (CorrelationId) et éviter les doublons (DedupeKey).

- CorrelationId: un UUID v4 généré automatiquement si non fourni. Il permet de relier tous les envois issus d’un même événement métier (par ex. "AG reminder #42").
- DedupeKey: une clé stable (string) représentant l’unicité métier dans une fenêtre temporelle. Exemple: `sha1("ag.reminder:$userId:$date")`.
- TTL: fenêtre de déduplication en secondes (par défaut 600 = 10 minutes).

Propagation et métadonnées:
- La façade enrichit `DeliveryStatus->metadata` avec `correlationId` et `dedupeKey`.
- Sur hit de déduplication, la façade ne déclenche pas l’envoi et retourne `queued` avec `metadata.reason = "dedup-hit"` et `message = "noop"`.

Exemples code (PHP):
```php
use WrapNotificatorBundle\Notification\DeliveryContext;

$ctx = DeliveryContext::for(sha1("ag.reminder:$userId:$date"), 900); // 15 min
$status = $facade->notifyEmail('AG', '<b>Convocation</b>', 'to@example.com', true, [], ['source' => 'controller'], $ctx);
```

Exemples CLI:
```bash
# Dédoublonnage par clé stable (TTL 15 min)
php bin/console notify:send \
  --channel=sms --to="+33600000000" --text="Hello" \
  --dedupe-key="ag.reminder:42:2025-12-01" --dedupe-ttl=900

# Fournir un CorrelationId explicite (sinon auto-généré)
php bin/console notify:send --channel=email --to=you@example.com \
  --subject=Hi --html='<b>Hi</b>' --correlation-id=4f6a4b73-0f4c-4d48-9f6a-9dc2b7b6c001
```

Recommandations TTL par canal (à adapter):
- Incidents/alertes: 5 à 15 minutes
- Rappels/notifications planifiées: 1 à 2 heures

Observabilité:
- Logguez `correlationId` dans vos logs applicatifs pour faciliter le traçage.
- Exportez `correlationId`/`dedupeKey` vers votre système d’événements (e.g., DataDog, ELK) pour corréler.

Choix du repository de déduplication:
- Par défaut, un repository PSR-6 (`cache.app`) est utilisé lorsqu’il est disponible; sinon, un fallback mémoire est actif.
- Pour forcer l’un ou l’autre, définissez un alias dans vos services:
```yaml
# config/services.yaml
services:
    WrapNotificatorBundle\Contract\DedupeRepositoryInterface: '@WrapNotificatorBundle\Infrastructure\Dedupe\CacheDedupeRepository'
    # ou
    # WrapNotificatorBundle\Contract\DedupeRepositoryInterface: '@WrapNotificatorBundle\Infrastructure\Dedupe\InMemoryDedupeRepository'
```

Construction de clés (idempotence):
- Incluez l’identité du destinataire, le type d’événement et la fenêtre (jour/heure) pour éviter des collisions involontaires.
- Exemples: `"promo:$userId:$day"`, `sha1("billing.invoice_sent:$invoiceId")`.

## Tests & CI

- Lancer les tests: `make test`
- Matrice CI: PHP 8.3

## Qualité

- phpstan niveau 8 (`phpstan.neon`)
- psr-12 via `.php-cs-fixer.php`

---

## Licence
MIT


## Diagnostic Mercure & Messenger

Une commande dédiée permet de diagnostiquer rapidement l’intégration Mercure (publication) et Messenger (bus) et d’imprimer un rapport JSON.

Commande:

```
php bin/console wrap:notificator:diagnose
```

Options:
- `--topic="wrap_notificator/diag"` Topic Mercure où publier le message de test (par défaut: `wrap_notificator/diag`).
- `--mercure-only` N’exécute que le diagnostic Mercure.
- `--messenger-only` N’exécute que le diagnostic Messenger.
- `--async` Active l’envoi asynchrone côté Messenger (ajoute des stamps lors du dispatch du message de test).
- `--delay=SECONDS` Retard en secondes à appliquer lorsque `--async` est utilisé (via `DelayStamp`).

Exemples:
- Tester les deux intégrations (par défaut):
  ```bash
  php bin/console wrap:notificator:diagnose
  ```
- Tester Mercure uniquement avec un topic personnalisé:
  ```bash
  php bin/console wrap:notificator:diagnose --mercure-only --topic="alerts:ops"
  ```
- Tester Messenger en mode async avec 30s de délai (nécessite un worker actif):
  ```bash
  php bin/console wrap:notificator:diagnose --messenger-only --async --delay=30
  php bin/console messenger:consume -vv
  ```

Sortie JSON (exemple):
```
{
  "ts": "2025-11-08T13:20:40+00:00",
  "mercure": {
    "available": true,
    "published": true,
    "id": "urn:uuid:...",
    "error": null,
    "topic": "wrap_notificator/diag"
  },
  "messenger": {
    "available": true,
    "dispatched": true,
    "transportNames": ["async"],
    "handled": false,
    "handlers": [],
    "error": null
  }
}
```

Codes de retour:
- `0` si tous les diagnostics effectués ont réussi
- `1` si au moins un des diagnostics effectués a échoué (service manquant, exception lors de la publication/du dispatch, etc.)

Dépannage:
- Mercure: vérifiez `MERCURE_URL`, `MERCURE_JWT_SECRET`, la connectivité réseau, et que votre hub est démarré. Inspectez l’`id` retourné par `publish()` si présent.
- Messenger: vérifiez votre configuration des transports, lancez un worker avec `bin/console messenger:consume -vv`, contrôlez les DSN et les permissions réseau.


---

## Écouteurs Mercure côté Twig (front) + UI moderne

Le bundle expose des fonctions Twig pour démarrer des abonnements Mercure dans le navigateur et afficher des notifications conviviales.

### Fonctions Twig
- `wrap_notify_bootstrap()`
  - Injecte un module JS exposant `window.subscribeMercure(baseUrl, topics, onMessage?, options?)` et `window.wrapNotify` (`showBootstrapToast`, `notifyBrowser`, `notifySystem`).
  - Par défaut, insère aussi la feuille de style externe du bundle.
- `wrap_notify_browser(array $topics = [])`
  - Abonne le navigateur aux topics Mercure et affiche un toast par message.
  - UX moderne: barre de progression (pause au survol), en‑tête avec titre, icône à droite, bouton fermer.
  - Variants pris en charge: `info` (défaut), `success`, `warning`, `danger`.
  - Émet l’événement `wrap:mercure` côté `window` avec `{ payload, raw, topics }`.
- `wrap_notify_system(array $topics = [])`
  - Abonne aux topics « système » et tente une notification OS via l’API Web Notifications.
  - Fallback toast si permissions absentes/refusées.
  - Émet l’événement `wrap:mercure:system`.
- `wrap_notify_styles()` (optionnel)
  - Ajoute explicitement la balise `<link>` de la feuille CSS externe si l’auto‑link est désactivé.

Si `wrap_notificator.mercure.enabled=false`, ces fonctions retournent une chaîne vide.

### Exemple d’usage Twig
```twig
{# templates/base.html.twig #}
{# CSS auto‑lié par défaut via wrap_notify_bootstrap(); si nécessaire : #}
{# {{ wrap_notify_styles() }} #}

{{ wrap_notify_bootstrap() }}
{{ wrap_notify_browser(['/chat/flash-sales']) }}
{{ wrap_notify_system(['dede:system']) }}
```

### Mapping du variant (style) depuis le payload Mercure
Les clés reconnues, par ordre de priorité: `level` (prioritaire) → `leve` → `type` → `variant` → `status` → `severity` → `kind`.
- `info|information` → info
- `danger|error|fail|failed` → danger
- `warning|warn|avertissement` → warning
- `success|ok|done|valid` → success
- Sinon: `info`

Exemples de payloads (données JSON côté Mercure):
```json
{"title":"Information","body":"Mise à jour effectuée","level":"info","delay":4000}
```
```json
{"title":"Attention","body":"Quota à 90%","level":"warning","duration":8000,"iconClass":"bi bi-exclamation-triangle"}
```
```json
{"title":"Erreur","body":"Sauvegarde échouée","level":"danger","ttl":6000,"iconUrl":"/images/error.svg"}
```
```json
{"title":"OK","body":"Tout est bon","level":"success","ui":{"position":"bottom-right","density":"compact","shadow":"lg"}}
```

### Options UI (facultatives, via payload)
- Durée: `delay` | `duration` | `ttl` (ms; min 1500, max 15000; défaut 5000)
- Position du conteneur: `position` = `top-right` (défaut) | `top-left` | `bottom-right` | `bottom-left`
- Densité: `density` = `compact` | `cozy`
- Arrondi: `rounded` (bool)
- Ombre: `shadow` = `sm` | `md` | `lg`
- Effet verre: `glass` (bool)
- Opacité: `opacity` (0.85–1)
- Icône: `iconHtml` (HTML) > `iconClass` (ex: `bi bi-info-circle`) > `icon`/`iconUrl` (image). Fallback SVG par variant si rien n’est fourni.

### Notifications système (OS)
- `wrap_notify_system()` demande la permission si nécessaire (`Notification.requestPermission`).
- Si acceptée: `new Notification(title, { body, icon })` + auto‑fermeture après 8s.
- Si refusée/indisponible: fallback en toast.

### Souscription Mercure côté navigateur
- La fonction globale `subscribeMercure(baseUrl, topics, onMessage, options)` ouvre un `EventSource` sur `baseUrl` (avec `?topic=...`).
- Par défaut, `withCredentials: true` (support du cookie JWT subscriber du hub). Vous pouvez forcer via `options.withCredentials`.
- À chaque message, `payload` est `JSON.parse(event.data)` si possible; l’événement `wrap:mercure` est émis avec `{ payload, raw: event, topics }`.

Exemple d’usage manuel :
```html
<script type="module">
  window.subscribeMercure('https://mercure.example/.well-known/mercure', ['/demo/topic'],
    (payload) => console.log('Mercure:', payload),
    { withCredentials: true }
  );
</script>
```

### Feuille de style externe (par défaut)
Le style des toasts est livré par un CSS externe:
- Chemin par défaut: `@WrapNotificator/css/wrap_notificator.css`
- Config par défaut: `ui.external_css: true` et `ui.auto_link_css: true` → le `<link>` est ajouté automatiquement par `wrap_notify_bootstrap()`.
- Pour changer le chemin :
```yaml
wrap_notificator:
  mercure:
    ui:
      asset_path: '@WrapNotificator/css/wrap_notificator.css'
      external_css: true
      auto_link_css: true
```
Si vous désactivez `auto_link_css`, ajoutez `{{ wrap_notify_styles() }}` dans le `<head>`.

N’oubliez pas d’exposer les assets si nécessaire :
```
php bin/console assets:install --symlink --relative
```

### Remarques CORS / Auth
- Avec `withCredentials: true` :
  - Le hub doit retourner `Access-Control-Allow-Credentials: true`.
  - `Access-Control-Allow-Origin` doit être l’origine exacte du site (pas `*`).
  - En cross‑domain, le cookie JWT doit être `SameSite=None; Secure` et servi en HTTPS.
- `EventSource` n’accepte pas d’en‑têtes personnalisés; l’auth se fait côté cookie du hub.

### Débogage rapide
- Aucun toast ? Vérifiez que `wrap_notify_bootstrap()` est inclus avant les autres, que `wrap_notificator.mercure.enabled=true`, et l’URL publique Mercure.
- Pas de styles ? Vérifiez la présence du `<link>` vers `@WrapNotificator/css/wrap_notificator.css` (ou votre chemin configuré).
- Notifications OS: vérifier les permissions navigateur/OS; le fallback toast doit apparaître si refusées.
