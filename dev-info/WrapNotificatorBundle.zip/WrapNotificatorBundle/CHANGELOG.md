# CHANGELOG

All notable changes to this project will be documented in this file.

## [1.1.0] - 2025-11-08
- Added diagnostic CLI command `wrap:notificator:diagnose` for Mercure & Messenger
  - Publishes a Mercure test Update and/or dispatches a Messenger ping
  - Prints a JSON report and returns 0/1 depending on success
  - Documented in README under "Diagnostic Mercure & Messenger"

## [1.0.0] - 2025-11-08
- Initial release of WrapNotificatorBundle
  - Facade API over Mailer + Notifier + Mercure + Web Push
  - MessageFactory, TypedSender, NotifierFacade
  - CLI command `notify:send`
  - DTOs: DeliveryStatus, BrowserPayload, WebPushMessage
  - Examples, tests, CI, and quality tooling
