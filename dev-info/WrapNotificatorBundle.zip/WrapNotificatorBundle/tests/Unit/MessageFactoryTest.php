<?php

declare(strict_types=1);

namespace WrapNotificatorBundle\Tests\Unit;

use PHPUnit\Framework\TestCase;
use Symfony\Component\Mime\Address;
use Symfony\Component\Mime\Email;
use Symfony\Component\Notifier\Bridge\Slack\SlackOptions;
use Symfony\Component\Notifier\Bridge\Telegram\TelegramOptions;
use Symfony\Component\Notifier\Message\ChatMessage;
use Symfony\Component\Notifier\Message\SmsMessage;
use WrapNotificatorBundle\Notification\BrowserPayload;
use WrapNotificatorBundle\Notification\MessageFactory;
use WrapNotificatorBundle\Notification\WebPushMessage;

final class MessageFactoryTest extends TestCase
{
    public function testEmailTextVsHtmlAndFrom(): void
    {
        $factory = new MessageFactory();
        $emailHtml = $factory->email('Hi', '<b>Hello</b>', 'to@example.com', ['html' => true, 'from' => ['me@example.com', 'Me']]);
        self::assertInstanceOf(Email::class, $emailHtml);
        self::assertSame('Hi', $emailHtml->getSubject());
        self::assertSame('to@example.com', $emailHtml->getTo()[0]->getAddress());
        self::assertSame('me@example.com', $emailHtml->getFrom()[0]->getAddress());
        self::assertSame('Me', $emailHtml->getFrom()[0]->getName());

        $emailText = $factory->email('Hi', 'Hello', 'to@example.com', ['html' => false]);
        self::assertStringContainsString('Hello', $emailText->getTextBody() ?? '');
    }

    public function testChatSlackAndTelegramOptions(): void
    {
        $factory = new MessageFactory();
        $slack = $factory->chat('slack', 'content', 'subject', [
            'channel' => 'ops',
            'iconEmoji' => ':bell:',
            'blocks' => [['type' => 'section', 'text' => ['type' => 'mrkdwn', 'text' => 'Hi']]],
        ]);
        self::assertInstanceOf(ChatMessage::class, $slack);
        self::assertSame('slack', $slack->getTransport());
        $slackOptions = $slack->getOptions();
        self::assertInstanceOf(SlackOptions::class, $slackOptions);

        $tg = $factory->chat('telegram', 'content', null, [
            'chatId' => '12345',
            'parseMode' => 'HTML',
            'disableWebPagePreview' => true,
        ]);
        self::assertSame('telegram', $tg->getTransport());
        $tgOptions = $tg->getOptions();
        self::assertInstanceOf(TelegramOptions::class, $tgOptions);
    }

    public function testBrowserAndPushDtos(): void
    {
        $factory = new MessageFactory();
        $browser = $factory->browser('topic', ['a' => 1]);
        self::assertInstanceOf(BrowserPayload::class, $browser);
        self::assertSame('topic', $browser->topic);
        self::assertSame(['a' => 1], $browser->data);

        $subscription = [
            'endpoint' => 'https://ep',
            'keys' => ['p256dh' => 'p', 'auth' => 'a'],
        ];
        $push = $factory->push($subscription, ['msg' => 'hi'], 60);
        self::assertInstanceOf(WebPushMessage::class, $push);
        self::assertSame('https://ep', $push->endpoint);
        self::assertSame(60, $push->ttl);
        self::assertStringContainsString('"msg":"hi"', $push->payloadJson);
    }
}
