<?php

declare(strict_types=1);

namespace WrapNotificatorBundle\Tests\Unit;

use PHPUnit\Framework\TestCase;
use Psr\Cache\CacheItemInterface;
use Psr\Cache\CacheItemPoolInterface;
use WrapNotificatorBundle\Infrastructure\Dedupe\CacheDedupeRepository;
use WrapNotificatorBundle\Infrastructure\Dedupe\InMemoryDedupeRepository;

final class DedupeRepositoryTest extends TestCase
{
    public function testInMemoryRememberAndExists(): void
    {
        $repo = new InMemoryDedupeRepository();
        $key = 'k1';
        self::assertFalse($repo->exists($key));
        $repo->remember($key, 60);
        self::assertTrue($repo->exists($key));
    }

    public function testCacheRepoRememberAndTtl(): void
    {
        $cache = new class implements CacheItemPoolInterface {
            /** @var array<string,CacheItemInterface> */
            private array $items = [];
            public function getItem(string $key): CacheItemInterface { return $this->items[$key] = $this->items[$key] ?? new class($key) implements CacheItemInterface {
                public function __construct(private string $key, private bool $hit = false, private mixed $value = null, public ?int $exp = null) {}
                public function getKey(): string { return $this->key; }
                public function get(): mixed { return $this->value; }
                public function isHit(): bool { return $this->hit && ($this->exp === null || $this->exp > time()); }
                public function set(mixed $value): \Psr\Cache\CacheItemInterface { $this->value = $value; $this->hit = true; return $this; }
                public function expiresAt(?\DateTimeInterface $expiration): \Psr\Cache\CacheItemInterface { $this->exp = $expiration?->getTimestamp(); return $this; }
                public function expiresAfter(int|\DateInterval|null $time): \Psr\Cache\CacheItemInterface {
                    if ($time instanceof \DateInterval) {
                        $time = (new \DateTimeImmutable('@0'))->add($time)->getTimestamp();
                    }
                    $this->exp = is_int($time) ? time() + $time : null; return $this;
                }
            }; }
            public function getItems(array $keys = []): iterable { foreach ($keys as $k) { yield $this->getItem($k); } }
            public function hasItem(string $key): bool { return isset($this->items[$key]) && $this->items[$key]->isHit(); }
            public function clear(): bool { $this->items = []; return true; }
            public function deleteItem(string $key): bool { unset($this->items[$key]); return true; }
            public function deleteItems(array $keys): bool { foreach ($keys as $k) { unset($this->items[$k]); } return true; }
            public function save(CacheItemInterface $item): bool { return true; }
            public function saveDeferred(CacheItemInterface $item): bool { return true; }
            public function commit(): bool { return true; }
            // helper
            public function forceExpireAll(): void { foreach ($this->items as $i) { if ($i instanceof \stdClass) continue; $i->expiresAfter(0); } }
        };

        $repo = new CacheDedupeRepository($cache);
        $key = 'k-cache';
        self::assertFalse($repo->exists($key));
        $repo->remember($key, 1);
        self::assertTrue($repo->exists($key));
        // simulate TTL pass by forcing expiration
        if (method_exists($cache, 'forceExpireAll')) {
            $cache->forceExpireAll();
        }
        // After expiry, hasItem returns false
        self::assertFalse($repo->exists($key));
    }
}
