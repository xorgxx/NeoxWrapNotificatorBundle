<?php

declare(strict_types=1);

namespace WrapNotificatorBundle\Tests\Unit;

use PHPUnit\Framework\TestCase;
use WrapNotificatorBundle\Contract\DedupeRepositoryInterface;
use WrapNotificatorBundle\Contract\SenderInterface;
use WrapNotificatorBundle\Notification\DeliveryContext;
use WrapNotificatorBundle\Notification\DeliveryStatus;
use WrapNotificatorBundle\Notification\MessageFactory;
use WrapNotificatorBundle\Service\NotifierFacade;

final class NotifierFacadeDedupeTest extends TestCase
{
    public function testDedupeMissThenSentWithContext(): void
    {
        $factory = new MessageFactory();
        $sender = $this->createMock(SenderInterface::class);
        $sender->method('sendSms')->willReturn(DeliveryStatus::sent('sms'));

        $repo = new class implements DedupeRepositoryInterface {
            public array $remembered = [];
            public function remember(string $key, int $ttlSeconds): void { $this->remembered[$key] = $ttlSeconds; }
            public function exists(string $key): bool { return false; }
        };

        $facade = new NotifierFacade($factory, $sender, $repo);
        $ctx = DeliveryContext::for('k-user-1', 900);
        $status = $facade->notifySms('hi', '+336', [], $ctx);
        self::assertSame('sent', $status->status);
        self::assertSame('sms', $status->channel);
        self::assertSame('k-user-1', $status->metadata['dedupeKey'] ?? null);
        self::assertArrayHasKey('correlationId', $status->metadata);
        self::assertSame(900, $repo->remembered['k-user-1']);
    }

    public function testDedupeHitReturnsQueuedNoop(): void
    {
        $factory = new MessageFactory();
        $sender = $this->createMock(SenderInterface::class);
        $sender->expects(self::never())->method('sendSms');

        $repo = new class implements DedupeRepositoryInterface {
            public function remember(string $key, int $ttlSeconds): void {}
            public function exists(string $key): bool { return $key === 'k-hit'; }
        };

        $facade = new NotifierFacade($factory, $sender, $repo);
        $ctx = DeliveryContext::for('k-hit', 600);
        $status = $facade->notifySms('hi', '+336', [], $ctx);
        self::assertSame(DeliveryStatus::STATUS_QUEUED, $status->status);
        self::assertSame('dedup-hit', $status->metadata['reason'] ?? null);
        self::assertSame('k-hit', $status->metadata['dedupeKey'] ?? null);
    }
}
