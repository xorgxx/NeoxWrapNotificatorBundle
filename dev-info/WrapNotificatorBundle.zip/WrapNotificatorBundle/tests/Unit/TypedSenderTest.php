<?php

declare(strict_types=1);

namespace WrapNotificatorBundle\Tests\Unit;

use Minishlink\WebPush\Report;
use Minishlink\WebPush\Subscription;
use Minishlink\WebPush\WebPush;
use PHPUnit\Framework\TestCase;
use Prophecy\PhpUnit\ProphecyTrait;
use Prophecy\Prophecy\ObjectProphecy;
use Symfony\Component\Mailer\MailerInterface;
use Symfony\Component\Mime\Email;
use Symfony\Component\Notifier\ChatterInterface;
use Symfony\Component\Notifier\Message\ChatMessage;
use Symfony\Component\Notifier\Message\SmsMessage;
use Symfony\Component\Notifier\TexterInterface;
use Symfony\Component\Mercure\HubInterface;
use Symfony\Component\Mercure\Update;
use WrapNotificatorBundle\Notification\BrowserPayload;
use WrapNotificatorBundle\Notification\TypedSender;
use WrapNotificatorBundle\Notification\WebPushMessage;

final class TypedSenderTest extends TestCase
{
    use ProphecyTrait;

    public function testSendEmailSent(): void
    {
        $mailer = $this->prophesize(MailerInterface::class);
        $mailer->send(\Prophecy\Argument::type(Email::class))->shouldBeCalled();
        $sender = new TypedSender($mailer->reveal());
        $status = $sender->sendEmail(new Email());
        self::assertSame('email', $status->channel);
        self::assertSame('sent', $status->status);
        self::assertNotEmpty($status->uuid);
    }

    public function testSendSmsFailedWithoutTexter(): void
    {
        $sender = new TypedSender();
        $status = $sender->sendSms(new SmsMessage('+336', 'hi'));
        self::assertSame('failed', $status->status);
    }

    public function testSendChatSent(): void
    {
        $chatter = $this->prophesize(ChatterInterface::class);
        $chatter->send(new ChatMessage('content'))->shouldBeCalled();
        $sender = new TypedSender(mailer: null, chatter: $chatter->reveal());
        $status = $sender->sendChat(new ChatMessage('content'));
        self::assertSame('sent', $status->status);
    }

    public function testSendBrowserSentWithId(): void
    {
        $hub = $this->prophesize(HubInterface::class);
        $hub->publish(new Update('topic', '{"a":1}'))->willReturn('id-123');
        $sender = new TypedSender(null, null, null, $hub->reveal());
        $status = $sender->sendBrowser(new BrowserPayload('topic', ['a' => 1]));
        self::assertSame('sent', $status->status);
        self::assertSame('id-123', $status->id);
    }

    public function testSendPushFailedReason(): void
    {
        $report = $this->createMock(Report::class);
        $report->method('isSuccess')->willReturn(false);
        $report->method('getReason')->willReturn('invalid token');
        $webPush = $this->createMock(WebPush::class);
        $webPush->method('sendOneNotification')->willReturn($report);

        $sender = new TypedSender(null, null, null, null, $webPush);
        $msg = new WebPushMessage('https://ep', 'p', 'a', '{"hi":1}', 60);
        $status = $sender->sendPush($msg);
        self::assertSame('failed', $status->status);
        self::assertSame('invalid token', $status->message);
    }
}
