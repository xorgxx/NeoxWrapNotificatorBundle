<?php

declare(strict_types=1);

namespace WrapNotificatorBundle\Tests\Unit;

use PHPUnit\Framework\TestCase;
use WrapNotificatorBundle\Notification\DeliveryContext;

final class DeliveryContextTest extends TestCase
{
    public function testAutoCorrelationIdAndToArray(): void
    {
        $ctx = DeliveryContext::create();
        self::assertNotEmpty($ctx->correlationId);
        self::assertNull($ctx->dedupeKey);
        self::assertNull($ctx->ttlSeconds);
        $arr = $ctx->toArray();
        self::assertArrayHasKey('correlationId', $arr);
    }

    public function testForHelperSetsDedupeAndTtl(): void
    {
        $ctx = DeliveryContext::for('key-123', 900);
        self::assertSame('key-123', $ctx->dedupeKey);
        self::assertSame(900, $ctx->ttlSeconds);
        self::assertNotEmpty($ctx->correlationId);
    }
}
