<?php

declare(strict_types=1);

namespace WrapNotificatorBundle\Tests\Unit;

use PHPUnit\Framework\TestCase;
use WrapNotificatorBundle\Notification\MessageFactory;
use WrapNotificatorBundle\Contract\SenderInterface;
use WrapNotificatorBundle\Service\NotifierFacade;
use Symfony\Component\Mime\Email;
use Symfony\Component\Notifier\Message\ChatMessage;
use Symfony\Component\Notifier\Message\SmsMessage;
use WrapNotificatorBundle\Notification\BrowserPayload;
use WrapNotificatorBundle\Notification\WebPushMessage;
use WrapNotificatorBundle\Notification\DeliveryStatus;

final class NotifierFacadeTest extends TestCase
{
    public function testNotifyEmailHappyPath(): void
    {
        $factory = new MessageFactory();
        $sender = $this->createMock(SenderInterface::class);
        $sender->method('sendEmail')->willReturn(DeliveryStatus::sent('email'));
        $facade = new NotifierFacade($factory, $sender);
        $status = $facade->notifyEmail('Hi', '<b>X</b>', 'to@example.com', true);
        self::assertSame('email', $status->channel);
        self::assertSame('sent', $status->status);
    }

    public function testNotifySmsHappyPath(): void
    {
        $factory = new MessageFactory();
        $sender = $this->createMock(TypedSender::class);
        $sender->method('sendSms')->willReturn(DeliveryStatus::sent('sms'));
        $facade = new NotifierFacade($factory, $sender);
        $status = $facade->notifySms('hi', '+336');
        self::assertSame('sent', $status->status);
    }

    public function testNotifyChatHappyPath(): void
    {
        $factory = new MessageFactory();
        $sender = $this->createMock(TypedSender::class);
        $sender->method('sendChat')->willReturn(DeliveryStatus::sent('chat'));
        $facade = new NotifierFacade($factory, $sender);
        $status = $facade->notifyChat('slack', 'hi', 'subj');
        self::assertSame('sent', $status->status);
    }

    public function testNotifyBrowserHappyPath(): void
    {
        $factory = new MessageFactory();
        $sender = $this->createMock(TypedSender::class);
        $sender->method('sendBrowser')->willReturn(DeliveryStatus::sent('browser', 'id-1'));
        $facade = new NotifierFacade($factory, $sender);
        $status = $facade->notifyBrowser('topic', ['a' => 1]);
        self::assertSame('sent', $status->status);
        self::assertSame('id-1', $status->id);
    }

    public function testNotifyPushHappyPathAndDesktopAlias(): void
    {
        $factory = new MessageFactory();
        $sender = $this->createMock(TypedSender::class);
        $sender->method('sendPush')->willReturn(DeliveryStatus::sent('push'));
        $facade = new NotifierFacade($factory, $sender);
        $subscription = ['endpoint' => 'https://ep', 'keys' => ['p256dh' => 'p', 'auth' => 'a']];
        $statusPush = $facade->notifyPush($subscription, ['x' => 1], 60);
        self::assertSame('sent', $statusPush->status);
        $statusDesktop = $facade->notifyDesktop($subscription, ['x' => 1], 60);
        self::assertSame('sent', $statusDesktop->status);
    }
}
