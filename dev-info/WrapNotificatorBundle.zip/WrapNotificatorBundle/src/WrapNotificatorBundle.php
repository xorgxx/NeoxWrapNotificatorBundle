<?php

declare(strict_types=1);

namespace Neox\WrapNotificatorBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

final class WrapNotificatorBundle extends Bundle
{
}
