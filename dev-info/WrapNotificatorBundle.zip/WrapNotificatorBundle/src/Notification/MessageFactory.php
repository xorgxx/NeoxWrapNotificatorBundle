<?php

declare(strict_types=1);

namespace Neox\WrapNotificatorBundle\Notification;

use Symfony\Component\Mime\Address;
use Symfony\Component\Mime\Email;
use Symfony\Component\Notifier\Message\ChatMessage;
use Symfony\Component\Notifier\Message\SmsMessage;
use Symfony\Component\Notifier\Bridge\Slack\SlackOptions;
use Symfony\Component\Notifier\Bridge\Telegram\TelegramOptions;

final class MessageFactory
{
    /**
     * @param array{html?:bool,from?:array{0:string,1:string|null}} $opts
     */
    public function email(string $subject, string $content, string $to, array $opts = []): Email
    {
        $email = new Email();
        $email = $email->subject($subject)
            ->to($to);

        if (isset($opts['from'])) {
            $from = $opts['from'];
            $email = $email->from(new Address($from[0], $from[1] ?? null));
        }

        $isHtml = $opts['html'] ?? true;
        if ($isHtml) {
            $email = $email->html($content);
        } else {
            $email = $email->text($content);
        }

        return $email;
    }

    public function sms(string $content, string $to): SmsMessage
    {
        return new SmsMessage($to, $content);
    }

    /**
     * @param array<string,mixed> $opts
     */
    public function chat(string $transport, string $content, ?string $subject = null, array $opts = []): ChatMessage
    {
        $message = new ChatMessage($content);
        $message->transport($transport);
        if ($subject !== null) {
            $message->subject($subject);
        }

        if ($transport === 'slack') {
            $options = new SlackOptions();
            if (isset($opts['channel'])) {
                $options = $options->channel((string) $opts['channel']);
            }
            if (isset($opts['iconEmoji'])) {
                $options = $options->iconEmoji((string) $opts['iconEmoji']);
            }
            if (isset($opts['blocks']) && is_array($opts['blocks'])) {
                $options = $options->blocks($opts['blocks']);
            }
            $message->options($options);
        } elseif ($transport === 'telegram') {
            $options = new TelegramOptions();
            if (isset($opts['chatId'])) {
                $options = $options->chatId((string) $opts['chatId']);
            }
            if (isset($opts['parseMode'])) {
                $options = $options->parseMode((string) $opts['parseMode']);
            }
            if (isset($opts['disableWebPagePreview'])) {
                $options = $options->disableWebPagePreview((bool) $opts['disableWebPagePreview']);
            }
            $message->options($options);
        }

        return $message;
    }

    /**
     * @param array<string,mixed> $data
     */
    public function browser(string $topic, array $data): BrowserPayload
    {
        return new BrowserPayload($topic, $data);
    }

    /**
     * @param array<string,mixed> $data
     * @param array{endpoint:string,keys:array{p256dh:string,auth:string}} $subscription
     */
    public function push(array $subscription, array $data, ?int $ttl = null): WebPushMessage
    {
        $payloadJson = json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        if ($payloadJson === false) {
            $payloadJson = '{}';
        }

        return new WebPushMessage(
            endpoint: $subscription['endpoint'],
            p256dh: $subscription['keys']['p256dh'],
            auth: $subscription['keys']['auth'],
            payloadJson: $payloadJson,
            ttl: $ttl,
        );
    }
}
