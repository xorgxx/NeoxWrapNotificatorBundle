<?php

declare(strict_types=1);

namespace Neox\WrapNotificatorBundle\Notification;

use Symfony\Component\Uid\Uuid;

final class DeliveryContext
{
    public function __construct(
        public readonly string $correlationId,
        public readonly ?string $dedupeKey = null,
        public readonly ?int $ttlSeconds = null,
    ) {
    }

    public static function create(?string $correlationId = null, ?string $dedupeKey = null, ?int $ttlSeconds = null): self
    {
        return new self($correlationId ?? Uuid::v4()->toRfc4122(), $dedupeKey, $ttlSeconds);
    }

    public static function for(string $dedupeKey, ?int $ttlSeconds = 600): self
    {
        return new self(Uuid::v4()->toRfc4122(), $dedupeKey, $ttlSeconds);
    }

    /**
     * @return array{correlationId:string,dedupeKey:string|null,ttlSeconds:int|null}
     */
    public function toArray(): array
    {
        return [
            'correlationId' => $this->correlationId,
            'dedupeKey' => $this->dedupeKey,
            'ttlSeconds' => $this->ttlSeconds,
        ];
    }
}
